import { authService } from "@/services/authService";
import { useAuthStore } from "@/store/authStore";
import { Ionicons } from "@expo/vector-icons";
import { router, usePathname } from "expo-router";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  ImageBackground,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function ProfileScreen() {
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState("简体中文");
  const [loading, setLoading] = useState(true);
  const [supportedLanguages, setSupportedLanguages] = useState<
    Array<{ code?: string; name?: string }>
  >([]);

  const user = useAuthStore((state) => state.user);
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const insets = useSafeAreaInsets();
  const pathname = usePathname();

  // 页面加载时获取用户信息和语言列表
  useEffect(() => {
    if (isAuthenticated) {
      loadUserData();
    } else {
      setLoading(false);
    }
  }, [isAuthenticated]);

  const loadUserData = async () => {
    try {
      setLoading(true);

      // 并行获取用户信息和支持的语言列表
      const [languages] = await Promise.all([
        authService.getSupportedLanguages(),
        authService.getUserInfo(),
      ]);

      setSupportedLanguages(languages);

      // 设置当前选中的语言
      if (user?.language) {
        const currentLang = languages.find(
          (lang) => lang.code === user.language
        );
        if (currentLang) {
          setSelectedLanguage(currentLang.name || "简体中文");
        }
      }
    } catch (error) {
      console.error("加载用户数据失败:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleLanguageSelect = async (
    languageCode: string,
    languageName: string
  ) => {
    try {
      await authService.updateLanguage(languageCode);
      setSelectedLanguage(languageName);
      setModalVisible(false);
    } catch (error) {
      console.error("更新语言失败:", error);
      Alert.alert("失败", "更新语言设置失败，请重试");
    }
  };

  const handleLogout = () => {
    // 已登录，显示退出确认
    Alert.alert("退出账号", "确定要退出当前账号吗？", [
      {
        text: "取消",
        style: "cancel",
      },
      {
        text: "退出",
        style: "destructive",
        onPress: async () => {
          try {
            await authService.logout();
            // 退出后会自动触发 useEffect 跳转到登录页
          } catch (error) {
            console.error("退出失败:", error);
            Alert.alert("退出失败", "请稍后重试");
          }
        },
      },
    ]);
  };

  if (loading) {
    return (
      <View
        style={[
          styles.container,
          { justifyContent: "center", alignItems: "center" },
        ]}
      >
        <ActivityIndicator size="large" color="#ffffff" />
      </View>
    );
  }

  // 未登录状态
  if (!isAuthenticated) {
    return (
      <ImageBackground
        source={require("@/assets/drama/bg.png")}
        style={styles.notLoginContainer}
        resizeMode="cover"
      >
        {/* 蒙层 */}
        <View style={styles.overlay} />

        <Text style={{ ...styles.notLoginTitle ,marginTop:insets.top}}>登录</Text>

        <View style={styles.notLoginContent}>
          <View style={styles.titleContainer}>
            {/* 右上方装饰线 */}
            <View style={styles.lineTopRight} />

            <Text style={styles.todayText}>Today</Text>
            <Text style={styles.dramaText}>Drama</Text>

            {/* 左下方装饰线 */}
            <View style={styles.lineBottomLeft} />
          </View>
        </View>

        <View style={[styles.loginButtonWrapper, { bottom: 80 + insets.bottom }]}>
          <TouchableOpacity
            style={styles.notLoginButton}
            onPress={() => router.push("/login")}
          >
            <Text style={styles.notLoginButtonText}>登录</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        {user?.avatarUrl ? (
          <Image source={{ uri: user.avatarUrl }} style={styles.avatar} />
        ) : (
          <View style={[styles.avatar, styles.avatarPlaceholder]}>
            <Ionicons name="person" size={32} color="#ffffff" />
          </View>
        )}
        <View style={styles.userInfo}>
          <Text style={styles.username}>
            {user?.nickname || user?.username || "未设置用户名"}
          </Text>
          <Text style={styles.userId}>账号：{user?.userId || "未知"}</Text>
        </View>
      </View>
      <View style={styles.baseInfo}>
        <Text style={styles.infoTitle}>基础信息</Text>
        <TouchableOpacity
          style={styles.laugBox}
          onPress={() => setModalVisible(true)}
        >
          <Text style={styles.laugTitle}>语言</Text>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Text style={styles.laugBtn}>{selectedLanguage}</Text>
            <Ionicons
              name="chevron-forward"
              size={20}
              color="#ffffff"
              style={{ marginLeft: 8 }}
            />
          </View>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Ionicons
          name="log-out-outline"
          size={20}
          color="#FF5252"
          style={{ marginRight: 8 }}
        />
        <Text style={styles.logoutText}>退出账号</Text>
      </TouchableOpacity>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>选择语言</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={28} color="#ffffff" />
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.languageList}>
              {supportedLanguages.map((lang) => (
                <TouchableOpacity
                  key={lang.code}
                  style={styles.languageItem}
                  onPress={() => handleLanguageSelect(lang.code!, lang.name!)}
                >
                  <Text style={styles.languageText}>{lang.name}</Text>
                  {selectedLanguage === lang.name && (
                    <Ionicons name="checkmark" size={24} color="#4CAF50" />
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* 自定义 Tab Bar */}
      <View style={[styles.customTabBar, { height: 40 + insets.bottom, paddingBottom: insets.bottom }]}>
        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => router.push('/(tabs)/dream')}
        >
          <Text style={[styles.tabText, pathname === '/dream' && styles.tabTextActive]}>
            叙梦
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => router.push('/(tabs)/profile')}
        >
          <Text style={[styles.tabText, pathname === '/profile' && styles.tabTextActive]}>
            我的
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1e1e1e",
    paddingTop: 60, 
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 60,
    marginLeft: 20,
  },
  avatar: {
    width: 57,
    height: 57,
    borderRadius: 28.5,
  },
  avatarPlaceholder: {
    backgroundColor: "rgba(49, 49, 49, 1)",
    justifyContent: "center",
    alignItems: "center",
  },
  userInfo: {
    marginLeft: 16,
  },
  username: {
    fontSize: 20,
    color: "#FFFFFF",
    fontWeight: "500",
  },
  userId: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.63)",
    marginTop: 4,
  },
  baseInfo: {
    marginLeft: 20,
    marginTop: 40,
  },
  infoTitle: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.63)",
  },
  laugBox: {
    height: 57,
    width: "100%",
    backgroundColor: "rgba(49, 49, 49, 1)",
    marginTop: 20,
    borderRadius: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
  },
  laugTitle: {
    fontSize: 16,
    color: "#ffffff",
  },
  laugBtn: {
    fontSize: 16,
    color: "#ffffff",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    justifyContent: "flex-end",
  },
  modalContent: {
    backgroundColor: "#2a2a2a",
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: 40,
    maxHeight: "70%",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255, 255, 255, 0.1)",
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#ffffff",
  },
  languageList: {
    paddingHorizontal: 20,
  },
  languageItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255, 255, 255, 0.05)",
  },
  languageText: {
    fontSize: 16,
    color: "#ffffff",
  },
  logoutButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: 57,
    backgroundColor: "rgba(49, 49, 49, 1)",
    borderRadius: 16,
    marginLeft: 20,
    marginTop: 40,
  },
  logoutText: {
    fontSize: 16,
    color: "#FF5252",
    fontWeight: "500",
  },
  notLoginContainer: {
    flex: 1,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(30, 30, 30, 0.63)",
  },
  notLoginTitle: {
    fontSize: 20,
    color: "#FFFFFF",
    textAlign: "center",
    paddingTop: 60,
  },
  notLoginContent: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 150,
  },
  titleContainer: {
    width: "70%",
    position: "relative",
  },
  lineTopRight: {
    position: "absolute",
    top: -30,
    right: -20,
    width: 150,
    height: 1,
    backgroundColor: "#FFFFFF",
    transform: [{ rotate: "45deg" }],
  },
  lineBottomLeft: {
    position: "absolute",
    bottom: -30,
    left: -20,
    width: 150,
    height: 1,
    backgroundColor: "#FFFFFF",
    transform: [{ rotate: "45deg" }],
  },
  todayText: {
    fontSize: 60,
    color: "#FFFFFF",
    fontWeight: "300",
    letterSpacing: 2,
    textAlign: "left",
  },
  dramaText: {
    fontSize: 60,
    color: "#FFFFFF",
    fontWeight: "300",
    letterSpacing: 2,
    textAlign: "right",
    marginTop: 18,
  },
  loginButtonWrapper: {
    position: "absolute",
    bottom: 80,
    left: 0,
    right: 0,
    alignItems: "center",
  },
  notLoginButton: {
    width: 300,
    height: 55,
    backgroundColor: "#FFFFFF",
    borderRadius: 25,
    justifyContent: "center",
    alignItems: "center",
  },
  notLoginButtonText: {
    fontSize: 16,
    color: "#000000",
    fontWeight: "500",
  },
  loginButton: {
    height: 57,
    backgroundColor: "rgba(49, 49, 49, 1)",
    borderRadius: 16,
    marginHorizontal: 20,
    marginTop: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  loginButtonText: {
    fontSize: 16,
    color: "#FFFFFF",
    fontWeight: "500",
  },
  customTabBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 40,
    flexDirection: 'row',
    backgroundColor: '#1c1c1c',
  },
  tabItem: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    height: 40,
  },
  tabText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#8C8C8C',
  },
  tabTextActive: {
    color: '#FFFFFF',
  },
});
