import { Ionicons } from "@expo/vector-icons";
import { useEffect, useRef, useState } from "react";
import {
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

const YEARS = [
  2025, 2024, 2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016,
  2015, 2014, 2013, 2012, 2011, 2010, 2009, 2008, 2007, 2006,
  2005, 2004, 2003, 2002, 2001, 2000, 1999, 1998, 1997, 1996,
  1995, 1994, 1993, 1992, 1991, 1990, 1989, 1988, 1987, 1986,
  1985, 1984, 1983, 1982, 1981, 1980, 1979, 1978, 1977, 1976,
  1975, 1974, 1973, 1972, 1971, 1970, 1969, 1968, 1967, 1966,
  1965, 1964, 1963, 1962, 1961, 1960, 1959, 1958, 1957, 1956,
  1955, 1954, 1953, 1952, 1951, 1950, 1949, 1948, 1947, 1946,
  1945, 1944, 1943, 1942, 1941, 1940, 1939, 1938, 1937, 1936,
  1935, 1934, 1933, 1932, 1931, 1930, 1929, 1928, 1927, 1926,
  1925
];

interface DatePickerProps {
  visible: boolean;
  onClose: () => void;
  onSelect: (date: Date) => void;
  selectedDate?: Date;
}

export default function DatePicker({
  visible,
  onClose,
  onSelect,
  selectedDate,
}: DatePickerProps) {
  const [currentDate, setCurrentDate] = useState(selectedDate || new Date());
  const [viewMode, setViewMode] = useState<"day" | "month" | "year">("day");
  const yearScrollViewRef = useRef<ScrollView>(null);

  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const monthsShort = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  const weekDays = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

  useEffect(() => {
    if (viewMode === "year" && yearScrollViewRef.current) {
      const currentYear = currentDate.getFullYear();
      const yearIndex = YEARS.indexOf(currentYear);

      if (yearIndex !== -1) {
        const scrollPosition = yearIndex * 58 - 150 + 25;

        setTimeout(() => {
          yearScrollViewRef.current?.scrollTo({
            y: Math.max(0, scrollPosition),
            animated: true,
          });
        }, 100);
      }
    }
  }, [viewMode, currentDate]);

  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const generateCalendarDays = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);

    const days: (number | null)[] = [];

    for (let i = 0; i < firstDay; i++) {
      days.push(null);
    }

    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i);
    }

    return days;
  };

  const handlePrevMonth = () => {
    const newDate = new Date(currentDate);
    newDate.setMonth(newDate.getMonth() - 1);
    setCurrentDate(newDate);
  };

  const handleNextMonth = () => {
    const newDate = new Date(currentDate);
    newDate.setMonth(newDate.getMonth() + 1);
    setCurrentDate(newDate);
  };

  const handlePrevYear = () => {
    const newDate = new Date(currentDate);
    newDate.setFullYear(newDate.getFullYear() - 1);
    setCurrentDate(newDate);
  };

  const handleNextYear = () => {
    const newDate = new Date(currentDate);
    newDate.setFullYear(newDate.getFullYear() + 1);
    setCurrentDate(newDate);
  };

  const handleDaySelect = (day: number) => {
    const newDate = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(),
      day
    );
    onSelect(newDate);
    onClose();
  };

  const handleMonthSelect = (monthIndex: number) => {
    const newDate = new Date(currentDate);
    newDate.setMonth(monthIndex);
    setCurrentDate(newDate);
    setViewMode("day");
  };

  const handleYearSelect = (year: number) => {
    const newDate = new Date(currentDate);
    newDate.setFullYear(year);
    setCurrentDate(newDate);
    setViewMode("month");
  };

  const isToday = (day: number) => {
    const today = new Date();
    return (
      day === today.getDate() &&
      currentDate.getMonth() === today.getMonth() &&
      currentDate.getFullYear() === today.getFullYear()
    );
  };

  const isSelected = (day: number) => {
    if (!selectedDate) return false;
    return (
      day === selectedDate.getDate() &&
      currentDate.getMonth() === selectedDate.getMonth() &&
      currentDate.getFullYear() === selectedDate.getFullYear()
    );
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          {}
          <View style={styles.header}>
            <TouchableOpacity onPress={viewMode === "day" ? handlePrevMonth : handlePrevYear}>
              <Ionicons name="chevron-back" size={24} color="#000000" />
            </TouchableOpacity>

            <View style={styles.headerCenter}>
              <TouchableOpacity onPress={() => setViewMode("month")}>
                <Text style={styles.headerText}>
                  {months[currentDate.getMonth()]}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setViewMode("year")}>
                <Text style={styles.headerText}>
                  {currentDate.getFullYear()}
                </Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity onPress={viewMode === "day" ? handleNextMonth : handleNextYear}>
              <Ionicons name="chevron-forward" size={24} color="#000000" />
            </TouchableOpacity>
          </View>

          {}
          {viewMode === "day" && (
            <>
              <View style={styles.weekDays}>
                {weekDays.map((day) => (
                  <Text key={day} style={styles.weekDayText}>
                    {day}
                  </Text>
                ))}
              </View>

              <View style={styles.daysGrid}>
                {generateCalendarDays().map((day, index) => (
                  <TouchableOpacity
                    key={index}
                    style={[
                      styles.dayCell,
                      day === null && styles.emptyCell,
                      day !== null && isSelected(day) && styles.selectedDay,
                    ]}
                    onPress={() => day && handleDaySelect(day)}
                    disabled={day === null}
                  >
                    {day !== null && (
                      <Text
                        style={[
                          styles.dayText,
                          isToday(day) && styles.todayText,
                          isSelected(day) && styles.selectedDayText,
                        ]}
                      >
                        {day}
                      </Text>
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </>
          )}

          {}
          {viewMode === "month" && (
            <View style={styles.monthsGrid}>
              {monthsShort.map((month, index) => (
                <TouchableOpacity
                  key={month}
                  style={[
                    styles.monthCell,
                    currentDate.getMonth() === index && styles.selectedMonth,
                  ]}
                  onPress={() => handleMonthSelect(index)}
                >
                  <Text
                    style={[
                      styles.monthText,
                      currentDate.getMonth() === index && styles.selectedMonthText,
                    ]}
                  >
                    {month}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {}
          {viewMode === "year" && (
            <ScrollView
              ref={yearScrollViewRef}
              style={styles.yearsScrollView}
              contentContainerStyle={styles.yearsScrollContentSingle}
              showsVerticalScrollIndicator={true}
              nestedScrollEnabled={true}
              persistentScrollbar={true}
            >
              {YEARS.map((year) => (
                <TouchableOpacity
                  key={year}
                  style={[
                    styles.yearCellSingle,
                    currentDate.getFullYear() === year && styles.selectedYearSingle,
                  ]}
                  onPress={() => handleYearSelect(year)}
                >
                  <Text
                    style={[
                      styles.yearTextSingle,
                      currentDate.getFullYear() === year && styles.selectedYearTextSingle,
                    ]}
                  >
                    {year}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          )}

          {}
          <TouchableOpacity style={styles.closeButton} onPress={onClose}>
            <Text style={styles.closeButtonText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  container: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 20,
    width: 320,
    maxHeight: "80%",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  headerCenter: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
  },
  headerText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#000000",
    minWidth: 50,
  },
  weekDays: {
    flexDirection: "row",
    marginBottom: 10,
  },
  weekDayText: {
    width: 40,
    textAlign: "center",
    fontSize: 12,
    fontWeight: "500",
    color: "rgba(0, 0, 0, 0.5)",
  },
  daysGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  dayCell: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 20,
  },
  emptyCell: {
    backgroundColor: "transparent",
  },
  selectedDay: {
    backgroundColor: "#4CAF50",
  },
  dayText: {
    fontSize: 16,
    color: "#000000",
  },
  todayText: {
    color: "#4CAF50",
    fontWeight: "600",
  },
  selectedDayText: {
    color: "#ffffff",
    fontWeight: "600",
  },
  monthsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  monthCell: {
    width: 70,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 12,
    backgroundColor: "rgba(240, 240, 240, 1)",
  },
  selectedMonth: {
    backgroundColor: "#4CAF50",
  },
  monthText: {
    fontSize: 14,
    color: "#000000",
  },
  selectedMonthText: {
    color: "#ffffff",
    fontWeight: "600",
  },
  yearsScrollView: {
    height: 300,
    width: "100%",
  },
  yearsScrollContent: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    paddingBottom: 10,
    paddingRight: 10,
  },
  yearsScrollContentSingle: {
    paddingVertical: 10,
    alignItems: "center",
  },
  yearsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  yearCell: {
    width: 70,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 12,
    backgroundColor: "rgba(240, 240, 240, 1)",
  },
  yearCellSingle: {
    width: 280,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 12,
    backgroundColor: "rgba(240, 240, 240, 1)",
    marginBottom: 8,
  },
  selectedYear: {
    backgroundColor: "#4CAF50",
  },
  selectedYearSingle: {
    backgroundColor: "#4CAF50",
  },
  yearText: {
    fontSize: 14,
    color: "#000000",
  },
  yearTextSingle: {
    fontSize: 18,
    color: "#000000",
    fontWeight: "500",
    textAlign: "center",
    width: "100%",
  },
  selectedYearText: {
    color: "#ffffff",
    fontWeight: "600",
  },
  selectedYearTextSingle: {
    color: "#ffffff",
    fontWeight: "600",
  },
  closeButton: {
    marginTop: 20,
    padding: 12,
    backgroundColor: "rgba(240, 240, 240, 1)",
    borderRadius: 12,
    alignItems: "center",
  },
  closeButtonText: {
    fontSize: 16,
    color: "#000000",
    fontWeight: "500",
  },
});
