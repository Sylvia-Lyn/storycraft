import i18n from '@/i18n';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

export type Language = 'zh' | 'en' | 'ja' | 'ko';

export const LANGUAGES = {
  'zh': { label: '简体中文', nativeLabel: '简体中文' },
  'en': { label: 'English', nativeLabel: 'English' },
  'ja': { label: '日本語', nativeLabel: '日本語' },
  'ko': { label: '한국어', nativeLabel: '한국어' },
} as const;

interface LanguageState {
  currentLanguage: Language;

  setLanguage: (language: Language) => Promise<void>;
  initLanguage: () => Promise<void>;
}

export const useLanguageStore = create<LanguageState>()(
  persist(
    (set, get) => ({
      currentLanguage: 'ja',

      setLanguage: async (language: Language) => {
        try {
          await i18n.changeLanguage(language);
          set({ currentLanguage: language });
        } catch (error) {
          console.error('Failed to change language:', error);
        }
      },

      initLanguage: async () => {
        try {
          const state = get();
          const language = state.currentLanguage || 'ja';
          await i18n.changeLanguage(language);
        } catch (error) {
          console.error('Failed to initialize language:', error);
          await i18n.changeLanguage('ja');
          set({ currentLanguage: 'ja' });
        }
      },
    }),
    {
      name: 'language-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
