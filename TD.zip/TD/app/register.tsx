import DatePicker from "@/components/DatePicker";
import { authService } from "@/services/authService";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function RegisterScreen() {
  const { t } = useTranslation();
  const [username, setUsername] = useState("");
  const [birthDate, setBirthDate] = useState<Date | undefined>(undefined);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const insets = useSafeAreaInsets();

  const validateForm = () => {
    if (!username.trim()) {
      Alert.alert(t("common.prompt"), t("auth.username"));
      return false;
    }

    if (!password) {
      Alert.alert(t("common.prompt"), t("auth.password"));
      return false;
    }

    if (password.length < 6) {
      Alert.alert(t("common.prompt"), "密码长度不能少于6位");
      return false;
    }

    if (password !== confirmPassword) {
      Alert.alert(t("common.prompt"), "两次输入的密码不一致");
      return false;
    }

    return true;
  };

  const handleRegister = async () => {
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const response = await authService.register({
        mobile:username,
        password,
        birthDate: birthDate?.toISOString(),
        language: "ja",
      });

      if (response.code === "0") {
        router.replace("/(tabs)/dream");
      } else {
        Alert.alert(t("auth.register"), response.msg || "请稍后重试");
      }
    } catch (error: any) {
      console.error("注册失败:", error);
      Alert.alert(
        t("auth.register"),
        error.message || "网络错误，请检查网络连接后重试"
      );
    } finally {
      setLoading(false);
    }
  };

  const handleDateSelect = (date: Date) => {
    setBirthDate(date);
    setShowDatePicker(false);
  };

  const formatDate = (date?: Date) => {
    if (!date) return "";
    const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    return `${
      months[date.getMonth()]
    } ${date.getDate()}, ${date.getFullYear()}`;
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
      keyboardVerticalOffset={0}
    >
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.content}>
          <View style={styles.formWrapper}>
            <View style={styles.header}>
              <TouchableOpacity
                onPress={() => router.back()}
                style={styles.backButton}
              >
                <Ionicons name="arrow-back" size={24} color="#000000" />
              </TouchableOpacity>
              <Text style={styles.title}>{t("auth.register")}</Text>
            </View>

            <View style={styles.form}>
              <View style={styles.inputContainer}>
                <Ionicons
                  name="person-outline"
                  size={20}
                  color="rgba(0, 0, 0, 0.5)"
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.input}
                  placeholder={t("auth.username")}
                  placeholderTextColor="rgba(0, 0, 0, 0.5)"
                  value={username}
                  onChangeText={setUsername}
                  autoCapitalize="none"
                />
              </View>

              <TouchableOpacity
                style={styles.inputContainer}
                onPress={() => setShowDatePicker(true)}
              >
                <Ionicons
                  name="calendar-outline"
                  size={20}
                  color="rgba(0, 0, 0, 0.5)"
                  style={styles.inputIcon}
                />
                <Text
                  style={[styles.input, !birthDate && styles.placeholderText]}
                >
                  {birthDate ? formatDate(birthDate) : t("auth.dateOfBirth")}
                </Text>
              </TouchableOpacity>

              <DatePicker
                visible={showDatePicker}
                onClose={() => setShowDatePicker(false)}
                onSelect={handleDateSelect}
                selectedDate={birthDate}
              />

              <View style={styles.inputContainer}>
                <Ionicons
                  name="lock-closed-outline"
                  size={20}
                  color="rgba(0, 0, 0, 0.5)"
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.input}
                  placeholder={t("auth.password")}
                  placeholderTextColor="rgba(0, 0, 0, 0.5)"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                />
                <TouchableOpacity
                  onPress={() => setShowPassword(!showPassword)}
                  style={styles.eyeIcon}
                >
                  <Ionicons
                    name={showPassword ? "eye-outline" : "eye-off-outline"}
                    size={20}
                    color="rgba(0, 0, 0, 0.5)"
                  />
                </TouchableOpacity>
              </View>

              <View style={styles.inputContainer}>
                <Ionicons
                  name="lock-closed-outline"
                  size={20}
                  color="rgba(0, 0, 0, 0.5)"
                  style={styles.inputIcon}
                />
                <TextInput
                  style={styles.input}
                  placeholder={t("auth.confirmPassword")}
                  placeholderTextColor="rgba(0, 0, 0, 0.5)"
                  value={confirmPassword}
                  onChangeText={setConfirmPassword}
                  secureTextEntry={!showConfirmPassword}
                />
                <TouchableOpacity
                  onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                  style={styles.eyeIcon}
                >
                  <Ionicons
                    name={
                      showConfirmPassword ? "eye-outline" : "eye-off-outline"
                    }
                    size={20}
                    color="rgba(0, 0, 0, 0.5)"
                  />
                </TouchableOpacity>
              </View>

              <TouchableOpacity
                style={styles.registerButton}
                onPress={handleRegister}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#ffffff" />
                ) : (
                  <Text style={styles.registerButtonText}>{t("auth.register")}</Text>
                )}
              </TouchableOpacity>

              {}
            </View>
          </View>

          <View
            style={{ ...styles.termsContainer, marginBottom: insets.bottom }}
          >
            <Text style={styles.termsText}>
              {t("auth.agreeToTerms")
                .split(/(\[.*?\])/)
                .filter((part) => part)
                .map((part, index) => {
                  const termsMatch = part.match(/\[(.*?)\]/);
                  if (termsMatch) {
                    const linkText = termsMatch[1];
                    return (
                      <Text
                        key={index}
                        style={styles.termsLink}
                        onPress={() => console.log(linkText)}
                      >
                        {linkText}
                      </Text>
                    );
                  }
                  return part;
                })}
            </Text>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ffffff",
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    minHeight: "100%",
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 60,
    justifyContent: "space-between",
  },
  formWrapper: {
    flex: 1,
  },
  header: {
    marginBottom: 18,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    marginBottom: 20,
    marginLeft: -8,
  },
  title: {
    fontSize: 34,
    fontWeight: "700",
    color: "#000000",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 17,
    color: "rgba(0, 0, 0, 0.63)",
  },
  form: {
    width: "100%",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(240, 240, 240, 1)",
    borderRadius: 16,
    marginBottom: 16,
    paddingHorizontal: 16,
    height: 56,
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: "#000000",
  },
  placeholderText: {
    color: "rgba(0, 0, 0, 0.5)",
  },
  eyeIcon: {
    padding: 4,
  },
  registerButton: {
    backgroundColor: "rgba(0, 0, 0, 1)",
    borderRadius: 16,
    height: 56,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 8,
    marginBottom: 24,
  },
  registerButtonText: {
    fontSize: 17,
    fontWeight: "600",
    color: "#ffffff",
  },
  loginContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 24,
  },
  loginText: {
    fontSize: 14,
    color: "rgba(0, 0, 0, 0.63)",
    marginRight: 4,
  },
  loginLink: {
    fontSize: 14,
    color: "#000000",
    fontWeight: "600",
  },
  termsContainer: {
    paddingHorizontal: 16,
  },
  termsText: {
    fontSize: 12,
    color: "rgba(0, 0, 0, 0.5)",
    textAlign: "center",
    lineHeight: 18,
  },
  termsLink: {
    color: "#000000",
    textDecorationLine: "underline",
    fontWeight: "500",
  },
});
