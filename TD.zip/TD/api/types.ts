// Auto-generated TypeScript types from Swagger

// Generic API Response wrapper
export interface ApiResponse<T> {
  code?: string;
  data?: T;
  msg?: string;
}

// Generic pagination wrapper
export interface IPage<T> {
  current?: number;
  pages?: number;
  records?: T[];
  searchCount?: boolean;
  size?: number;
  total?: number;
}

// Generic page query request
export interface PageQueryRequest<T> {
  pageIndex?: number;
  pageSize?: number;
  queryCount?: boolean;
  start?: number;
  startPos?: number;
}

export interface BranchOptionDTO {
  description?: string;
  id?: number;
  isPaid?: number;
  nextSegmentId?: number;
  segment?: SegmentDTO;
  segmentId?: number;
  title?: string;
}

export interface BranchOptionEntity {
  createdAt?: string;
  description?: string;
  id?: number;
  isPaid?: number;
  nextSegmentId?: number;
  segmentId?: number;
  sortOrder?: number;
  status?: number;
  title?: string;
  updatedAt?: string;
}

export interface DramaDTO {
  cover?: string;
  description?: string;
  id?: number;
  rootSegment?: SegmentDTO;
  title?: string;
}

export interface DramaEntity {
  cover?: string;
  createdAt?: string;
  description?: string;
  id?: number;
  rootSegmentId?: number;
  sortOrder?: number;
  status?: number;
  title?: string;
  updatedAt?: string;
}

export interface DramaSegmentDTO {
  cover?: string;
  description?: string;
  id?: number;
  rootSegment?: SegmentDTO;
  title?: string;
}

export interface LanguageDTO {
  // 语言代码
  code?: string;
  // 语言名称
  name?: string;
}

export interface LanguageForm {
  // 语言代码，支持zh(中文)和en(英文)
  language: string;
}

export interface LoginForm {
  // mobile or email
  mobile?: string;
  // password
  password?: string;
}

export interface RegisterForm {
  // birth date
  birthDate?: string;
  // email
  email?: string;
  // gender 0:unknown 1:male 2:female
  gender?: number;
  // language preference: zh or en
  language?: string;
  languageValid?: boolean;
  // mobile
  mobile?: string;
  mobileValid?: boolean;
  // password
  password?: string;
  // username
  username?: string;
}

export interface SegmentDTO {
  branchTrigger?: number;
  branches?: BranchOptionDTO[];
  defaultSegmentId?: number;
  id?: number;
  isEnd?: boolean;
  title?: string;
  url?: string;
}

export interface StreamParams {
  audioBitrate?: string;
  audioCodec?: string;
  bufSize?: string;
  format?: string;
  gop?: string;
  inputFile?: string;
  maxRate?: string;
  playlistName?: string;
  preset?: string;
  qualities?: VideoQuality[];
  rtmpUrl?: string;
  videoBitrate?: string;
  videoCodec?: string;
}

export interface UserEntity {
  // 头像URL
  avatarUrl?: string;
  // 出生日期
  birthDate?: string;
  // 创建时间
  createTime?: string;
  // 邮箱
  email?: string;
  // 性别：0未知 1男 2女
  gender?: number;
  // 语言偏好：zh中文 en英文
  language?: string;
  // 语言显示名称
  languageName?: string;
  // 最近登录IP
  lastLoginIp?: string;
  // 最近登录时间
  lastLoginTime?: string;
  // 手机号（密文存储）
  mobile?: string;
  // 用户昵称
  nickname?: string;
  // 明文手机号
  plainMobile?: string;
  // 账号状态：0禁用 1正常
  status?: number;
  // 更新时间
  updateTime?: string;
  // 用户ID
  userId?: number;
  // 用户名
  username?: string;
}

export interface UserUpdateForm {
  // 出生日期
  birthDate?: string;
  // 性别：0未知 1男 2女
  gender?: number;
  // 语言偏好：zh中文 en英文
  language?: string;
  // 用户昵称
  nickname?: string;
  // 用户名称
  username?: string;
}

export interface VideoQuality {
  bitrate?: string;
  gop?: string;
  height?: number;
  preset?: string;
  videoCodec?: string;
  width?: number;
}

export interface PlaybackProgressForm {
  choiceType: number;
  // 节点ID
  segmentId: string;
}
