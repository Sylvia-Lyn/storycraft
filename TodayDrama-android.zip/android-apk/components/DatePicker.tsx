import { Ionicons } from "@expo/vector-icons";
import { useEffect, useRef, useState } from "react";
import {
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

interface DatePickerProps {
  visible: boolean;
  onClose: () => void;
  onSelect: (date: Date) => void;
  selectedDate?: Date;
}

export default function DatePicker({
  visible,
  onClose,
  onSelect,
  selectedDate,
}: DatePickerProps) {
  const [currentDate, setCurrentDate] = useState(selectedDate || new Date());
  const [viewMode, setViewMode] = useState<"day" | "month" | "year">("day");
  const yearScrollViewRef = useRef<ScrollView>(null);

  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const monthsShort = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  const weekDays = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];

  useEffect(() => {
    if (viewMode === "year" && yearScrollViewRef.current) {
      const years = generateYears();
      const currentYear = currentDate.getFullYear();
      const yearIndex = years.indexOf(currentYear);

      if (yearIndex !== -1) {
        // 每个年份项高度50px + 间距8px = 58px
        // 滚动到选中年份，并让它居中显示（减去容器高度的一半）
        const scrollPosition = yearIndex * 58 - 150 + 25; // 150是容器高度的一半，25是年份项高度的一半

        setTimeout(() => {
          yearScrollViewRef.current?.scrollTo({
            y: Math.max(0, scrollPosition),
            animated: true,
          });
        }, 100);
      }
    }
  }, [viewMode]);

  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const generateCalendarDays = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);

    const days: (number | null)[] = [];

    for (let i = 0; i < firstDay; i++) {
      days.push(null);
    }

    for (let i = 1; i <= daysInMonth; i++) {
      days.push(i);
    }

    return days;
  };

  const handlePrevMonth = () => {
    const newDate = new Date(currentDate);
    newDate.setMonth(newDate.getMonth() - 1);
    setCurrentDate(newDate);
  };

  const handleNextMonth = () => {
    const newDate = new Date(currentDate);
    newDate.setMonth(newDate.getMonth() + 1);
    setCurrentDate(newDate);
  };

  const handlePrevYear = () => {
    const newDate = new Date(currentDate);
    newDate.setFullYear(newDate.getFullYear() - 1);
    setCurrentDate(newDate);
  };

  const handleNextYear = () => {
    const newDate = new Date(currentDate);
    newDate.setFullYear(newDate.getFullYear() + 1);
    setCurrentDate(newDate);
  };

  const handleDaySelect = (day: number) => {
    const newDate = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(),
      day
    );
    onSelect(newDate);
    onClose();
  };

  const handleMonthSelect = (monthIndex: number) => {
    const newDate = new Date(currentDate);
    newDate.setMonth(monthIndex);
    setCurrentDate(newDate);
    setViewMode("day");
  };

  const handleYearSelect = (year: number) => {
    const newDate = new Date(currentDate);
    newDate.setFullYear(year);
    setCurrentDate(newDate);
    setViewMode("month");
  };

  const generateYears = () => {
    const currentYear = new Date().getFullYear();
    const years: number[] = [];
    for (let i = currentYear; i >= currentYear - 100; i--) {
      years.push(i);
    }
    return years;
  };

  const isToday = (day: number) => {
    const today = new Date();
    return (
      day === today.getDate() &&
      currentDate.getMonth() === today.getMonth() &&
      currentDate.getFullYear() === today.getFullYear()
    );
  };

  const isSelected = (day: number) => {
    if (!selectedDate) return false;
    return (
      day === selectedDate.getDate() &&
      currentDate.getMonth() === selectedDate.getMonth() &&
      currentDate.getFullYear() === selectedDate.getFullYear()
    );
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity onPress={viewMode === "day" ? handlePrevMonth : handlePrevYear}>
              <Ionicons name="chevron-back" size={24} color="#000000" />
            </TouchableOpacity>

            <View style={styles.headerCenter}>
              <TouchableOpacity onPress={() => setViewMode("month")}>
                <Text style={styles.headerText}>
                  {months[currentDate.getMonth()]}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setViewMode("year")}>
                <Text style={styles.headerText}>
                  {currentDate.getFullYear()}
                </Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity onPress={viewMode === "day" ? handleNextMonth : handleNextYear}>
              <Ionicons name="chevron-forward" size={24} color="#000000" />
            </TouchableOpacity>
          </View>

          {/* Day View */}
          {viewMode === "day" && (
            <>
              <View style={styles.weekDays}>
                {weekDays.map((day) => (
                  <Text key={day} style={styles.weekDayText}>
                    {day}
                  </Text>
                ))}
              </View>

              <View style={styles.daysGrid}>
                {generateCalendarDays().map((day, index) => (
                  <TouchableOpacity
                    key={index}
                    style={[
                      styles.dayCell,
                      day === null && styles.emptyCell,
                      day !== null && isSelected(day) && styles.selectedDay,
                    ]}
                    onPress={() => day && handleDaySelect(day)}
                    disabled={day === null}
                  >
                    {day !== null && (
                      <Text
                        style={[
                          styles.dayText,
                          isToday(day) && styles.todayText,
                          isSelected(day) && styles.selectedDayText,
                        ]}
                      >
                        {day}
                      </Text>
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </>
          )}

          {/* Month View */}
          {viewMode === "month" && (
            <View style={styles.monthsGrid}>
              {monthsShort.map((month, index) => (
                <TouchableOpacity
                  key={month}
                  style={[
                    styles.monthCell,
                    currentDate.getMonth() === index && styles.selectedMonth,
                  ]}
                  onPress={() => handleMonthSelect(index)}
                >
                  <Text
                    style={[
                      styles.monthText,
                      currentDate.getMonth() === index && styles.selectedMonthText,
                    ]}
                  >
                    {month}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Year View */}
          {viewMode === "year" && (
            <ScrollView
              ref={yearScrollViewRef}
              style={styles.yearsScrollView}
              contentContainerStyle={styles.yearsScrollContentSingle}
              showsVerticalScrollIndicator={true}
              nestedScrollEnabled={true}
              persistentScrollbar={true}
            >
              {generateYears().map((year) => (
                <TouchableOpacity
                  key={year}
                  style={[
                    styles.yearCellSingle,
                    currentDate.getFullYear() === year && styles.selectedYearSingle,
                  ]}
                  onPress={() => handleYearSelect(year)}
                >
                  <Text
                    style={[
                      styles.yearTextSingle,
                      currentDate.getFullYear() === year && styles.selectedYearTextSingle,
                    ]}
                  >
                    {year}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          )}

          {/* Close Button */}
          <TouchableOpacity style={styles.closeButton} onPress={onClose}>
            <Text style={styles.closeButtonText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  container: {
    backgroundColor: "#ffffff",
    borderRadius: 20,
    padding: 20,
    width: 320,
    maxHeight: "80%",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  headerCenter: {
    flexDirection: "row",
    gap: 8,
  },
  headerText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#000000",
  },
  weekDays: {
    flexDirection: "row",
    marginBottom: 10,
  },
  weekDayText: {
    width: 40,
    textAlign: "center",
    fontSize: 12,
    fontWeight: "500",
    color: "rgba(0, 0, 0, 0.5)",
  },
  daysGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  dayCell: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 20,
  },
  emptyCell: {
    backgroundColor: "transparent",
  },
  selectedDay: {
    backgroundColor: "#4CAF50",
  },
  dayText: {
    fontSize: 16,
    color: "#000000",
  },
  todayText: {
    color: "#4CAF50",
    fontWeight: "600",
  },
  selectedDayText: {
    color: "#ffffff",
    fontWeight: "600",
  },
  monthsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  monthCell: {
    width: 70,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 12,
    backgroundColor: "rgba(240, 240, 240, 1)",
  },
  selectedMonth: {
    backgroundColor: "#4CAF50",
  },
  monthText: {
    fontSize: 14,
    color: "#000000",
  },
  selectedMonthText: {
    color: "#ffffff",
    fontWeight: "600",
  },
  yearsScrollView: {
    height: 300,
    width: "100%",
  },
  yearsScrollContent: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    paddingBottom: 10,
    paddingRight: 10,
  },
  yearsScrollContentSingle: {
    paddingVertical: 10,
    alignItems: "center",
  },
  yearsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  yearCell: {
    width: 70,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 12,
    backgroundColor: "rgba(240, 240, 240, 1)",
  },
  yearCellSingle: {
    width: "90%",
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 12,
    backgroundColor: "rgba(240, 240, 240, 1)",
    marginBottom: 8,
  },
  selectedYear: {
    backgroundColor: "#4CAF50",
  },
  selectedYearSingle: {
    backgroundColor: "#4CAF50",
  },
  yearText: {
    fontSize: 14,
    color: "#000000",
  },
  yearTextSingle: {
    fontSize: 18,
    color: "#000000",
    fontWeight: "500",
  },
  selectedYearText: {
    color: "#ffffff",
    fontWeight: "600",
  },
  selectedYearTextSingle: {
    color: "#ffffff",
    fontWeight: "600",
  },
  closeButton: {
    marginTop: 20,
    padding: 12,
    backgroundColor: "rgba(240, 240, 240, 1)",
    borderRadius: 12,
    alignItems: "center",
  },
  closeButtonText: {
    fontSize: 16,
    color: "#000000",
    fontWeight: "500",
  },
});
