const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');

// API 基础地址
const SWAGGER_URL = 'http://43.165.186.251:8080/tiktok-drama/v2/api-docs';
const OUTPUT_DIR = path.join(__dirname, '../api');

// 创建输出目录
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

// 获取 Swagger JSON
function fetchSwaggerJson(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;

    client.get(url, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (error) {
          reject(error);
        }
      });
    }).on('error', (error) => {
      reject(error);
    });
  });
}

// 清理类型名称，移除特殊字符并转换为有效的TypeScript标识符
function sanitizeTypeName(name) {
  if (!name) return 'any';

  // 处理泛型类型
  if (name.includes('«') && name.includes('»')) {
    // 例如: "IPage«DramaEntity»" -> "IPage<DramaEntity>"
    // 例如: "响应«string»" -> "ApiResponse<string>"
    // 例如: "响应«List«BranchOptionEntity»»" -> "ApiResponse<BranchOptionEntity[]>"
    let result = name;

    // 先处理 List«T» -> T[]
    result = result.replace(/List«([^»]+)»/g, '$1[]');

    // 再处理其他泛型类型
    result = result
      .replace(/响应«/g, 'ApiResponse<')
      .replace(/IPage«/g, 'IPage<')
      .replace(/Map«string,object»/g, 'Record<string, any>')
      .replace(/»/g, '>');

    // 处理嵌套泛型中的类型名
    result = result
      .replace(/DramaEntity/g, 'DramaEntity')
      .replace(/DramaSegmentDTO/g, 'DramaSegmentDTO')
      .replace(/BranchOptionEntity/g, 'BranchOptionEntity')
      .replace(/LanguageDTO/g, 'LanguageDTO')
      .replace(/BranchOptionDTO/g, 'BranchOptionDTO')
      .replace(/SegmentDTO/g, 'SegmentDTO')
      .replace(/UserEntity/g, 'UserEntity')
      .replace(/int>/g, 'number>')
      .replace(/string>/g, 'string>');

    return result;
  }

  // 替换特殊字符
  return name
    .replace(/播放进度表单/g, 'PlaybackProgressForm')
    .replace(/响应/g, 'ApiResponse')
    .replace(/int/g, 'number')
    .replace(/[^a-zA-Z0-9<>]/g, ''); // 保留 <> 用于泛型
}

// 将 Swagger 类型转换为 TypeScript 类型
function swaggerTypeToTS(property, definitions) {
  if (!property) return 'any';

  if (property.$ref) {
    const refName = property.$ref.split('/').pop();
    return sanitizeTypeName(refName);
  }

  if (property.type === 'array') {
    const itemType = swaggerTypeToTS(property.items, definitions);
    return `${itemType}[]`;
  }

  const typeMap = {
    'integer': 'number',
    'long': 'number',
    'float': 'number',
    'double': 'number',
    'string': 'string',
    'boolean': 'boolean',
    'object': 'any',
  };

  return typeMap[property.type] || 'any';
}

// 生成类型定义
function generateTypes(swagger) {
  let output = '// Auto-generated TypeScript types from Swagger\n\n';

  const definitions = swagger.definitions || {};

  // 先生成通用泛型类型
  output += `// Generic API Response wrapper\n`;
  output += `export interface ApiResponse<T> {\n`;
  output += `  code?: string;\n`;
  output += `  data?: T;\n`;
  output += `  msg?: string;\n`;
  output += `}\n\n`;

  output += `// Generic pagination wrapper\n`;
  output += `export interface IPage<T> {\n`;
  output += `  current?: number;\n`;
  output += `  pages?: number;\n`;
  output += `  records?: T[];\n`;
  output += `  searchCount?: boolean;\n`;
  output += `  size?: number;\n`;
  output += `  total?: number;\n`;
  output += `}\n\n`;

  output += `// Generic page query request\n`;
  output += `export interface PageQueryRequest<T> {\n`;
  output += `  pageIndex?: number;\n`;
  output += `  pageSize?: number;\n`;
  output += `  queryCount?: boolean;\n`;
  output += `  start?: number;\n`;
  output += `  startPos?: number;\n`;
  output += `}\n\n`;

  // 生成所有 model 类型
  Object.keys(definitions).forEach((name) => {
    // 跳过泛型类型定义（已经手动定义了）
    if (name.includes('«') || name.includes('响应') || name.includes('IPage') || name.includes('PageQueryRequest')) {
      return;
    }

    const model = definitions[name];
    const sanitizedName = sanitizeTypeName(name);
    output += `export interface ${sanitizedName} {\n`;

    const properties = model.properties || {};
    Object.keys(properties).forEach((propName) => {
      const prop = properties[propName];
      const required = model.required?.includes(propName) ? '' : '?';
      const type = swaggerTypeToTS(prop, definitions);
      const description = prop.description ? `  // ${prop.description}\n` : '';

      output += description;
      output += `  ${propName}${required}: ${type};\n`;
    });

    output += '}\n\n';
  });

  return output;
}

// 生成 API 请求函数
function generateApi(swagger) {
  const basePath = swagger.basePath || '';
  let output = `// Auto-generated API functions from Swagger\n\n`;
  output += `import { useAuthStore } from '../store/authStore';\n`;
  output += `import type {\n`;
  output += `  ApiResponse,\n`;
  output += `  IPage,\n`;
  output += `  PageQueryRequest,\n`;
  output += `  BranchOptionDTO,\n`;
  output += `  BranchOptionEntity,\n`;
  output += `  DramaDTO,\n`;
  output += `  DramaEntity,\n`;
  output += `  DramaSegmentDTO,\n`;
  output += `  LanguageDTO,\n`;
  output += `  LanguageForm,\n`;
  output += `  LoginForm,\n`;
  output += `  PlaybackProgressForm,\n`;
  output += `  RegisterForm,\n`;
  output += `  SegmentDTO,\n`;
  output += `  StreamParams,\n`;
  output += `  UserEntity,\n`;
  output += `  UserUpdateForm,\n`;
  output += `} from './types';\n\n`;

  output += `const BASE_URL = 'http://43.165.186.251:8080${basePath}';\n\n`;

  // 通用请求函数
  output += `async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = useAuthStore.getState().token;

  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: \`Bearer \${token}\` }),
    ...options.headers,
  };

  const response = await fetch(\`\${BASE_URL}\${path}\`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    throw new Error(\`API Error: \${response.statusText}\`);
  }

  return response.json();
}\n\n`;

  const paths = swagger.paths || {};
  const apiByTag = {};

  // 按 tag 分组 API
  Object.keys(paths).forEach((path) => {
    const pathItem = paths[path];

    Object.keys(pathItem).forEach((method) => {
      if (['get', 'post', 'put', 'delete', 'patch'].includes(method)) {
        const operation = pathItem[method];
        const tag = operation.tags?.[0] || 'default';

        if (!apiByTag[tag]) {
          apiByTag[tag] = [];
        }

        apiByTag[tag].push({
          path,
          method,
          operation,
        });
      }
    });
  });

  // 生成 API 类
  Object.keys(apiByTag).forEach((tag) => {
    // 清理tag名称，移除特殊字符
    const sanitizedTag = tag
      .replace(/剧集接口/g, 'Drama')
      .replace(/分支选项接口/g, 'BranchOption')
      .replace(/节点接口/g, 'Segment')
      .replace(/视频流媒体接口/g, 'Stream')
      .replace(/登录接口/g, 'Auth')
      .replace(/[^a-zA-Z0-9]/g, ''); // 移除所有非字母数字字符

    const className = sanitizedTag.charAt(0).toUpperCase() + sanitizedTag.slice(1) + 'Api';
    output += `export class ${className} {\n`;

    apiByTag[tag].forEach(({ path, method, operation }) => {
      const operationId = operation.operationId || `${method}${path.replace(/\//g, '_')}`;
      const summary = operation.summary || '';
      const params = operation.parameters || [];

      // 函数参数
      const funcParams = [];
      const pathParams = [];
      const queryParams = [];
      let bodyParam = null;

      params.forEach((param) => {
        if (param.in === 'path') {
          pathParams.push(param.name);
          funcParams.push(`${param.name}: ${swaggerTypeToTS(param, swagger.definitions)}`);
        } else if (param.in === 'query') {
          queryParams.push(param);
          const required = param.required ? '' : '?';
          funcParams.push(`${param.name}${required}: ${swaggerTypeToTS(param, swagger.definitions)}`);
        } else if (param.in === 'body') {
          bodyParam = param;
          const paramType = swaggerTypeToTS(param.schema, swagger.definitions);
          funcParams.push(`body: ${paramType}`);
        }
      });

      // 响应类型
      const response200 = operation.responses?.['200'];
      const responseType = response200?.schema
        ? swaggerTypeToTS(response200.schema, swagger.definitions)
        : 'any';

      output += `  /**\n   * ${summary}\n   */\n`;
      output += `  static async ${operationId}(${funcParams.join(', ')}): Promise<${responseType}> {\n`;

      // 构建路径
      let apiPath = path;
      pathParams.forEach((param) => {
        apiPath = apiPath.replace(`{${param}}`, `\${${param}}`);
      });
      output += `    let url = \`${apiPath}\`;\n`;

      // 添加查询参数
      if (queryParams.length > 0) {
        output += `    const params = new URLSearchParams();\n`;
        queryParams.forEach((param) => {
          const optional = param.required ? '' : `${param.name} && `;
          output += `    ${optional}params.append('${param.name}', String(${param.name}));\n`;
        });
        output += `    if (params.toString()) url += \`?\${params.toString()}\`;\n`;
      }

      // 请求配置
      const requestOptions = [`method: '${method.toUpperCase()}'`];
      if (bodyParam) {
        requestOptions.push('body: JSON.stringify(body)');
      }

      output += `    return request<${responseType}>(url, { ${requestOptions.join(', ')} });\n`;
      output += `  }\n\n`;
    });

    output += '}\n\n';
  });

  return output;
}

// 主函数
async function main() {
  try {
    console.log('Fetching Swagger documentation...');
    const swagger = await fetchSwaggerJson(SWAGGER_URL);

    console.log('Generating TypeScript types...');
    const types = generateTypes(swagger);
    fs.writeFileSync(path.join(OUTPUT_DIR, 'types.ts'), types);
    console.log('✓ Types generated: api/types.ts');

    console.log('Generating API functions...');
    const api = generateApi(swagger);
    // 最后一次清理，确保所有特殊字符都被替换
    const cleanedApi = api
      .replace(/«/g, '<')
      .replace(/»/g, '>');
    fs.writeFileSync(path.join(OUTPUT_DIR, 'index.ts'), cleanedApi);
    console.log('✓ API generated: api/index.ts');

    console.log('\n✅ All done! You can now import from:');
    console.log('  import { UserApi, AuthApi } from "@/api"');
    console.log('  import { User, LoginResponse } from "@/api/types"');
  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

main();
