import { Tabs } from "expo-router";
import { View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  console.log('insets.bottom',insets.bottom)
  return (
    <View style={{ flex: 1, backgroundColor: "#1c1c1c" }}>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarStyle: {
            display: 'none', // 隐藏默认的 tab bar
          },
        }}
      >
        <Tabs.Screen
          name="dream"
          options={{
            title: "叙梦",
          }}
        />
        <Tabs.Screen
          name="profile"
          options={{
            title: "我的",
          }}
        />
      </Tabs>
    </View>
  );
}
