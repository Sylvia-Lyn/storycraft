//
//  UserManager.swift
//  TodayDrama
//
//  Created by GH on 9/3/25.
//

import Foundation

@Observable
final class UserManager {
    private(set) var userSelf: User?
    private let filename = "user_self.json"
    
    init() {
        Task { await loadUser() }
    }
    
    func auth() {
        Network.post("user/userInfo") { data in
            guard let user = User(json: data) else { return }
            
            self.userSelf = user
            _ = try? FileSystem.save(user, to: self.filename, in: .applicationSupport)
            
            AppState.shared.showBoarding = false
            
            print("[UserManager] 已保存用户信息")
        }
    }
    
    func clearUser() async {
        userSelf = nil
        try? FileSystem.delete(filename, in: .applicationSupport)
        print("[UserManager] 已清空用户信息")
    }
    
    private func loadUser() async {
        if let loadedUser = try? FileSystem.load(User.self, from: filename, in: .applicationSupport) {
            self.userSelf = loadedUser
            print("[UserManager] 已加载用户信息")
        } else {
            self.userSelf = nil
            AppState.shared.showBoarding = true
            print("[UserManager] 无用户信息")
        }
    }
}
