//
//  DramaView.swift
//  TodayDrama
//
//  Created by GH on 9/4/25.
//

import SwiftUI

struct DramaView: View {
    var body: some View {
        NavigationView {
            VStack {
                Text("叙梦")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                Spacer()
            }
            .navigationTitle("叙梦")
        }
    }
}

#Preview {
    DramaView()
}
