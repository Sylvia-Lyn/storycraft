//
//  DramaManager.swift
//  TodayDrama
//
//  Created by GH on 9/15/25.
//

import Foundation
import AVFoundation

@Observable
final class DramaManager: Hashable {
    let drama: Drama
    var isActive: Bool = false
    
    var mainPlayerItem: AVPlayerItem?
    var branchItems: [Int: AVPlayerItem] = [:]
    var currentSegment: Segment
    
    init(drama: Drama) {
        self.drama = drama
        self.currentSegment = drama.rootSegment
    }
    
    deinit {
        mainPlayerItem = nil
        branchItems.removeAll()
    }
    
    func loadRoot() {
        if mainPlayerItem != nil { return }
        
        guard let url = URL(string: drama.rootSegment.url) else { return }
        let item = AVPlayerItem(url: url, preloadDuration: 3.0)
        mainPlayerItem = item
        branchItems[drama.rootSegment.id] = item
        print("[DramaManager] 加载 Drama: \(drama.title)")
    }
    
    func loadBranch() {
        func preload(_ seg: Segment) {
            seg.branches.forEach { branch in
                if branchItems[branch.id] == nil,
                   let url = URL(string: branch.url) {
                    branchItems[branch.id] = AVPlayerItem(url: url, preloadDuration: 2.0)
                    print("[DramaManager] 加载 Branch: \(branch.title)")
                }
                preload(branch)
            }
        }
        preload(currentSegment)
    }
    
    func switchToBranch(_ branch: Segment) -> AVPlayerItem? {
        currentSegment = branch
        
        guard let cached = branchItems[branch.id] else { return nil }
        
        print("[DramaManager] 使用缓存: \(branch.title)")
        return cached
    }
    
    func resetProgress() {
        mainPlayerItem?.seek(to: .zero, completionHandler: nil)
        currentSegment = drama.rootSegment
        print("[DramaManager] Reset Drama: \(drama.title)")
    }
    
    static func == (lhs: DramaManager, rhs: DramaManager) -> Bool {
        lhs.drama.id == rhs.drama.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(drama.id)
    }
}
