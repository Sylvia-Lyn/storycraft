import type { UserEntity } from '@/api/types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

export type User = UserEntity;

export interface LoginResponse {
  user: User;
  token: string;
  refreshToken?: string;
  expiresIn?: number;
}
export const appInit = 'init'
interface AuthState {
  user: User | null;
  token: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;

  login: (response: LoginResponse) => void;
  logout: () => void;
  updateUser: (user: Partial<User>) => void;
  setToken: (token: string) => void;
  setRefreshToken: (refreshToken: string) => void;
  initAuth: () => Promise<void>;
  checkAuthStatus: () => boolean;
  clearAuth: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      refreshToken: null,
      isAuthenticated: false,
      isLoading: false,

      login: (response: LoginResponse) => {
        set({
          user: response.user,
          token: response.token,
          refreshToken: response.refreshToken || null,
          isAuthenticated: true,
        });
      },

      logout: () => {
        set({
          user: null,
          token: null,
          refreshToken: null,
          isAuthenticated: false,
        });
      },

      updateUser: (updatedUser: Partial<User>) => {
        const currentUser = get().user;
        if (currentUser) {
          set({
            user: {
              ...currentUser,
              ...updatedUser,
            },
          });
        } else {
          set({
            user: updatedUser as User,
            isAuthenticated: true,
          });
        }
      },

      setToken: (token: string) => {
        set({ token });
      },

      setRefreshToken: (refreshToken: string) => {
        set({ refreshToken });
      },

      initAuth: async () => {
        set({ isLoading: true });
        try {
          const state = get();
          if (state.token && state.user) {
            set({ isAuthenticated: true });
          } else {
            set({ isAuthenticated: false });
          }
        } catch (error) {
          console.error('Failed to initialize auth:', error);
          set({ isAuthenticated: false });
        } finally {
          set({ isLoading: false });
        }
      },

      checkAuthStatus: () => {
        const state = get();
        return !!state.token && !!state.user;
      },

      clearAuth: () => {
        set({
          user: null,
          token: null,
          refreshToken: null,
          isAuthenticated: false,
        });
      },
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
