//
//  DramaFeedViewModel.swift
//  TodayDrama
//
//  Created by GH on 9/15/25.
//

import AVFoundation
import SwiftyJSON

@Observable
final class DramaFeedViewModel {
    var managers: [DramaManager] = []
    let player = AVPlayer()
    var currentDrama: Drama?
    private var statusObserver: NSKeyValueObservation?
    
    // 分页相关属性
    private var currentPage: Int = 1
    private var pageSize: Int = 5
    var isLoading: Bool = false
    private var hasMoreData: Bool = true
    
    init() { configureAudioSession() }
    deinit { cleanup() }
    
    // MARK: - 切换分支
    func switchToSegment(_ segment: Segment, in manager: DramaManager) {
        guard let newItem = manager.switchToBranch(segment) else { return }
        player.replaceCurrentItem(with: newItem)
        player.seek(to: .zero)
        player.play()
    }
    
    func activateDrama(_ drama: Drama) {
        guard drama.id != currentDrama?.id else { return }
        
        if let previousDrama = currentDrama,
           let previousManager = managers.first(where: { $0.drama.id == previousDrama.id })
        {
            player.pause()
            previousManager.resetProgress()
            print("[DramaFeedViewModel] 暂停并重置: \(previousDrama.title)")
        }
        
        guard let manager = managers.first(where: { $0.drama.id == drama.id }) else { return }
        
        currentDrama = drama
        manager.isActive = true
        manager.loadRoot()
        
        if let playerItem = manager.mainPlayerItem {
            player.replaceCurrentItem(with: playerItem)
            
            statusObserver?.invalidate()
            
            if playerItem.status == .readyToPlay {
                player.play()
                print("[DramaFeedViewModel] 立即播放: \(drama.title)")
            } else {
                print("[DramaFeedViewModel] 等待准备: \(drama.title)")
                statusObserver = playerItem.observe(\.status, options: [.new]) {
                    [weak self] item, _ in
                    if item.status == .readyToPlay {
                        self?.player.play()
                        print("[DramaFeedViewModel] 延迟播放: \(drama.title)")
                    } else if item.status == .failed {
                        print(
                            "[DramaFeedViewModel] 播放失败: \(item.error?.localizedDescription ?? "未知错误")"
                        )
                    }
                }
            }
        }
        
        for otherManager in managers where otherManager.drama.id != drama.id {
            otherManager.isActive = false
        }
        
        preloadNextVideo(currentDrama: drama)
    }
    
    private func preloadNextVideo(currentDrama: Drama) {
        guard let currentIndex = managers.firstIndex(where: { $0.drama.id == currentDrama.id }),
              currentIndex + 1 < managers.count
        else { return }
        
        let nextManager = managers[currentIndex + 1]
        nextManager.loadRoot()
        print("[DramaFeedViewModel] 预加载: \(nextManager.drama.title)")
    }
    
    func loadInitDramas() {
        currentPage = 1
        hasMoreData = true
        loadDramas(page: currentPage, isInitialLoad: true)
    }
    
    func loadMoreDramas() {
        guard !isLoading && hasMoreData else { return }
        currentPage += 1
        loadDramas(page: currentPage, isInitialLoad: false)
    }
    
    private func loadDramas(page: Int, isInitialLoad: Bool) {
        guard !isLoading else { return }
        
        isLoading = true
        print("[DramaFeedViewModel] 开始加载第 \(page) 页数据")
        
        Network.post("drama/segments", body: ["pageIndex": page, "pageSize": pageSize]) { data in
            guard let recordsArray = data["records"].array else {
                print("[DramaFeedViewModel] 解析 records 失败")
                self.isLoading = false
                return
            }
            
            // 检查是否还有更多数据
            if recordsArray.isEmpty {
                self.hasMoreData = false
                print("[DramaFeedViewModel] 没有更多数据了")
                self.isLoading = false
                return
            }
            
            let dramas = recordsArray.compactMap { dramaJSON -> Drama? in
                guard let id = dramaJSON["id"].int,
                      let title = dramaJSON["title"].string,
                      let rootSegmentJSON = dramaJSON["rootSegment"].dictionary
                else {
                    return nil
                }
                
                let description = dramaJSON["description"].string
                let cover = dramaJSON["cover"].string
                
                guard let rootSegment = self.parseSegment(from: JSON(rootSegmentJSON)) else {
                    return nil
                }
                
                return Drama(
                    id: id,
                    version: 1,
                    title: title,
                    description: description,
                    rootSegment: rootSegment,
                    cover: cover
                )
            }
            
            let newManagers = dramas.map { DramaManager(drama: $0) }
            
            if isInitialLoad {
                self.managers = newManagers
                print("[DramaFeedViewModel] 初始加载了 \(newManagers.count) 个剧集")
            } else {
                self.managers.append(contentsOf: newManagers)
                print("[DramaFeedViewModel] 追加加载了 \(newManagers.count) 个剧集，总计 \(self.managers.count) 个")
            }
            
            self.isLoading = false
        }
    }
    
    private func parseSegment(from json: JSON) -> Segment? {
        guard let id = json["id"].int,
              let title = json["title"].string,
              let url = json["url"].string
        else {
            return nil
        }
        
        let description = json["description"].string
        let isPaid = json["isPaid"].int ?? 0
        let branchTrigger = json["branchTrigger"].double ?? 0.0
        let defaultSegmentId = json["defaultSegmentId"].int
        let isEnd = json["isEnd"].bool ?? false
        
        let branches = json["branches"].array?.compactMap { branchJSON -> Segment? in
            guard let segmentJSON = branchJSON["segment"].dictionary,
                  let branchId = branchJSON["id"].int,
                  let branchTitle = branchJSON["title"].string,
                  let segment = parseSegment(from: JSON(segmentJSON))
            else {
                return nil
            }
            
            return Segment(
                id: branchId,
                title: branchTitle,
                url: segment.url,
                description: segment.description,
                isPaid: segment.isPaid,
                branchTrigger: segment.branchTrigger,
                defaultSegmentId: segment.defaultSegmentId,
                branches: segment.branches,
                isEnd: segment.isEnd
            )
        } ?? []
        
        return Segment(
            id: id,
            title: title,
            url: url,
            description: description,
            isPaid: isPaid,
            branchTrigger: branchTrigger,
            defaultSegmentId: defaultSegmentId,
            branches: branches,
            isEnd: isEnd
        )
    }
    
    private func configureAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("[DramaFeedViewModel] 音频会话配置失败: \(error)")
        }
    }
    
    func cleanup() {
        statusObserver?.invalidate()
        statusObserver = nil
        player.pause()
        player.replaceCurrentItem(with: nil)
        currentDrama = nil
        print("[DramaFeedViewModel] 已清空视频缓存")
    }
}
