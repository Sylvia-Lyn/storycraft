import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import {
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { authService } from "@/services/authService";

export default function LoginScreen() {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const insets = useSafeAreaInsets();

  const validateForm = () => {
    if (!phone.trim()) {
      Alert.alert("提示", "请输入手机号");
      return false;
    }

    const phoneRegex = /^1[3-9]\d{9}$/;
    if (!phoneRegex.test(phone)) {
      Alert.alert("提示", "请输入有效的手机号");
      return false;
    }

    if (!password) {
      Alert.alert("提示", "请输入密码");
      return false;
    }

    if (password.length < 6) {
      Alert.alert("提示", "密码长度不能少于6位");
      return false;
    }

    return true;
  };

  const handleLogin = async () => {
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const response = await authService.login({
        mobile: phone,
        password,
      });

      if (response.code === "0") {
        // 登录成功后跳转到 profile 页面
        router.replace("/(tabs)/profile");
      } else {
        Alert.alert("登录失败", response.msg || "请检查手机号和密码");
      }
    } catch (error: any) {
      console.error("登录失败:", error);
      Alert.alert(
        "登录失败",
        error.message || "网络错误，请检查网络连接后重试"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.outerContainer}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={styles.container}
        keyboardVerticalOffset={0}
      >
      <View style={styles.content}>
        <View style={{...styles.formWrapper, marginTop: insets.top}}>
          <View style={styles.header}>
            <TouchableOpacity
              onPress={() => {
                // 检查是否可以返回，如果不能则跳转到profile页面
                if (router.canGoBack()) {
                  router.back();
                } else {
                  router.replace("/(tabs)/profile");
                }
              }}
              style={styles.backButton}
            >
              <Ionicons name="arrow-back" size={24} color="#000000" />
            </TouchableOpacity>
            <Text style={styles.title}>登录</Text>
            <Text style={styles.subtitle}>登录以获得完整体验</Text>
          </View>

          <View style={styles.form}>
          <View style={styles.inputContainer}>
            <Ionicons
              name="call-outline"
              size={20}
              color="rgba(0, 0, 0, 0.5)"
              style={styles.inputIcon}
            />
            <TextInput
              style={styles.input}
              placeholder="手机号"
              placeholderTextColor="rgba(0, 0, 0, 0.5)"
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
              autoCapitalize="none"
            />
          </View>

          <View style={styles.inputContainer}>
            <Ionicons
              name="lock-closed-outline"
              size={20}
              color="rgba(0, 0, 0, 0.5)"
              style={styles.inputIcon}
            />
            <TextInput
              style={styles.input}
              placeholder="密码"
              placeholderTextColor="rgba(0, 0, 0, 0.5)"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
            />
            <TouchableOpacity
              onPress={() => setShowPassword(!showPassword)}
              style={styles.eyeIcon}
            >
              <Ionicons
                name={showPassword ? "eye-outline" : "eye-off-outline"}
                size={20}
                color="rgba(0, 0, 0, 0.5)"
              />
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={styles.forgotPassword} onPress={() => router.push("/register")}>
            <Text style={styles.forgotPasswordText}>注册</Text>
            <Ionicons name="arrow-forward" size={17} color="rgba(0, 0, 0, 1)" style={{ marginLeft: 4 }} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.loginButton}
            onPress={handleLogin}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#ffffff" />
            ) : (
              <Text style={styles.loginButtonText}>登录</Text>
            )}
          </TouchableOpacity>

          {/* <View style={styles.registerContainer}>
            <Text style={styles.registerText}>还没有账户？</Text>
            <TouchableOpacity onPress={() => router.push("/register")}>
              <Text style={styles.registerLink}>立即注册</Text>
            </TouchableOpacity>
          </View> */}
        </View>
        </View>

        <View style={{...styles.termsContainer,
          marginBottom:insets.bottom
        }}>
          <Text style={styles.termsText}>
            继续即代表你同意{" "}
            <Text style={styles.termsLink} onPress={() => console.log("用户协议")}>
              用户协议
            </Text>
            {" "}和{" "}
            <Text style={styles.termsLink} onPress={() => console.log("隐私政策")}>
              隐私政策
            </Text>
          </Text>
        </View>
      </View>
    </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  outerContainer: {
    flex: 1,
    backgroundColor: "#ffffff",
  },
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    justifyContent: "space-between",
  },
  formWrapper: {
    flexShrink: 0,
  },
  header: {
    marginBottom: 18,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    marginBottom: 20,
    marginLeft: -8,
  },
  title: {
    fontSize: 34,
    fontWeight: "700",
    color: "#000000",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 17,
    color: "rgba(0, 0, 0, 1)",
  },
  form: {
    width: "100%",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(240, 240, 240, 1)",
    borderRadius: 16,
    marginBottom: 16,
    paddingHorizontal: 16,
    height: 56,
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: "#000000",
  },
  eyeIcon: {
    padding: 4,
  },
  forgotPassword: {
    alignSelf: "flex-end",
    marginBottom: 24,
    flexDirection: "row",
    alignItems: "center",
  },
  forgotPasswordText: {
    fontSize: 17,
    color: "rgba(0, 0, 0, 1)",
  },
  loginButton: {
    backgroundColor: "rgba(0, 0, 0, 1)",
    borderRadius: 16,
    height: 56,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 24,
  },
  loginButtonText: {
    fontSize: 17,
    fontWeight: "600",
    color: "#ffffff",
  },
  registerContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  registerText: {
    fontSize: 14,
    color: "rgba(0, 0, 0, 0.63)",
    marginRight: 4,
  },
  registerLink: {
    fontSize: 14,
    color: "#4CAF50",
    fontWeight: "600",
  },
  termsContainer: {
    paddingHorizontal: 16,
    paddingBottom: 0,
  },
  termsText: {
    fontSize: 12,
    color: "rgba(0, 0, 0, 0.5)",
    textAlign: "center",
    lineHeight: 18,
  },
  termsLink: {
    color: "#000000",
    textDecorationLine: "underline",
    fontWeight: "500",
  },
});
