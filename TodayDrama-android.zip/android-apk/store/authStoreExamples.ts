// 在组件中使用 Auth Store 的示例

import { useAuthStore } from '@/store/authStore';

// 示例 1: 登录页面使用
export function LoginExample() {
  const login = useAuthStore((state) => state.login);

  const handleLogin = async (phone: string, password: string) => {
    try {
      // 调用登录 API
      const response = await fetch('YOUR_API_URL/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, password }),
      });

      const data = await response.json();

      // 使用 store 保存登录信息
      login({
        user: data.user,
        token: data.token,
        refreshToken: data.refreshToken,
      });

      // 导航到主页
      // router.push('/(tabs)/dream');
    } catch (error) {
      console.error('Login failed:', error);
    }
  };
}

// 示例 2: 注册页面使用
export function RegisterExample() {
  const login = useAuthStore((state) => state.login);

  const handleRegister = async (userData: any) => {
    try {
      // 调用注册 API
      const response = await fetch('YOUR_API_URL/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
      });

      const data = await response.json();

      // 注册成功后自动登录
      login({
        user: data.user,
        token: data.token,
      });

      // 导航到主页
      // router.push('/(tabs)/dream');
    } catch (error) {
      console.error('Register failed:', error);
    }
  };
}

// 示例 3: 获取当前用户信息
export function UserProfileExample() {
  const user = useAuthStore((state) => state.user);
  const updateUser = useAuthStore((state) => state.updateUser);

  const handleUpdateProfile = (newData: any) => {
    // 更新本地用户信息
    updateUser(newData);

    // 同时调用 API 更新服务器
    // await fetch('YOUR_API_URL/profile', { ... });
  };
}

// 示例 4: 登出
export function LogoutExample() {
  const logout = useAuthStore((state) => state.logout);

  const handleLogout = () => {
    logout();
    // router.push('/login');
  };
}

// 示例 5: 检查认证状态
export function AuthCheckExample() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const checkAuthStatus = useAuthStore((state) => state.checkAuthStatus);

  // 在组件挂载时检查
  useEffect(() => {
    if (!checkAuthStatus()) {
      // 未登录，跳转到登录页
      // router.push('/login');
    }
  }, []);
}

// 示例 6: 在 API 请求中使用 token
export function ApiRequestExample() {
  const token = useAuthStore((state) => state.token);

  const fetchUserData = async () => {
    const response = await fetch('YOUR_API_URL/user', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });

    return response.json();
  };
}

// 示例 7: 在 App 启动时初始化
export function AppInitExample() {
  const initAuth = useAuthStore((state) => state.initAuth);
  const isLoading = useAuthStore((state) => state.isLoading);

  useEffect(() => {
    initAuth();
  }, []);

  if (isLoading) {
    return <LoadingScreen />;
  }
}
