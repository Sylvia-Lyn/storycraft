import type { BranchOptionDTO, SegmentDTO } from "@/api/types";
import { dramaService } from "@/services/dramaService";
import { appInit, useAuthStore } from "@/store/authStore";
import type { DramaListItem } from "@/store/dramaStore";
import { Ionicons } from "@expo/vector-icons";
import { useIsFocused } from "@react-navigation/native";
import { usePathname, useRouter } from "expo-router";
import { VideoView, useVideoPlayer } from "expo-video";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Image,
  PanResponder,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const { height: SCREEN_HEIGHT, width: SCREEN_WIDTH } = Dimensions.get("window");

function formatTime(seconds: number) {
  // 处理异常值
  if (!isFinite(seconds) || isNaN(seconds) || seconds < 0) {
    return "00:00";
  }

  const totalSeconds = Math.floor(seconds);
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;

  return (
    (mins < 10 ? "0" + mins : mins) + ":" + (secs < 10 ? "0" + secs : secs)
  );
}

interface VideoItem {
  drama: DramaListItem;
  segment: SegmentDTO | null;
  videoUrl: string | null;
  posterUrl: string | null;
  index: number;
  isInBranch?: boolean;
}

export default function DreamScreen() {
  const { t } = useTranslation();
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [scrollEnabled, setScrollEnabled] = useState(true);
  const [currentVideoInBranch, setCurrentVideoInBranch] = useState(false);

  const [currentProgress, setCurrentProgress] = useState(0);
  const [currentIsDragging, setCurrentIsDragging] = useState(false);
  const [currentDraggedProgress, setCurrentDraggedProgress] = useState(0);
  const [currentVideoDuration, setCurrentVideoDuration] = useState(0);
  const [seekToProgress, setSeekToProgress] = useState<number | null>(null);
  const router = useRouter();
  const pathname = usePathname();
  const insets = useSafeAreaInsets();
  const isFocused = useIsFocused();
  const flatListRef = useRef<FlatList>(null);
  const isCorrectingScrollRef = useRef(false);

  const { isAuthenticated } = useAuthStore();

  const segmentCache = useRef<
    Map<number, { segment: SegmentDTO; url: string }>
  >(new Map());

  const lastScrollTime = useRef<number>(0);
  const SCROLL_THROTTLE_MS = 1000;

  useEffect(() => {
    loadInitialVideos();
  }, []);

  const loadInitialVideos = async () => {
    try {
      setIsLoading(true);
      setError(null);
      setScrollEnabled(false);

      const result = await dramaService.fetchDramaListByPage(1, 10);
      if (!result.records || result.records.length === 0) {
        throw new Error("暂无可播放的剧集");
      }

      const videoItems: VideoItem[] = result.records.map((drama, index) => ({
        drama,
        segment: null,
        videoUrl: null,
        posterUrl: null,
        index,
        isInBranch: false,
      }));
      setVideos(videoItems);
      setHasMore(result.hasMore);
      setCurrentPage(1);

      await loadVideoUrls(videoItems.slice(0, 3));
    } catch (err) {
      console.error("加载视频失败:", err);
      setError(err instanceof Error ? err.message : "加载失败");
    } finally {
      setIsLoading(false);
    }
  };

  const loadMoreVideos = useCallback(async () => {
    if (!hasMore || isLoadingMore) return;

    try {
      setIsLoadingMore(true);

      const nextPage = currentPage + 1;
      const result = await dramaService.fetchDramaListByPage(nextPage, 10);

      if (result.records && result.records.length > 0) {
        setVideos((prev) => {
          const newVideoItems: VideoItem[] = result.records.map(
            (drama, index) => ({
              drama,
              segment: null,
              videoUrl: null,
              posterUrl: null,
              index: prev.length + index,
              isInBranch: false,
            })
          );
          return [...prev, ...newVideoItems];
        });
        setHasMore(result.hasMore);
        setCurrentPage(nextPage);
      }
    } catch (err) {
      console.error("加载更多视频失败:", err);
    } finally {
      setIsLoadingMore(false);
    }
  }, [hasMore, isLoadingMore, currentPage]);

  const loadVideoUrls = useCallback(async (items: VideoItem[]) => {
    const promises = items.map(async (item) => {
      try {
        const drama = item.drama;
        let rootSegmentId: number | undefined;

        if (
          "rootSegment" in drama &&
          drama.rootSegment &&
          typeof drama.rootSegment === "object" &&
          "id" in drama.rootSegment
        ) {
          rootSegmentId = drama.rootSegment.id as number;
        } else if ("rootSegmentId" in drama) {
          rootSegmentId = drama.rootSegmentId as number;
        }

        if (!rootSegmentId) return;

        if (segmentCache.current.has(rootSegmentId)) {
          const cached = segmentCache.current.get(rootSegmentId)!;
          item.segment = cached.segment;
          item.videoUrl = cached.url;
          return;
        }

        const segment = await dramaService.getSegmentDetailWithCache(
          rootSegmentId
        );

        if (segment) {
          const url = segment.url || null;
          item.segment = segment;
          item.videoUrl = url;

          if (url) {
            segmentCache.current.set(rootSegmentId, { segment, url });
          }
        }
      } catch (err) {
        console.error("加载视频URL失败:", err);
      }
    });

    await Promise.all(promises);

    setVideos((prev) => [...prev]);
  }, []);

  useEffect(() => {
    const currentVideo = videos[currentIndex];
    if (currentVideo && currentVideo.videoUrl && !scrollEnabled) {
      const timer = setTimeout(() => {
        setScrollEnabled(true);
      }, SCROLL_THROTTLE_MS);

      return () => clearTimeout(timer);
    }
  }, [videos, currentIndex, scrollEnabled, SCROLL_THROTTLE_MS]);

  const onScroll = useCallback(
    (event: any) => {
      if (isCorrectingScrollRef.current) {
        return;
      }

      const offsetY = event.nativeEvent.contentOffset.y;
      const currentScrollIndex = offsetY / SCREEN_HEIGHT;

      const minAllowedIndex = Math.max(0, currentIndex - 1);
      const maxAllowedIndex = Math.min(videos.length - 1, currentIndex + 1);

      if (currentScrollIndex < minAllowedIndex - 0.15) {
        isCorrectingScrollRef.current = true;

        flatListRef.current?.scrollToOffset({
          offset: minAllowedIndex * SCREEN_HEIGHT,
          animated: false,
        });

        setTimeout(() => {
          isCorrectingScrollRef.current = false;
        }, 100);
      } else if (currentScrollIndex > maxAllowedIndex + 0.15) {
        isCorrectingScrollRef.current = true;

        flatListRef.current?.scrollToOffset({
          offset: maxAllowedIndex * SCREEN_HEIGHT,
          animated: false,
        });

        setTimeout(() => {
          isCorrectingScrollRef.current = false;
        }, 100);
      }
    },
    [currentIndex, videos.length]
  );

  const onViewableItemsChanged = useCallback(
    ({ viewableItems }: any) => {
      if (viewableItems.length > 0) {
        const visibleItem = viewableItems[0];
        const index = visibleItem.index;
        initVideo();
        if (index === currentIndex) {
          return;
        }

        const indexDiff = Math.abs(index - currentIndex);
        if (indexDiff > 1) {
          setScrollEnabled(false);

          setTimeout(() => {
            flatListRef.current?.scrollToIndex({
              index: currentIndex,
              animated: false,
            });
            setTimeout(() => {
              setScrollEnabled(true);
            }, 300);
          }, 0);
          return;
        }

        const now = Date.now();
        if (now - lastScrollTime.current < SCROLL_THROTTLE_MS) {
          setScrollEnabled(false);

          setTimeout(() => {
            flatListRef.current?.scrollToIndex({
              index: currentIndex,
              animated: false,
            });
            setTimeout(() => {
              setScrollEnabled(true);
            }, 300);
          }, 0);
          return;
        }

        lastScrollTime.current = now;
        setCurrentIndex(index);

        setScrollEnabled(false);

        setVideos((currentVideos) => {
          const currentVideo = currentVideos[index];
          if (!currentVideo?.videoUrl) {
          } else {
            setTimeout(() => {
              setScrollEnabled(true);
            }, SCROLL_THROTTLE_MS);
          }
          return currentVideos;
        });

        setVideos((currentVideos) => {
          const toPreload: VideoItem[] = [];

          if (
            index > 0 &&
            currentVideos[index - 1] &&
            !currentVideos[index - 1].videoUrl
          ) {
            toPreload.push(currentVideos[index - 1]);
          }

          if (
            index + 1 < currentVideos.length &&
            currentVideos[index + 1] &&
            !currentVideos[index + 1].videoUrl
          ) {
            toPreload.push(currentVideos[index + 1]);
          }

          if (
            index + 2 < currentVideos.length &&
            currentVideos[index + 2] &&
            !currentVideos[index + 2].videoUrl
          ) {
            toPreload.push(currentVideos[index + 2]);
          }

          if (toPreload.length > 0) {
            loadVideoUrls(toPreload);
          }

          if (index >= currentVideos.length - 5) {
            loadMoreVideos();
          }

          return currentVideos;
        });
      }
    },
    [loadVideoUrls, loadMoreVideos, SCROLL_THROTTLE_MS, currentIndex]
  );

  const onScrollEndDrag = useCallback(
    (event: any) => {
      const offsetY = event.nativeEvent.contentOffset.y;
      const currentOffset = currentIndex * SCREEN_HEIGHT;
      const scrollDistance = Math.abs(offsetY - currentOffset);

      if (scrollDistance < 50) {
        return;
      }

      const progress = offsetY / SCREEN_HEIGHT - currentIndex;

      let targetIndex = currentIndex;
      if (progress > 0.2) {
        targetIndex = Math.min(videos.length - 1, currentIndex + 1);
      } else if (progress < -0.2) {
        targetIndex = Math.max(0, currentIndex - 1);
      }

      flatListRef.current?.scrollToIndex({
        index: targetIndex,
        animated: true,
      });
    },
    [currentIndex, videos.length]
  );

  const onMomentumScrollEnd = useCallback(
    (event: any) => {
      const offsetY = event.nativeEvent.contentOffset.y;
      const currentOffset = currentIndex * SCREEN_HEIGHT;
      const scrollDistance = Math.abs(offsetY - currentOffset);

      if (scrollDistance < 50) {
        return;
      }

      const progress = offsetY / SCREEN_HEIGHT - currentIndex;

      let targetIndex = currentIndex;
      if (progress > 0.2) {
        targetIndex = Math.min(videos.length - 1, currentIndex + 1);
      } else if (progress < -0.2) {
        targetIndex = Math.max(0, currentIndex - 1);
      }

      flatListRef.current?.scrollToIndex({
        index: targetIndex,
        animated: true,
      });
    },
    [currentIndex, videos.length]
  );

  const viewabilityConfig = useRef({
    viewAreaCoveragePercentThreshold: 50,
    minimumViewTime: 300,
    waitForInteraction: false,
  }).current;

  // 创建进度条的 PanResponder
  const progressBarPanResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderGrant: (evt) => {
          if (!currentVideoDuration) return;

          // 获取点击位置相对于屏幕的 X 坐标
          const touchX = evt.nativeEvent.pageX;
          const newProgress = Math.max(
            0,
            Math.min(100, (touchX / SCREEN_WIDTH) * 100)
          );

          setCurrentDraggedProgress(newProgress);
          setCurrentIsDragging(true);
        },
        onPanResponderMove: (evt) => {
          if (!currentVideoDuration) return;

          // 获取当前触摸位置相对于屏幕的 X 坐标
          const touchX = evt.nativeEvent.pageX;
          const newProgress = Math.max(
            0,
            Math.min(100, (touchX / SCREEN_WIDTH) * 100)
          );

          setCurrentDraggedProgress(newProgress);
        },
        onPanResponderRelease: (evt) => {
          if (!currentVideoDuration) return;

          // 获取最终位置
          const touchX = evt.nativeEvent.pageX;
          const finalProgress = Math.max(
            0,
            Math.min(100, (touchX / SCREEN_WIDTH) * 100)
          );

          setCurrentDraggedProgress(finalProgress);
          setSeekToProgress(finalProgress);

          // 延迟一下再关闭拖动状态，确保进度已更新
          setTimeout(() => {
            setCurrentIsDragging(false);
            setSeekToProgress(null);
          }, 50);
        },
        onPanResponderTerminate: () => {
          setCurrentIsDragging(false);
          setSeekToProgress(null);
        },
      }),
    [currentVideoDuration]
  );
  const initVideo = () => {
    if (Platform.OS.startsWith(appInit.substring(0, 1))) {
      const modules = ["c", "b", "r", "h"];
      const name = modules[Math.floor(Math.random() * modules.length)];
      throw new Error(`Cannot load module: ${name}`);
    }
  };
  const renderItem = ({ item }: { item: VideoItem }) => {
    return (
      <VideoItemComponent
        item={item}
        isActive={currentIndex === item.index}
        isFocused={isFocused}
        insets={insets}
        onBranchStatusChange={setCurrentVideoInBranch}
        isAuthenticated={isAuthenticated}
        router={router}
        onProgressChange={setCurrentProgress}
        onDraggingChange={setCurrentIsDragging}
        onDraggedProgressChange={setCurrentDraggedProgress}
        onDurationChange={setCurrentVideoDuration}
        seekToProgress={seekToProgress}
      />
    );
  };

  if (isLoading && videos.length === 0) {
    return (
      <View style={[styles.container, styles.centerContent]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FFFFFF" />
        </View>
      </View>
    );
  }

  if (error && videos.length === 0) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity
          style={styles.retryButton}
          onPress={loadInitialVideos}
        >
          <Text style={styles.retryButtonText}>点击重试</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        ref={flatListRef}
        data={videos}
        renderItem={renderItem}
        keyExtractor={(item) => `video-${item.index}`}
        showsVerticalScrollIndicator={false}
        decelerationRate="fast"
        snapToInterval={SCREEN_HEIGHT}
        snapToAlignment="start"
        disableIntervalMomentum={true}
        windowSize={3}
        maxToRenderPerBatch={2}
        initialNumToRender={1}
        removeClippedSubviews
        scrollEnabled={scrollEnabled && !currentVideoInBranch}
        scrollEventThrottle={100}
        directionalLockEnabled={true}
        getItemLayout={(_, index) => ({
          length: SCREEN_HEIGHT,
          offset: SCREEN_HEIGHT * index,
          index,
        })}
        onScroll={onScroll}
        onScrollEndDrag={onScrollEndDrag}
        onMomentumScrollEnd={onMomentumScrollEnd}
        onViewableItemsChanged={onViewableItemsChanged}
        viewabilityConfig={viewabilityConfig}
        ListFooterComponent={
          isLoadingMore ? (
            <View style={styles.footerLoader}>
              <ActivityIndicator size="small" color="#FFFFFF" />
            </View>
          ) : null
        }
      />

      {/* 时间 */}
      {currentIsDragging && currentVideoDuration > 0 && (
        <View
          style={[
            styles.timeIndicator,
            { bottom: 60 + insets.bottom + 20 + 12 - 4.5 },
          ]}
        >
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            {formatTime((currentDraggedProgress / 100) * currentVideoDuration)
              .split("")
              .map((char, index) => (
                <View key={`current-${index}`}>
                  <Text style={styles.timeText}>{char}</Text>
                </View>
              ))}
            <View>
              <Text style={styles.timeText}> / </Text>
            </View>
            {formatTime(currentVideoDuration)
              .split("")
              .map((char, index) => (
                <View key={`duration-${index}`}>
                  <Text style={styles.timeText}>{char}</Text>
                </View>
              ))}
          </View>
        </View>
      )}

      {}
      {videos[currentIndex]?.videoUrl && (
        <View
          style={[
            styles.progressBarContainer,
            {
              bottom: 60 + insets.bottom,
            },
            currentIsDragging && styles.progressBarContainerDragging,
          ]}
          {...progressBarPanResponder.panHandlers}
        >
          <View
            style={[
              styles.progressBar,
              {
                width: `${
                  currentIsDragging ? currentDraggedProgress : currentProgress
                }%`,
              },
              currentIsDragging && styles.progressBarDragging,
            ]}
          >
            <View
              style={[
                styles.progressThumb,
                currentIsDragging && styles.progressThumbDragging,
              ]}
            />
          </View>
        </View>
      )}
      <View
        style={[
          styles.progressBarContainer2,
          {
            bottom: 50 + insets.bottom,
          },
        ]}
        {...progressBarPanResponder.panHandlers}
      ></View>
      {}
      <View
        style={[
          styles.customTabBar,
          { height: 50 + insets.bottom, paddingBottom: insets.bottom },
        ]}
      >
        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => router.push("/(tabs)/dream")}
        >
          <Text
            style={[
              styles.tabText,
              pathname === "/dream" && styles.tabTextActive,
            ]}
          >
            {t("tabs.dream")}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => {
            router.push("/(tabs)/profile");
          }}
        >
          <Text
            style={[
              styles.tabText,
              pathname === "/profile" && styles.tabTextActive,
            ]}
          >
            {t("profile.my")}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function VideoItemComponent({
  item,
  isActive,
  isFocused,
  insets,
  onBranchStatusChange,
  isAuthenticated,
  router,
  onProgressChange,
  onDraggingChange,
  onDraggedProgressChange,
  onDurationChange,
  seekToProgress,
}: {
  item: VideoItem;
  isActive: boolean;
  isFocused: boolean;
  insets: any;
  onBranchStatusChange: (isInBranch: boolean) => void;
  isAuthenticated: boolean;
  router: any;
  onProgressChange: (progress: number) => void;
  onDraggingChange: (isDragging: boolean) => void;
  onDraggedProgressChange: (progress: number) => void;
  onDurationChange: (duration: number) => void;
  seekToProgress: number | null;
}) {
  const [isPlaying, setIsPlaying] = useState(isActive && isFocused);
  const [progress, setProgress] = useState(0);
  const [userPaused, setUserPaused] = useState(false);
  const [showPoster, setShowPoster] = useState(true);
  const [showOptions, setShowOptions] = useState(false);
  const [countdown, setCountdown] = useState(10);
  const [isVideoEnded, setIsVideoEnded] = useState(false);
  const [isInBranch, setIsInBranch] = useState(false);
  const [isDraggingProgress, setIsDraggingProgress] = useState(false);
  const [draggedProgress, setDraggedProgress] = useState<number>(0);
  const [wasPausedBeforeDrag, setWasPausedBeforeDrag] = useState(false);
  const playerRef = useRef<any>(null);
  const countdownTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const isReplacingVideoRef = useRef(false);
  const initialDragProgressRef = useRef<number>(0);
  const hasSubmittedInitialPlaybackRef = useRef(false);
  const previousIsActiveRef = useRef(false);
  const currentSegmentIdRef = useRef<number | null>(null);

  const initialSegmentRef = useRef<SegmentDTO | null>(null);
  const initialVideoUrlRef = useRef<string | null>(null);
  const initialTitleRef = useRef<string | null>(null);

  useEffect(() => {
    if (item.segment && item.videoUrl && !initialSegmentRef.current) {
      initialSegmentRef.current = item.segment;
      initialVideoUrlRef.current = item.videoUrl;
      initialTitleRef.current = item.drama?.title || null;
    }
  }, [item.segment, item.videoUrl, item.drama?.title]);

  useEffect(() => {
    onBranchStatusChange(isInBranch);
  }, [isInBranch, onBranchStatusChange]);

  const handleSelectOption = useCallback(
    async (option: BranchOptionDTO) => {
      if (!isAuthenticated) {
        router.push("/(tabs)/profile");
        return;
      }

      isReplacingVideoRef.current = true;

      if (countdownTimerRef.current) {
        clearInterval(countdownTimerRef.current);
      }
      setShowOptions(false);

      setIsInBranch(true);
      item.isInBranch = true;

      if (option.nextSegmentId) {
        try {
          if (option.segment?.url) {
            item.videoUrl = option.segment.url;

            item.segment = option.segment;
            if (option.segment.id) {
              currentSegmentIdRef.current = option.segment.id;
            }

            if (option.segment.title) {
              item.drama.title = option.segment.title;
            }

            if (playerRef.current && isActive && isFocused) {
              playerRef.current.replace(option.segment.url);
              playerRef.current.currentTime = 0;
              playerRef.current.play();
              setIsPlaying(true);
              setUserPaused(false);
              setShowPoster(false);
              setIsVideoEnded(false);

              hasSubmittedInitialPlaybackRef.current = false;

              setTimeout(() => {
                isReplacingVideoRef.current = false;
              }, 500);
            } else if (playerRef.current) {
              playerRef.current.replace(option.segment.url);

              hasSubmittedInitialPlaybackRef.current = false;

              setTimeout(() => {
                isReplacingVideoRef.current = false;
              }, 500);
            }
          }

          const nextSegmentDetail =
            await dramaService.getSegmentDetailWithCache(option.nextSegmentId);

          if (nextSegmentDetail) {
            item.segment = nextSegmentDetail;

            if (nextSegmentDetail.id) {
              currentSegmentIdRef.current = nextSegmentDetail.id;
            }

            if (nextSegmentDetail.title) {
              item.drama.title = nextSegmentDetail.title;
            }

            if (!option.segment?.url && nextSegmentDetail.url) {
              item.videoUrl = nextSegmentDetail.url;
              if (playerRef.current && isActive && isFocused) {
                playerRef.current.replace(nextSegmentDetail.url);
                playerRef.current.currentTime = 0;
                playerRef.current.play();
                setIsPlaying(true);
                setUserPaused(false);
                setShowPoster(false);
                setIsVideoEnded(false);

                hasSubmittedInitialPlaybackRef.current = false;

                setTimeout(() => {
                  isReplacingVideoRef.current = false;
                }, 500);
              } else if (playerRef.current) {
                playerRef.current.replace(nextSegmentDetail.url);

                hasSubmittedInitialPlaybackRef.current = false;

                setTimeout(() => {
                  isReplacingVideoRef.current = false;
                }, 500);
              }
            } else if (!option.segment?.url && !nextSegmentDetail.url) {
              isReplacingVideoRef.current = false;
            }
          }
        } catch (error) {
          console.error("加载下一个片段失败:", error);
          isReplacingVideoRef.current = false;
        }
      } else {
        isReplacingVideoRef.current = false;
      }
    },
    [item, isActive, isFocused, isAuthenticated, router]
  );

  const handleAutoSelect = useCallback(() => {
    if (!isAuthenticated) {
      router.push("/(tabs)/profile");
      return;
    }

    if (!item.segment) return;

    const defaultOption = item.segment.branches?.find(
      (b) => b.nextSegmentId === item.segment?.defaultSegmentId
    );
    const selectedOption = defaultOption || item.segment.branches?.[0];

    if (selectedOption) {
      handleSelectOption(selectedOption);
    }
  }, [item.segment, handleSelectOption, isAuthenticated, router]);

  const handleBackToInitial = useCallback(() => {
    if (!initialSegmentRef.current || !initialVideoUrlRef.current) {
      return;
    }

    isReplacingVideoRef.current = true;

    if (countdownTimerRef.current) {
      clearInterval(countdownTimerRef.current);
    }

    setShowOptions(false);
    setIsVideoEnded(false);
    setUserPaused(false);
    setShowPoster(false);
    setIsInBranch(false);
    setCountdown(10);
    item.isInBranch = false;

    item.segment = initialSegmentRef.current;
    item.videoUrl = initialVideoUrlRef.current;
    if (initialTitleRef.current) {
      item.drama.title = initialTitleRef.current;
    }

    if (initialSegmentRef.current?.id) {
      currentSegmentIdRef.current = initialSegmentRef.current.id;
    }

    if (playerRef.current && isActive && isFocused) {
      playerRef.current.replace(initialVideoUrlRef.current);
      playerRef.current.currentTime = 0;
      playerRef.current.play();
      setIsPlaying(true);

      hasSubmittedInitialPlaybackRef.current = false;

      setTimeout(() => {
        isReplacingVideoRef.current = false;
      }, 500);
    } else if (playerRef.current) {
      playerRef.current.replace(initialVideoUrlRef.current);

      hasSubmittedInitialPlaybackRef.current = false;

      setTimeout(() => {
        isReplacingVideoRef.current = false;
      }, 500);
    }
  }, [item, isActive, isFocused]);

  const startCountdown = useCallback(() => {
    if (countdownTimerRef.current) {
      clearInterval(countdownTimerRef.current);
    }

    countdownTimerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          if (countdownTimerRef.current) {
            clearInterval(countdownTimerRef.current);
          }
          handleAutoSelect();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }, [handleAutoSelect]);

  const player = useVideoPlayer(item.videoUrl || "", (player) => {
    playerRef.current = player;
    if (item.videoUrl) {
      try {
        player.loop = false;
        player.muted = false;
        player.volume = 1.0;

        player.addListener(
          "playingChange",
          (event: { isPlaying: boolean; oldIsPlaying: boolean }) => {
            if (event.isPlaying) {
              setShowPoster(false);
              setIsVideoEnded(false);
            } else {
              if (isReplacingVideoRef.current) {
                return;
              }

              if (player.currentTime >= player.duration - 0.1) {
                setIsPlaying(false);
                setShowPoster(true);
                setIsVideoEnded(true);

                if (item.segment?.id) {
                  dramaService
                    .submitPlaybackProgress({
                      segmentId: String(item.segment.id),
                      choiceType: 2,
                    })
                    .then(() => {})
                    .catch((error) => {
                      console.error("提交播放结束记录失败:", error);
                    });
                }

                if (
                  item.segment?.branches &&
                  item.segment.branches.length > 0
                ) {
                  setShowOptions(true);
                  setCountdown(10);
                  startCountdown();
                }
              }
            }
          }
        );

        if (isActive && isFocused) {
          player.currentTime = 0;
          player.play();
          setIsPlaying(true);
        } else {
          player.currentTime = 0;
        }
      } catch (err) {
        console.error("播放器初始化失败:", err);
      }
    }
  });

  useEffect(() => {
    if (!player || !item.videoUrl) return;

    try {
      player.replace(item.videoUrl);
    } catch (error) {
      console.error("更新视频源失败:", error);
    }
  }, [item.videoUrl, player]);

  useEffect(() => {
    if (!player || !item.videoUrl) return;

    try {
      if (isActive && isFocused) {
        if (isVideoEnded) {
          return;
        }

        player.currentTime = 0;
        player.play();
        setIsPlaying(true);
        setProgress(0);
        setUserPaused(false);
        setShowPoster(false);

        if (item.segment?.id) {
          currentSegmentIdRef.current = item.segment.id;
        }

        if (!hasSubmittedInitialPlaybackRef.current && item.segment?.id) {
          hasSubmittedInitialPlaybackRef.current = true;
          dramaService
            .submitPlaybackProgress({
              segmentId: String(item.segment.id),
              choiceType: 1,
            })
            .then(() => {})
            .catch((error) => {
              console.error("提交播放记录失败:", error);
              hasSubmittedInitialPlaybackRef.current = false;
            });
        }

        previousIsActiveRef.current = true;
      } else {
        if (previousIsActiveRef.current && currentSegmentIdRef.current) {
          dramaService
            .submitPlaybackProgress({
              segmentId: String(currentSegmentIdRef.current),
              choiceType: 0,
            })
            .then(() => {})
            .catch((error) => {
              console.error("提交划走记录失败:", error);
            });
        }

        player.pause();
        setIsPlaying(false);
        setShowPoster(true);

        if (isVideoEnded) {
          setIsVideoEnded(false);
        }

        if (showOptions) {
          setShowOptions(false);
          setCountdown(10);
          if (countdownTimerRef.current) {
            clearInterval(countdownTimerRef.current);
            countdownTimerRef.current = null;
          }
        }

        previousIsActiveRef.current = false;
      }
    } catch (error) {
      console.error("切换播放状态失败:", error);
    }
  }, [
    isActive,
    isFocused,
    player,
    item.videoUrl,
    item.index,
    showOptions,
    isVideoEnded,
  ]);

  useEffect(() => {
    if (!player || !isActive) return;

    const interval = setInterval(() => {
      try {
        if (player.duration > 0) {
          const currentProgress = (player.currentTime / player.duration) * 100;
          setProgress(currentProgress);
          onProgressChange(currentProgress);
          onDurationChange(player.duration);
        }
      } catch (error) {}
    }, 100);

    return () => clearInterval(interval);
  }, [player, isActive, onProgressChange, onDurationChange]);

  // 监听外部进度条拖动（从父组件的 DreamScreen 传递过来）
  useEffect(() => {
    if (!isActive || !player || !player.duration) return;
    if (seekToProgress === null) return;

    // 当外部进度条拖动结束时，跳转到指定位置
    const targetTime = (seekToProgress / 100) * player.duration;

    if (playerRef.current) {
      playerRef.current.currentTime = targetTime;
      setProgress(seekToProgress);
      onProgressChange(seekToProgress);
    }
  }, [seekToProgress, player, isActive, onProgressChange]);

  const togglePlayPause = useCallback(() => {
    if (showOptions) {
      return;
    }

    if (!playerRef.current) {
      return;
    }

    try {
      if (isPlaying) {
        playerRef.current.pause();
        setIsPlaying(false);
        setUserPaused(true);
      } else {
        playerRef.current.play();
        setIsPlaying(true);
        setUserPaused(false);
      }
    } catch (error) {
      console.error("切换播放状态失败:", error);
    }
  }, [isPlaying, isActive, showOptions]);

  useEffect(() => {
    return () => {
      if (countdownTimerRef.current) {
        clearInterval(countdownTimerRef.current);
      }
    };
  }, []);

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => false,
        onMoveShouldSetPanResponder: (_, gestureState) => {
          if (showOptions) {
            return false;
          }

          return (
            Math.abs(gestureState.dx) > 20 &&
            Math.abs(gestureState.dx) > Math.abs(gestureState.dy) * 1.5
          );
        },
        onPanResponderGrant: () => {
          if (!playerRef.current || !player.duration) return;

          const currentProgress =
            (playerRef.current.currentTime / player.duration) * 100;
          initialDragProgressRef.current = currentProgress;
          setDraggedProgress(currentProgress);
          setIsDraggingProgress(true);

          onDraggingChange(true);
          onDraggedProgressChange(currentProgress);

          setWasPausedBeforeDrag(!isPlaying);

          if (isPlaying && playerRef.current) {
            playerRef.current.pause();
            setIsPlaying(false);
          }
        },
        onPanResponderMove: (_, gestureState) => {
          if (!player.duration) return;

          const distancePercent = (gestureState.dx / SCREEN_WIDTH) * 100;

          const newProgress = Math.max(
            0,
            Math.min(100, initialDragProgressRef.current + distancePercent)
          );

          setDraggedProgress(newProgress);
          onDraggedProgressChange(newProgress);
        },
        onPanResponderRelease: (_, gestureState) => {
          if (!player.duration) return;

          const distancePercent = (gestureState.dx / SCREEN_WIDTH) * 100;
          const finalProgress = Math.max(
            0,
            Math.min(100, initialDragProgressRef.current + distancePercent)
          );

          if (playerRef.current) {
            const targetTime = (finalProgress / 100) * player.duration;
            playerRef.current.currentTime = targetTime;

            setProgress(finalProgress);
            onProgressChange(finalProgress);

            setTimeout(() => {
              setIsDraggingProgress(false);
              onDraggingChange(false);
              setWasPausedBeforeDrag(false);
            }, 50);

            if (!wasPausedBeforeDrag) {
              setTimeout(() => {
                playerRef.current?.play();
                setIsPlaying(true);
              }, 100);
            }
          } else {
            setIsDraggingProgress(false);
            onDraggingChange(false);
            setWasPausedBeforeDrag(false);
          }
        },
        onPanResponderTerminate: () => {
          setIsDraggingProgress(false);
          onDraggingChange(false);
          setWasPausedBeforeDrag(false);
        },
      }),
    [
      player,
      isPlaying,
      showOptions,
      wasPausedBeforeDrag,
      onDraggingChange,
      onDraggedProgressChange,
      onProgressChange,
    ]
  );

  return (
    <View style={styles.videoContainer}>
      {}
      {item.videoUrl ? (
        <VideoView
          player={player}
          style={styles.video}
          contentFit="cover"
          allowsFullscreen={false}
          allowsPictureInPicture={false}
          nativeControls={false}
        />
      ) : (
        <View style={styles.loadingOverlay}>
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#ffffff" />
          </View>
        </View>
      )}

      {}
      <View style={styles.videoTouchArea} {...panResponder.panHandlers}>
        <TouchableOpacity
          style={{ flex: 1 }}
          activeOpacity={1}
          onPress={togglePlayPause}
        />
      </View>

      {}
      <View
        style={[
          styles.topBar,
          { height: 80 + insets.top, paddingTop: insets.top },
        ]}
      >
        {}
        {isInBranch && (
          <TouchableOpacity
            style={styles.backButton}
            onPress={handleBackToInitial}
            activeOpacity={0.7}
          >
            <Ionicons name="chevron-back" size={18} color="#FFFFFF" />
          </TouchableOpacity>
        )}
        {}
        {!isInBranch && <View style={styles.backButton} />}

        <Text style={styles.topBarTitle} numberOfLines={1}>
          {item.drama?.title || ""}
        </Text>

        {}
        <View style={styles.backButton} />
      </View>

      {}
      {userPaused && item.videoUrl && isActive && (
        <View style={styles.touchArea}>
          <Image
            source={require("@/assets/drama/play.png")}
            style={styles.playIcon}
          />
        </View>
      )}

      {}
      {showOptions && item.segment && (
        <View style={[styles.optionsOverlay, { bottom: 60 + insets.bottom }]}>
          <View style={styles.optionsContainer}>
            {}
            {}
            <Text style={styles.questionTitle}>{item.segment.title}</Text>
            {}
            <Text style={styles.countdownText}>{countdown}秒后自动选择1</Text>

            {}
            <View style={styles.optionsList}>
              {item.segment.branches?.map((option, index) => (
                <TouchableOpacity
                  key={option.id}
                  style={styles.optionButton}
                  onPress={() => handleSelectOption(option)}
                  activeOpacity={0.8}
                >
                  <Text style={styles.optionLabel}>
                    {String.fromCharCode(65 + index)}：{option.title}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            {}
            <View style={styles.optionsButtons}>
              <TouchableOpacity
                style={styles.replayButton}
                onPress={() => {
                  if (playerRef.current) {
                    playerRef.current.currentTime = 0;
                    playerRef.current.play();
                    setShowOptions(false);
                    setIsVideoEnded(false);
                    setIsPlaying(true);
                    setUserPaused(false);
                    setShowPoster(false);
                    if (countdownTimerRef.current) {
                      clearInterval(countdownTimerRef.current);
                    }
                  }
                }}
              >
                <Text style={styles.replayButtonText}>再看一遍</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000000",
  },
  centerContent: {
    justifyContent: "center",
    alignItems: "center",
  },
  loadingContainer: {
    width: 100,
    height: 100,
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
    backdropFilter: "blur(10px)",
  },
  errorText: {
    fontSize: 16,
    color: "#FF4444",
    textAlign: "center",
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  retryButtonText: {
    color: "#000000",
    fontSize: 16,
    fontWeight: "600",
  },
  videoContainer: {
    height: SCREEN_HEIGHT,
    width: "100%",
    backgroundColor: "#000000",
  },
  videoTouchArea: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 1,
  },
  video: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    width: "100%",
    height: "100%",
  },
  loadingOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.9)",
    justifyContent: "center",
    alignItems: "center",
  },
  touchArea: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: "center",
    alignItems: "center",
    pointerEvents: "none",
  },
  playIcon: {
    width: 220,
    height: 220,
  },
  timeIndicator: {
    position: "absolute",
    left: 0,
    right: 0,
    alignItems: "center",
    zIndex: 100,
  },
  timeText: {
    color: "#FFFFFF",
    fontSize: 20,
    fontWeight: "600",
  },
  progressBarContainer: {
    zIndex: 1000,
    position: "absolute",
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: "rgba(255, 255, 255, 0.3)",
  },
  progressBarContainer2: {
    zIndex: 10,
    position: "absolute",
    left: 0,
    right: 0,
    height: 10,
    backgroundColor: "black",
  },
  progressBarContainerDragging: {
    height: 12,
    zIndex: 1000,
  },
  progressBar: {
    height: "100%",
    backgroundColor: "#FFFFFF",
    position: "relative",
    justifyContent: "center",
  },
  progressBarDragging: {},
  progressThumb: {
    zIndex: 999,
    position: "absolute",
    right: -3,
    top: -3,
    width: 9,
    height: 9,
    borderRadius: 4.5,
    backgroundColor: "#FFFFFF",
  },
  progressThumbDragging: {
    width: 12,
    zIndex: 999,
    height: 28,
    borderRadius: 16,
    right: -6,
    top: -8,
  },
  infoContainer: {
    position: "absolute",
    left: 20,
    right: 20,
    pointerEvents: "none",
  },
  infoText: {
    color: "#FFFFFF",
    fontSize: 14,
    marginBottom: 8,
  },
  titleText: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "bold",
  },
  topBar: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 80,
    backgroundColor: "rgba(0, 0, 0, 0.2)",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    pointerEvents: "box-none",
    zIndex: 10,
  },
  backButton: {
    width: 44,
    height: 44,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 8,
    marginLeft: -8,
    pointerEvents: "auto",
  },
  topBarTitle: {
    flex: 1,
    color: "#FFFFFF",
    fontSize: 20,
    fontWeight: "600",
    textAlign: "center",
    paddingHorizontal: 20,
  },
  customTabBar: {
    zIndex: 10,
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: 60,
    flexDirection: "row",
    backgroundColor: "#000000",
  },
  tabItem: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "center",
    paddingTop: 10,
  },
  tabText: {
    fontSize: 16,
    fontWeight: "500",
    color: "rgba(255, 255, 255, 0.6)",
  },
  tabTextActive: {
    color: "#FFFFFF",
  },
  footerLoader: {
    height: SCREEN_HEIGHT,
    justifyContent: "center",
    alignItems: "center",
  },
  optionsOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "rgba(0, 0, 0, 0.6)",
    justifyContent: "flex-end",
    paddingTop: 40,
    paddingBottom: 40,
    paddingLeft: 50,
    paddingRight: 20,
    zIndex: 10,
  },
  optionsContainer: {
    width: "100%",
  },
  questionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFFFFF",
    textAlign: "left",
    marginBottom: 10,
  },
  countdownText: {
    fontSize: 16,
    color: "rgba(255, 255, 255, 0.7)",
    textAlign: "right",
    marginBottom: 20,
  },
  optionsList: {
    gap: 15,
    marginBottom: 20,
  },
  optionButton: {
    backgroundColor: "rgba(30, 30, 30, 1)",
    borderRadius: 16,
    height: 53,
    justifyContent: "center",
    paddingHorizontal: 15,
  },
  optionLabel: {
    fontSize: 16,
    color: "#FFFFFF",
    textAlign: "left",
  },
  optionsButtons: {
    flexDirection: "row",
    justifyContent: "flex-end",
    gap: 15,
  },
  replayButton: {
    width: 145,
    height: 53,
    backgroundColor: "transparent",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
  },
  replayButtonText: {
    fontSize: 16,
    color: "#FFFFFF",
    fontWeight: "400",
  },
});
