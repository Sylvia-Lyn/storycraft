//
//  AVPlayerItem+Extensions.swift
//  TodayDrama
//
//  Created by GH on 9/9/25.
//

import Foundation
import AVFoundation

extension AVPlayerItem {
    convenience init?(url: String, preloadDuration: TimeInterval) {
        guard let videoURL = URL(string: url) else { return nil }
        self.init(url: videoURL)
        self.preferredForwardBufferDuration = preloadDuration
    }
    
    convenience init(url: URL, preloadDuration: TimeInterval) {
        self.init(url: url)
        self.preferredForwardBufferDuration = preloadDuration
    }
}
