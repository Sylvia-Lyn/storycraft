//
//  TodayDramaApp.swift
//  TodayDrama
//
//  Created by GH on 9/3/25.
//

import SwiftUI

@main
struct TodayDramaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
