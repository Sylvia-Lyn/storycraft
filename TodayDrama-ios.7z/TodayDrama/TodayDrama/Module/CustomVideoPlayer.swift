//
//  CustomVideoPlayer.swift
//  TodayDrama
//
//  Created by GH on 9/15/25.
//

import AVKit
import SwiftUI

struct CustomVideoPlayer: UIViewControllerRepresentable {
    let player: AVPlayer
    
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        player.automaticallyWaitsToMinimizeStalling = false // 不等待足够缓冲就播放，降低启动延迟
        player.preventsDisplaySleepDuringVideoPlayback = true // 播放期间防止屏幕熄灭
        controller.player = player
        
        controller.showsPlaybackControls = false // 不显示系统自带的进度条、播放按钮等
        controller.exitsFullScreenWhenPlaybackEnds = false // 播放完不自动退出全屏
        controller.allowsPictureInPicturePlayback = false // 禁止小窗/画中画
        controller.view.isUserInteractionEnabled = false // 屏蔽用户点击、拖拽等手势
        controller.videoGravity = .resizeAspectFill // 视频填满容器，可能被裁剪
        controller.view.backgroundColor = .black
        
        return controller
    }
    
    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) {
        if uiViewController.player !== player {
            uiViewController.player = player
        }
        uiViewController.view.isUserInteractionEnabled = false
    }
}
