//
//  ContentView.swift
//  TodayDrama
//
//  Created by GH on 9/3/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        DramaFeedView()
    }
}

//struct ContentView: View {
//    @Bindable var app = AppState.shared
//    @State private var selectedTab: Tab = .drama
//    
//    enum Tab: CaseIterable, Identifiable {
//        var id: String { title }
//        
//        case drama
//        case chat
//        case discover
//        case profile
//        
//        var title: String {
//            switch self {
//            case .drama: return "叙梦"
//            case .chat: return "聊天"
//            case .discover: return "发现"
//            case .profile: return "我的"
//            }
//        }
//    }
//    
//    var body: some View {
//        ZStack {
//            Group {
//                switch selectedTab {
//                case .drama: DramaFeedView()
//                case .chat: ChatView()
//                case .discover: DiscoverView()
//                case .profile: ProfileView()
//                }
//            }
//            
//            VStack {
//                Spacer()
//                
//                HStack(spacing: 0) {
//                    ForEach(Tab.allCases) { tab in
//                        Text(tab.title)
//                            .bold(selectedTab == tab)
//                            .scaleEffect(selectedTab == tab ? 1.2 : 1.0)
//                            .foregroundStyle(textColor(for: tab))
//                            .frame(maxWidth: .infinity)
//                            .contentShape(.rect)
//                            .onTapGesture { selectedTab = tab }
//                    }
//                }
//                .animation(.easeInOut(duration: 0.2), value: selectedTab)
//                .padding(.horizontal, 16)
//                .padding(.top, 10)
//                .frame(height: 64, alignment: .top)
//                .background {
//                    Rectangle()
//                        .fill(selectedTab == .drama ? .black : Color(UIColor.systemBackground))
//                        .overlay(alignment: .top) {
//                            Rectangle()
//                                .fill(Color(UIColor.separator).opacity(selectedTab == .drama ? 0.1 : 0.3))
//                                .frame(height: 0.5)
//                        }
//                }
//            }
//            .ignoresSafeArea(edges: .bottom)
//        }
//        .sheet(isPresented: $app.showBoarding) {
//            BoardingView()
//        }
//    }
//    
//    private func textColor(for tab: Tab) -> Color {
//        let isSelected = selectedTab == tab
//        let isDramaMode = selectedTab == .drama
//        
//        if isDramaMode {
//            return isSelected ? .white : .white.opacity(0.6)
//        } else {
//            return isSelected ? .primary : .secondary
//        }
//    }
//}

#Preview {
    ContentView()
}
