//
//  VerificationView.swift
//  TodayDrama
//
//  Created by GH on 9/4/25.
//

import SwiftUI
import SwiftyJSON

struct VerificationView: View {
    let verificationId: String
//    let username: String 
    let password: String
    let identifier: String
    let type: IdentifierType
    
    /// 验证码长度
    let maxLength: Int = 6
    @State private var code: String = ""
    /// 震动次数
    @State private var shakes: CGFloat = 0
    /// 是否聚焦在输入框上
    @FocusState private var fieldFocused: Bool
    /// 动画命名空间
    @Namespace private var animation
    
    var body: some View {
        VStack(spacing: 28) {
            // MARK: - Title & Description
            VStack(spacing: 32) {
                switch type {
                case .email:
                    Image(systemName: "envelope.badge")
                        .font(.title)
                        .bold()
                case .phone:
                    Image(systemName: "message.badge")
                        .font(.title)
                        .bold()
                }
                
                // TODO: - 待换成 Identifier
                Text("验证码已发送至 \(identifier)")
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .font(.headline)
                
                Text("请输入 6 位数字验证码")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            
            // MARK: - Verification Code Input Box
            TextField("", text: $code)
                .onChange(of: code) { _, newValue in
                    let filtered = newValue.filter { "0123456789".contains($0) }
                    code = String(filtered.prefix(maxLength))
                    
                    if code.count == maxLength {
                        verifyCode()
                    }
                }
                .keyboardType(.numberPad)
                .textContentType(.oneTimeCode)
                .focused($fieldFocused)
                .frame(width: 0, height: 0)
                .onAppear { fieldFocused = true }
            
            HStack(spacing: 12) {
                ForEach(0..<maxLength, id: \.self) { index in
                    let selected = (index == code.count)
                    let isFilled = (index < code.count)
                    
                    RoundedRectangle(cornerRadius: 10)
                        .fill(.secondary.opacity(isFilled ? 0.25 : 0.1))
                        .frame(width: 48, height: 48)
                        .overlay {
                            if selected {
                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                    .stroke(Color.accentColor, lineWidth: 2)
                                    .matchedGeometryEffect(id: "VerifyCode", in: animation)
                            } else {
                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                    .stroke(Material.thin, lineWidth: 1.5)
                            }
                            
                            Text(code.count > index
                                 ? String(code[code.index(code.startIndex, offsetBy: index)])
                                 : "")
                            .font(.title3)
                            .fontWeight(.semibold)
                            .fontDesign(.monospaced)
                        }
                        .animation(.smooth(duration: 0.15), value: selected)
                        .onTapGesture { fieldFocused = true }
                }
            }
            .modifier(ShakeEffect(animatableData: shakes))
            
            // MARK: - Verify Button
            Button {
                verifyCode()
            } label: {
                Text("注册")
                    .font(.headline)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
            }
            .buttonStyle(.borderedProminent)
            .disabled(code.count < maxLength)
            .padding(.top, 32)
            
            Spacer()
            
            // MARK: - Send Again Button
            // TODO: - 未完成重新发送
//            HStack {
//                Text("没有收到验证码？")
//                
//                Button("重新发送") {
//                    
//                }
//                .foregroundStyle(.accent)
//                .font(.headline)
//                .buttonStyle(.plain)
//            }
//            .padding(.bottom, 20)
        }
        .padding(32)
    }
    
    private func verifyCode() {
        let body = [
            "verification_id": verificationId,
            "verification_code": code
        ]
        
        Network.post("/auth/v1/verification/verify", body: body) { data in
            print(data)
            guard let verificationToken = data["verification_token"].string else { return }
            
            var body = [
//                "username": username,
                "password": password,
                "verification_token":  verificationToken
            ]
            
            switch type {
            case .email:
                body["email"] = identifier
            case .phone:
                body["mobile"] = identifier
            }
            
            Network.post("", body: body) { json in
                
            }
            
//            Network.setToken(token)
//            AppState.shared.user.auth()
        } onFailure: {
            withAnimation(.spring) {
                self.shakes += 1
                self.code = ""
            }
        }
    }
    
    private func errorShake() {
        withAnimation(.default) {
            shakes += 1
        }
        
        Task {
            try await Task.sleep(for: .seconds(1.5))
            code.removeAll()
        }
    }
}

public struct ShakeEffect: GeometryEffect {
    /// 震动的幅度
    public var amount: CGFloat = 10
    /// 每单位时间的震动次数
    public var shakesPerUnit: CGFloat = 3
    /// 动画数据，用于控制动画进度
    public var animatableData: CGFloat
    
    /// 初始化 `ShakeEffect` 结构体
    /// - Parameters:
    ///   - amount: 震动的幅度，默认为 10
    ///   - shakesPerUnit: 每单位时间的震动次数，默认为 3
    ///   - animatableData: 动画数据，用于控制动画进度
    public init(amount: CGFloat = 10, shakesPerUnit: CGFloat = 3, animatableData: CGFloat) {
        self.amount = amount
        self.shakesPerUnit = shakesPerUnit
        self.animatableData = animatableData
    }
    
    /// 正弦抖动效果
    /// - Parameter size: 视图的大小
    /// - Returns: 投影变换，用于应用震动效果
    /// - Note: 只要在视图上加 `.modifier(ShakeEffect(animatableData: 变量))`，然后使用 `withAnimation` 改动这个变量，即可实现震动效果。
    public nonisolated func effectValue(size: CGSize) -> ProjectionTransform {
        return ProjectionTransform(CGAffineTransform(translationX: amount * sin(animatableData * .pi * shakesPerUnit), y: 0))
    }
}

#Preview {
    VerificationView(
        verificationId: "",
//        username: "",
        password: "",
        identifier: "",
        type: .phone
    )
}
