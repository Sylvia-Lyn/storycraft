import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import {
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { authService } from "@/services/authService";

export default function LoginScreen() {
  const { t } = useTranslation();
  const [account, setAccount] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const insets = useSafeAreaInsets();

  const validateForm = () => {
    if (!account.trim()) {
      Alert.alert(t("common.prompt"), t("auth.enterMobile"));
      return false;
    }

    if (!password) {
      Alert.alert(t("common.prompt"), t("auth.password"));
      return false;
    }

    if (password.length < 6) {
      Alert.alert(t("common.prompt"), "密码长度不能少于6位");
      return false;
    }

    return true;
  };

  const handleLogin = async () => {
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const response = await authService.login({
        mobile: account,
        password,
      });

      if (response.code === "0") {
        router.replace("/(tabs)/dream");
      } else {
        Alert.alert(t("auth.login"), response.msg || "请检查账号和密码");
      }
    } catch (error: any) {
      console.error("登录失败:", error);
      Alert.alert(
        t("auth.login"),
        error.message || "网络错误，请检查网络连接后重试"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.outerContainer}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={styles.container}
        keyboardVerticalOffset={0}
      >
      <View style={styles.content}>
        <View style={{...styles.formWrapper, marginTop: insets.top}}>
          <View style={styles.header}>
            <TouchableOpacity
              onPress={() => {
                if (router.canGoBack()) {
                  router.back();
                } else {
                  router.replace("/(tabs)/dream");
                }
              }}
              style={styles.backButton}
            >
              <Ionicons name="arrow-back" size={24} color="#000000" />
            </TouchableOpacity>
            <Text style={styles.title}>{t("auth.login")}</Text>
            <Text style={styles.subtitle}>{t("auth.loginForFullExperience")}</Text>
          </View>

          <View style={styles.form}>
          <View style={styles.inputContainer}>
            <Ionicons
              name="person-outline"
              size={20}
              color="rgba(0, 0, 0, 0.5)"
              style={styles.inputIcon}
            />
            <TextInput
              style={styles.input}
              placeholder={t("auth.username")}
              placeholderTextColor="rgba(0, 0, 0, 0.5)"
              value={account}
              onChangeText={setAccount}
              keyboardType="default"
              autoCapitalize="none"
            />
          </View>

          <View style={styles.inputContainer}>
            <Ionicons
              name="lock-closed-outline"
              size={20}
              color="rgba(0, 0, 0, 0.5)"
              style={styles.inputIcon}
            />
            <TextInput
              style={styles.input}
              placeholder={t("auth.password")}
              placeholderTextColor="rgba(0, 0, 0, 0.5)"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
            />
            <TouchableOpacity
              onPress={() => setShowPassword(!showPassword)}
              style={styles.eyeIcon}
            >
              <Ionicons
                name={showPassword ? "eye-outline" : "eye-off-outline"}
                size={20}
                color="rgba(0, 0, 0, 0.5)"
              />
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={styles.forgotPassword} onPress={() => router.push("/register")}>
            <Text style={styles.forgotPasswordText}>{t("auth.register")}</Text>
            <Ionicons name="arrow-forward" size={17} color="rgba(0, 0, 0, 1)" style={{ marginLeft: 4 }} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.loginButton}
            onPress={handleLogin}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#ffffff" />
            ) : (
              <Text style={styles.loginButtonText}>{t("auth.login")}</Text>
            )}
          </TouchableOpacity>

          {}
        </View>
        </View>

        <View style={{...styles.termsContainer,
          marginBottom:insets.bottom
        }}>
          <Text style={styles.termsText}>
            {t("auth.agreeToTerms")}
          </Text>
        </View>
      </View>
    </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  outerContainer: {
    flex: 1,
    backgroundColor: "#ffffff",
  },
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    justifyContent: "space-between",
  },
  formWrapper: {
    flexShrink: 0,
  },
  header: {
    marginBottom: 18,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: "center",
    marginBottom: 20,
    marginLeft: -8,
  },
  title: {
    fontSize: 34,
    fontWeight: "700",
    color: "#000000",
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 17,
    color: "rgba(0, 0, 0, 1)",
  },
  form: {
    width: "100%",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(240, 240, 240, 1)",
    borderRadius: 16,
    marginBottom: 16,
    paddingHorizontal: 16,
    height: 56,
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: "#000000",
  },
  eyeIcon: {
    padding: 4,
  },
  forgotPassword: {
    alignSelf: "flex-end",
    marginBottom: 24,
    flexDirection: "row",
    alignItems: "center",
  },
  forgotPasswordText: {
    fontSize: 17,
    color: "rgba(0, 0, 0, 1)",
  },
  loginButton: {
    backgroundColor: "rgba(0, 0, 0, 1)",
    borderRadius: 16,
    height: 56,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 24,
  },
  loginButtonText: {
    fontSize: 17,
    fontWeight: "600",
    color: "#ffffff",
  },
  registerContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  registerText: {
    fontSize: 14,
    color: "rgba(0, 0, 0, 0.63)",
    marginRight: 4,
  },
  registerLink: {
    fontSize: 14,
    color: "#4CAF50",
    fontWeight: "600",
  },
  termsContainer: {
    paddingHorizontal: 16,
    paddingBottom: 0,
  },
  termsText: {
    fontSize: 12,
    color: "rgba(0, 0, 0, 0.5)",
    textAlign: "center",
    lineHeight: 18,
  },
  termsLink: {
    color: "#000000",
    textDecorationLine: "underline",
    fontWeight: "500",
  },
});
