// Auto-generated API functions from Swagger

import { useAuthStore } from "../store/authStore";
import type {
  ApiResponse,
  BranchOptionDTO,
  BranchOptionEntity,
  DramaDTO,
  DramaEntity,
  DramaSegmentDTO,
  IPage,
  LanguageDTO,
  LanguageForm,
  LoginForm,
  PageQueryRequest,
  PlaybackProgressForm,
  RegisterForm,
  SegmentDTO,
  StreamParams,
  UserEntity,
  UserUpdateForm,
} from "./types";

// const BASE_URL = "http://18.183.126.169:8080/tiktok-drama";

const BASE_URL = "https://drama.storycraft.tech/tiktok-drama";
async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = useAuthStore.getState().token;

  const headers: HeadersInit = {
    "Content-Type": "application/json",
    ...(token && { token: `${token}` }),
    ...options.headers,
  };

  const response = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    throw new Error(`API Error: ${response.statusText}`);
  }

  return response.json();
}

export class DramaApi {
  /**
   * 剧集列表
   */
  static async listUsingPOST(
    body: PageQueryRequest<DramaEntity>,
    userId?: number,
    username?: string,
    mobile?: string,
    email?: string,
    password?: string,
    nickname?: string,
    avatarUrl?: string,
    gender?: number,
    birthDate?: string,
    status?: number,
    lastLoginTime?: string,
    lastLoginIp?: string,
    language?: string,
    createTime?: string,
    updateTime?: string
  ): Promise<ApiResponse<IPage<DramaEntity>>> {
    let url = `/api/drama/list`;
    const params = new URLSearchParams();
    userId && params.append("userId", String(userId));
    username && params.append("username", String(username));
    mobile && params.append("mobile", String(mobile));
    email && params.append("email", String(email));
    password && params.append("password", String(password));
    nickname && params.append("nickname", String(nickname));
    avatarUrl && params.append("avatarUrl", String(avatarUrl));
    gender && params.append("gender", String(gender));
    birthDate && params.append("birthDate", String(birthDate));
    status && params.append("status", String(status));
    lastLoginTime && params.append("lastLoginTime", String(lastLoginTime));
    lastLoginIp && params.append("lastLoginIp", String(lastLoginIp));
    language && params.append("language", String(language));
    createTime && params.append("createTime", String(createTime));
    updateTime && params.append("updateTime", String(updateTime));
    if (params.toString()) url += `?${params.toString()}`;
    return request<ApiResponse<IPage<DramaEntity>>>(url, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  /**
   * 剧集列表（包含节点信息）
   */
  static async listDramaSegmentsUsingPOST(
    body: PageQueryRequest<DramaEntity>,
    userId?: number,
    username?: string,
    mobile?: string,
    email?: string,
    password?: string,
    nickname?: string,
    avatarUrl?: string,
    gender?: number,
    birthDate?: string,
    status?: number,
    lastLoginTime?: string,
    lastLoginIp?: string,
    language?: string,
    createTime?: string,
    updateTime?: string
  ): Promise<ApiResponse<IPage<DramaSegmentDTO>>> {
    let url = `/api/drama/segments`;
    const params = new URLSearchParams();
    userId && params.append("userId", String(userId));
    username && params.append("username", String(username));
    mobile && params.append("mobile", String(mobile));
    email && params.append("email", String(email));
    password && params.append("password", String(password));
    nickname && params.append("nickname", String(nickname));
    avatarUrl && params.append("avatarUrl", String(avatarUrl));
    gender && params.append("gender", String(gender));
    birthDate && params.append("birthDate", String(birthDate));
    status && params.append("status", String(status));
    lastLoginTime && params.append("lastLoginTime", String(lastLoginTime));
    lastLoginIp && params.append("lastLoginIp", String(lastLoginIp));
    language && params.append("language", String(language));
    createTime && params.append("createTime", String(createTime));
    updateTime && params.append("updateTime", String(updateTime));
    if (params.toString()) url += `?${params.toString()}`;
    return request<ApiResponse<IPage<DramaSegmentDTO>>>(url, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  /**
   * 根据剧集ID获取根节点
   */
  static async getRootSegmentByDramaIdUsingGET(
    dramaId: number
  ): Promise<ApiResponse<SegmentDTO>> {
    let url = `/api/drama/${dramaId}/root`;
    return request<ApiResponse<SegmentDTO>>(url, { method: "GET" });
  }
}

export class BranchOptionApi {
  /**
   * 根据节点id获取选择
   */
  static async listBySegmentIdUsingGET(
    segmentId: number
  ): Promise<ApiResponse<BranchOptionEntity[]>> {
    let url = `/api/option/segment/${segmentId}`;
    return request<ApiResponse<BranchOptionEntity[]>>(url, { method: "GET" });
  }

  /**
   * 详情
   */
  static async infoUsingGET(id: number): Promise<ApiResponse<BranchOptionDTO>> {
    let url = `/api/option/${id}`;
    return request<ApiResponse<BranchOptionDTO>>(url, { method: "GET" });
  }
}

export class SegmentApi {
  /**
   * 获取指定剧集的完整信息
   */
  static async getDramaDetailUsingGET(
    dramaId: number
  ): Promise<ApiResponse<DramaDTO>> {
    let url = `/api/segment/drama/${dramaId}/root`;
    return request<ApiResponse<DramaDTO>>(url, { method: "GET" });
  }

  /**
   * 提交用户在某个节点的选择
   */
  static async submitPlaybackProgressUsingPOST(
    body: PlaybackProgressForm
  ): Promise<ApiResponse<string>> {
    let url = `/api/segment/playback-progress`;
    return request<ApiResponse<string>>(url, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  /**
   * 获取指定节点的信息
   */
  static async getSegmentUsingGET(
    segmentId: number
  ): Promise<ApiResponse<SegmentDTO>> {
    let url = `/api/segment/${segmentId}/detail`;
    return request<ApiResponse<SegmentDTO>>(url, { method: "GET" });
  }

  /**
   * 获取指定节点的详细信息
   */
  static async getSegmentDetailUsingGET(
    segmentId: number
  ): Promise<ApiResponse<SegmentDTO>> {
    let url = `/api/segment/${segmentId}/detail/branch`;
    return request<ApiResponse<SegmentDTO>>(url, { method: "GET" });
  }
}

export class StreamApi {
  /**
   * 多码率推流（同步）
   */
  static async streamMultiBitrateUsingPOST(body: StreamParams): Promise<any> {
    let url = `/api/stream/multi`;
    return request<any>(url, { method: "POST", body: JSON.stringify(body) });
  }

  /**
   * 多码率推流（异步）
   */
  static async streamMultiBitrateAsyncUsingPOST(
    body: StreamParams
  ): Promise<any> {
    let url = `/api/stream/multi/async`;
    return request<any>(url, { method: "POST", body: JSON.stringify(body) });
  }

  /**
   * 示例多码率推流
   */
  static async streamMultiBitrateExampleUsingPOST(
    inputFile: string
  ): Promise<any> {
    let url = `/api/stream/multi/example`;
    const params = new URLSearchParams();
    params.append("inputFile", String(inputFile));
    if (params.toString()) url += `?${params.toString()}`;
    return request<any>(url, { method: "POST" });
  }

  /**
   * 单码率推流（同步）
   */
  static async streamSingleBitrateUsingPOST(body: StreamParams): Promise<any> {
    let url = `/api/stream/single`;
    return request<any>(url, { method: "POST", body: JSON.stringify(body) });
  }

  /**
   * 单码率推流（异步）
   */
  static async streamSingleBitrateAsyncUsingPOST(
    body: StreamParams
  ): Promise<any> {
    let url = `/api/stream/single/async`;
    return request<any>(url, { method: "POST", body: JSON.stringify(body) });
  }

  /**
   * 示例单码率推流
   */
  static async streamSingleBitrateExampleUsingPOST(
    inputFile: string
  ): Promise<any> {
    let url = `/api/stream/single/example`;
    const params = new URLSearchParams();
    params.append("inputFile", String(inputFile));
    if (params.toString()) url += `?${params.toString()}`;
    return request<any>(url, { method: "POST" });
  }
}

export class AuthApi {
  /**
   * 获取支持的语言列表
   */
  static async getSupportedLanguagesUsingGET(): Promise<
    ApiResponse<LanguageDTO[]>
  > {
    let url = `/api/user/languages`;
    return request<ApiResponse<LanguageDTO[]>>(url, { method: "GET" });
  }

  /**
   * 登录
   */
  static async loginUsingPOST(
    body: LoginForm
  ): Promise<ApiResponse<Record<string, any>>> {
    let url = `/api/user/login`;
    return request<ApiResponse<Record<string, any>>>(url, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  /**
   * 退出
   */
  static async logoutUsingPOST(body: number): Promise<ApiResponse<string>> {
    let url = `/api/user/logout`;
    return request<ApiResponse<string>>(url, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  /**
   * 刷新token
   */
  static async refreshTokenUsingPOST(): Promise<
    ApiResponse<Record<string, any>>
  > {
    let url = `/api/user/refreshToken`;
    return request<ApiResponse<Record<string, any>>>(url, { method: "POST" });
  }

  /**
   * 注册
   */
  static async registerUsingPOST(
    body: RegisterForm
  ): Promise<ApiResponse<Record<string, any>>> {
    let url = `/api/user/register`;
    return request<ApiResponse<Record<string, any>>>(url, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  /**
   * 更新用户语言偏好
   */
  static async updateLanguageUsingPOST(
    body: LanguageForm
  ): Promise<ApiResponse<string>> {
    let url = `/api/user/updateLanguage`;
    return request<ApiResponse<string>>(url, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  /**
   * 更新用户信息
   */
  static async updateUserInfoUsingPOST(
    body: UserUpdateForm
  ): Promise<ApiResponse<string>> {
    let url = `/api/user/updateUserInfo`;
    return request<ApiResponse<string>>(url, {
      method: "POST",
      body: JSON.stringify(body),
    });
  }

  /**
   * 获取用户ID
   */
  static async userInfoUsingPOST(): Promise<ApiResponse<number>> {
    let url = `/api/user/userId`;
    return request<ApiResponse<number>>(url, { method: "POST" });
  }

  /**
   * 获取用户信息
   */
  static async userInfoUsingPOST_1(): Promise<{ data: UserEntity }> {
    let url = `/api/user/userInfo`;
    return request<{ data: UserEntity }>(url, { method: "POST" });
  }
}
