//
//  RegisterView.swift
//  TodayDrama
//
//  Created by GH on 9/4/25.
//

import SwiftUI
@preconcurrency import SwiftyJSON

struct RegisterView: View {
//    @State private var username: String = "Test"
    @State private var identifier: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""
    // TODO: - 待添加前缀功能
//    @State private var prefixCode: String = "+86"
    @State private var type: IdentifierType = .phone
    
    @State private var isAgeValid: Bool = false
    @State private var canRegister: Bool = false
    @State private var passwordMatch: Bool = true
    
//    @State private var verificationId: String?
    
    @Bindable private var app = AppState.shared
    @FocusState private var focusedField: Field?
    let toLogin: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("注册")
                .font(.largeTitle)
                .bold()
                .padding(.top, 12)
            
//            TextField("请输入昵称", text: $username)
//                .textFieldStyle(.roundedBorder)
//                .textContentType(.nickname)
//                .focused($focusedField, equals: .username)
            
            IdentifierInputView(identifier: $identifier, type: type)
            // TODO: - 待添加前缀功能
//            IdentifierInputView(identifier: $identifier, prefixCode: $prefixCode, type: type)
                .focused($focusedField, equals: .identifier)
            
            SecureField("密码", text: $password)
                .textFieldStyle(.roundedBorder)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .focused($focusedField, equals: .password)
            
            VStack(alignment: .leading, spacing: 4) {
                SecureField("确认密码", text: $confirmPassword)
                    .textFieldStyle(.roundedBorder)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .focused($focusedField, equals: .confirmPassword)
                
                if !passwordMatch {
                    Text("两次输入的密码不一致")
                        .font(.caption)
                        .foregroundStyle(.red)
                }
            }
            
            Toggle("我已满 17 岁", isOn: $isAgeValid)
                .toggleStyle(CheckboxToggleStyle())
                .font(.callout)
            
            Spacer()
                .frame(height: 30)
            
            HStack {
                // TODO: - 邮箱注册功能
//                Button(type.switchButtonText) {
//                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
//                    
//                    withAnimation(.spring) {
//                        type = type == .email ? .phone : .email
//                    }
//                    
//                    identifier.removeAll()
//                }
//                .buttonStyle(.plain)
                
                Spacer()
                
                Button {
                    toLogin()
                } label: {
                    Text("已有账号")
                        .font(.headline)
                    
                    Image(systemName: "arrow.right")
                }
                .buttonStyle(.plain)
            }
            
            Button {
                register()
            } label: {
                Text("注册")
                    .font(.headline)
                    .kerning(canRegister ? 3 : 1)
                    .fontWeight(canRegister ? .semibold : .medium)
                    .foregroundStyle(.background)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 11)
                    .background(.foreground, in: .rect(cornerRadius: 8))
            }
            .buttonBorderShape(.roundedRectangle(radius: 8))
            .buttonStyle(.plain)
            .disabled(!canRegister)
            
            TermsView()
            
            Spacer()
        }
        .onChange(of: identifier) { validateInputs() }
        .onChange(of: password) { validateInputs() }
        .onChange(of: confirmPassword) { validateInputs() }
//        .onChange(of: username) { validateInputs() }
        .onChange(of: isAgeValid) { validateInputs() }
        .onChange(of: type) { validateInputs() }
        .onAppear { validateInputs() }
//        .navigationDestination(item: $verificationId) { verificationId in
//            VerificationView(
//                verificationId: verificationId,
////                username: username,
//                password: password,
//                identifier: identifier,
//                // TODO: - 待添加前缀功能
////                identifier: type == .phone ? "\(prefixCode) \(identifier)" : identifier,
//                type: type
//            )
//        }
        .padding(24)
    }
    
    private enum Field: Hashable {
//        case username
        case identifier
        case password
        case confirmPassword
    }
    
    private func register() {
        guard canRegister else { return }
        
        var body = ["password": password]
        
        if type == .phone {
            // TODO: - 待添加前缀功能
//            body["mobile"] = "\(prefixCode) \(identifier)"
            body["mobile"] = identifier
        } else {
            body["email"] = identifier
        }
        
        let data = JSON(body)
        
        Network.post("user/register", body: data) { data in
            guard let token = data["token"].string else { return }
            Network.setToken(token)
            
            AppState.shared.user.auth()
            
//            verificationId = data["verification_id"].string
        }
    }
    
    private func validateInputs() {
        let isPasswordValid = password.count >= 8
        passwordMatch = password == confirmPassword || confirmPassword.isEmpty
        
        var isIdentifierValid = false
        if let regex = try? NSRegularExpression(pattern: type.regexPattern) {
            let range = NSRange(identifier.startIndex..<identifier.endIndex, in: identifier)
            isIdentifierValid = regex.firstMatch(in: identifier, range: range) != nil
        }
        
//        let isDisplayNameValid = username.count >= 2
        
        withAnimation(.spring(duration: 0.25)) {
            canRegister = isPasswordValid &&
                           passwordMatch &&
                           isAgeValid &&
                           isIdentifierValid &&
//                           isDisplayNameValid &&
                           !confirmPassword.isEmpty
        }
    }
}

struct CheckboxToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack {
            Image(systemName: configuration.isOn ? "checkmark.square.fill" : "square")
                .foregroundStyle(configuration.isOn ? .accent : .secondary)
                .font(.title3)
            
            configuration.label
        }
        .onTapGesture { configuration.isOn.toggle() }
    }
}

#Preview {
    NavigationStack {
        RegisterView {}
    }
}
