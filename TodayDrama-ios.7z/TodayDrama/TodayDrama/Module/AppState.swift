//
//  AppState.swift
//  TodayDrama
//
//  Created by GH on 9/3/25.
//

import Foundation

@Observable
final class AppState {
    static let shared = AppState()
    private init() {}
    
    var showBoarding: Bool = false
    
    let user = UserManager()
    
    func logout() {
        Keychain.delete("token")
        Task {
            await user.clearUser()
            print("[AppState] 已登出并清理所有数据")
        }
    }
}
