import { AuthApi } from "@/api";
import type { LoginForm, RegisterForm, UserUpdateForm } from "@/api/types";
import { useAuthStore } from "@/store/authStore";
import { useLanguageStore } from "@/store/languageStore";

export const authService = {
  
  async login(loginData: LoginForm) {
    const response = await AuthApi.loginUsingPOST(loginData);


    if (response.data) {
      const { token, refreshToken, ...userData } = response.data;


      useAuthStore.getState().login({
        user: userData as any,
        token: token as string,
        refreshToken: refreshToken as string,
      });


      try {
        await this.getUserInfo();

        // 同步用户的语言设置到 languageStore
        const user = useAuthStore.getState().user;
        if (user?.language) {
          await useLanguageStore.getState().setLanguage(user.language as any);
        }
      } catch (error) {
        console.error("获取用户信息失败:", error);
      }
    }

    return response;
  },

  
  async register(registerData: RegisterForm) {
    const response = await AuthApi.registerUsingPOST(registerData);


    if (response.data) {
      const { token, refreshToken, ...userData } = response.data;


      useAuthStore.getState().login({
        user: userData as any,
        token: token as string,
        refreshToken: refreshToken as string,
      });


      try {
        await this.getUserInfo();

        // 同步用户的语言设置到 languageStore
        const user = useAuthStore.getState().user;
        if (user?.language) {
          await useLanguageStore.getState().setLanguage(user.language as any);
        }
      } catch (error) {
        console.error("获取用户信息失败:", error);
      }
    }

    return response;
  },

  
  async logout() {
    const userId = useAuthStore.getState().user?.userId;

    try {
      if (userId) {
        await AuthApi.logoutUsingPOST(userId);
      }
    } catch (error) {
      console.error("调用登出API失败:", error);
    }

    try {
      await useLanguageStore.getState().setLanguage('ja');
    } catch (error) {
      console.error("重置语言失败:", error);
    }

    useAuthStore.getState().logout();
  },

  
  async refreshToken() {
    const response = await AuthApi.refreshTokenUsingPOST();

    if (response.data) {
      const { token, refreshToken } = response.data;
      const currentUser = useAuthStore.getState().user;

      if (currentUser) {
        useAuthStore.getState().login({
          user: currentUser,
          token: token as string,
          refreshToken: refreshToken as string,
        });
      }
    }

    return response;
  },


  async getUserInfo() {
    const response = await AuthApi.userInfoUsingPOST_1();

    if (response.data) {

      useAuthStore.getState().updateUser(response.data);

      // 同步用户的语言设置到 languageStore
      if (response.data.language) {
        await useLanguageStore.getState().setLanguage(response.data.language as any);
      }
    } else {
    }

    return response.data;
  },

  
  async updateUserInfo(updateData: UserUpdateForm) {
    const response = await AuthApi.updateUserInfoUsingPOST(updateData);

    if (response.code === "0") {
      await this.getUserInfo();
    }

    return response;
  },


  async updateLanguage(language: string) {
    const response = await AuthApi.updateLanguageUsingPOST({ language });

    if (response.code === "0") {
      await this.getUserInfo();
      // 同步更新 languageStore
      await useLanguageStore.getState().setLanguage(language as any);
    }

    return response;
  },

  
  async getSupportedLanguages() {
    const response = await AuthApi.getSupportedLanguagesUsingGET();
    return response.data || [];
  },

  
  async getUserId() {
    const response = await AuthApi.userInfoUsingPOST();
    return response.data;
  },
};
