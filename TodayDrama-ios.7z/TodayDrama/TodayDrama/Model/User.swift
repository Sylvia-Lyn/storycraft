//
//  User.swift
//  TodayDrama
//
//  Created by GH on 9/3/25.
//

import Foundation
import SwiftyJSON

struct User: Identifiable, Codable {
    let id: Int
    let username: String
    let avatar: String?
    
    init?(json: JSON) {
        guard let id = json["userId"].int,
              let username = json["username"].string else {
            return nil
        }
        
        self.id = id
        self.username = username
        self.avatar = json["avatar"].string
    }
}
