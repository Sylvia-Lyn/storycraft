import { authService } from "@/services/authService";
import { useAuthStore } from "@/store/authStore";
import { LANGUAGES, useLanguageStore } from "@/store/languageStore";
import { Ionicons } from "@expo/vector-icons";
import { router, usePathname } from "expo-router";
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Alert,
  Image,
  ImageBackground,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function ProfileScreen() {
  const { t } = useTranslation();
  const [modalVisible, setModalVisible] = useState(false);
  const [loading, setLoading] = useState(true);

  const user = useAuthStore((state) => state.user);
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const { currentLanguage, setLanguage } = useLanguageStore();
  const insets = useSafeAreaInsets();
  const pathname = usePathname();

  useEffect(() => {
    if (isAuthenticated) {
      loadUserData();
    } else {
      setLoading(false);
    }
  }, [isAuthenticated]);

  const loadUserData = async () => {
    try {
      setLoading(true);
      await authService.getUserInfo();
    } catch (error) {
      console.error("加载用户数据失败:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleLanguageSelect = async (languageCode: string) => {
    try {
      await setLanguage(languageCode as any);
      if (isAuthenticated) {
        await authService.updateLanguage(languageCode);
      }
      setModalVisible(false);
    } catch (error) {
      console.error("更新语言失败:", error);
      Alert.alert(t("common.prompt"), "更新语言设置失败，请重试");
    }
  };

  const handleLogout = () => {
    Alert.alert(t("profile.logOut"), t("auth.logoutConfirm"), [
      {
        text: t("common.cancel"),
        style: "cancel",
      },
      {
        text: t("profile.logOut"),
        style: "destructive",
        onPress: async () => {
          try {
            await authService.logout();
          } catch (error) {
            console.error("退出失败:", error);
            Alert.alert(t("common.prompt"), "退出失败，请稍后重试");
          }
        },
      },
    ]);
  };

  if (loading) {
    return (
      <View
        style={[
          styles.container,
          { justifyContent: "center", alignItems: "center" },
        ]}
      >
        <ActivityIndicator size="large" color="#ffffff" />
      </View>
    );
  }

  if (!isAuthenticated) {
    return (
      <ImageBackground
        source={require("@/assets/drama/bg.png")}
        style={styles.notLoginContainer}
        resizeMode="cover"
      >
        {}
        <View style={styles.overlay} />

        <Text style={{ ...styles.notLoginTitle, marginTop: insets.top }}>
          {t("auth.login")}
        </Text>

        <View style={styles.notLoginContent}>
          <View style={styles.titleContainer}>
            {}
            <View style={styles.lineTopRight} />

            <Text style={styles.todayText}>Today</Text>
            <Text style={styles.dramaText}>Drama</Text>

            {}
            <View style={styles.lineBottomLeft} />
          </View>
        </View>

        <View
          style={[styles.loginButtonWrapper, { bottom: 80 + insets.bottom }]}
        >
          <TouchableOpacity
            style={styles.notLoginButton}
            onPress={() => router.push("/login")}
          >
            <Text style={styles.notLoginButtonText}>{t("auth.login")}</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>
    );
  }
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        {user?.avatarUrl ? (
          <Image source={{ uri: user.avatarUrl }} style={styles.avatar} />
        ) : (
          <View style={[styles.avatar, styles.avatarPlaceholder]}>
            <Ionicons name="person" size={32} color="#ffffff" />
          </View>
        )}
        <View style={styles.userInfo}>
          <Text style={styles.username}>
            {user?.plainMobile || "未设置用户名"}
          </Text>
          <Text style={styles.userId}>
            {t("profile.account")}：{user?.userId || "未知"}
          </Text>
        </View>
      </View>
      <View style={styles.baseInfo}>
        <Text style={styles.infoTitle}>{t("profile.basicInfo")}</Text>
        <TouchableOpacity
          style={styles.laugBox}
          onPress={() => setModalVisible(true)}
        >
          <Text style={styles.laugTitle}>{t("profile.language")}</Text>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Text style={styles.laugBtn}>
              {LANGUAGES[currentLanguage].nativeLabel}
            </Text>
            <Ionicons
              name="chevron-forward"
              size={20}
              color="#ffffff"
              style={{ marginLeft: 8 }}
            />
          </View>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Ionicons
          name="log-out-outline"
          size={20}
          color="#FF5252"
          style={{ marginRight: 8 }}
        />
        <Text style={styles.logoutText}>{t("profile.logOut")}</Text>
      </TouchableOpacity>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{t("common.language")}</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={28} color="#ffffff" />
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.languageList}>
              {Object.entries(LANGUAGES).map(([code, lang]) => (
                <TouchableOpacity
                  key={code}
                  style={styles.languageItem}
                  onPress={() => handleLanguageSelect(code)}
                >
                  <Text style={styles.languageText} allowFontScaling={false}>
                    {lang.nativeLabel}
                  </Text>
                  {currentLanguage === code && (
                    <View style={styles.checkmarkContainer}>
                      <Ionicons name="checkmark" size={24} color="#4CAF50" />
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {}

      <View
        style={[
          styles.customTabBar,
          { height: 60 + insets.bottom, paddingBottom: insets.bottom },
        ]}
      >
        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => router.push("/(tabs)/dream")}
        >
          <Text
            style={[
              styles.tabText,
              pathname === "/dream" && styles.tabTextActive,
            ]}
          >
            {t("tabs.dream")}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => {
            router.push("/(tabs)/profile");
          }}
        >
          <Text
            style={[
              styles.tabText,
              pathname === "/profile" && styles.tabTextActive,
            ]}
          >
            {t("profile.my")}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1e1e1e",
    paddingTop: 60,
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 60,
    marginLeft: 20,
  },
  avatar: {
    width: 57,
    height: 57,
    borderRadius: 28.5,
  },
  avatarPlaceholder: {
    backgroundColor: "rgba(49, 49, 49, 1)",
    justifyContent: "center",
    alignItems: "center",
  },
  userInfo: {
    marginLeft: 16,
  },
  username: {
    fontSize: 20,
    color: "#FFFFFF",
    fontWeight: "500",
  },
  userId: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.63)",
    marginTop: 4,
  },
  baseInfo: {
    marginLeft: 20,
    marginTop: 40,
  },
  infoTitle: {
    fontSize: 14,
    color: "rgba(255, 255, 255, 0.63)",
  },
  laugBox: {
    height: 57,
    width: "100%",
    backgroundColor: "rgba(49, 49, 49, 1)",
    marginTop: 20,
    borderRadius: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
  },
  laugTitle: {
    fontSize: 16,
    color: "#ffffff",
  },
  laugBtn: {
    fontSize: 16,
    color: "#ffffff",
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    justifyContent: "flex-end",
  },
  modalContent: {
    backgroundColor: "#2a2a2a",
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: 40,
    maxHeight: "70%",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255, 255, 255, 0.1)",
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#ffffff",
  },
  languageList: {
    paddingHorizontal: 20,
  },
  languageItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 16,
    paddingRight: 4,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255, 255, 255, 0.05)",
  },
  languageText: {
    flex: 1,
    fontSize: 16,
    color: "#ffffff",
    paddingRight: 12,
  },
  checkmarkContainer: {
    width: 24,
    height: 24,
    justifyContent: "center",
    alignItems: "center",
  },
  logoutButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: 57,
    backgroundColor: "rgba(49, 49, 49, 1)",
    borderRadius: 16,
    marginLeft: 20,
    marginTop: 40,
  },
  logoutText: {
    fontSize: 16,
    color: "#FF5252",
    fontWeight: "500",
  },
  notLoginContainer: {
    flex: 1,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(30, 30, 30, 0.63)",
  },
  notLoginTitle: {
    fontSize: 20,
    color: "#FFFFFF",
    textAlign: "center",
    paddingTop: 60,
  },
  notLoginContent: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 150,
  },
  titleContainer: {
    width: "70%",
    position: "relative",
  },
  lineTopRight: {
    position: "absolute",
    top: -30,
    right: -20,
    width: 150,
    height: 1,
    backgroundColor: "#FFFFFF",
    transform: [{ rotate: "45deg" }],
  },
  lineBottomLeft: {
    position: "absolute",
    bottom: -30,
    left: -20,
    width: 150,
    height: 1,
    backgroundColor: "#FFFFFF",
    transform: [{ rotate: "45deg" }],
  },
  todayText: {
    fontSize: 60,
    color: "#FFFFFF",
    fontWeight: "300",
    letterSpacing: 2,
    textAlign: "left",
  },
  dramaText: {
    fontSize: 60,
    color: "#FFFFFF",
    fontWeight: "300",
    letterSpacing: 2,
    textAlign: "right",
    marginTop: 18,
  },
  loginButtonWrapper: {
    position: "absolute",
    bottom: 80,
    left: 0,
    right: 0,
    alignItems: "center",
  },
  notLoginButton: {
    width: 300,
    height: 55,
    backgroundColor: "#FFFFFF",
    borderRadius: 25,
    justifyContent: "center",
    alignItems: "center",
  },
  notLoginButtonText: {
    fontSize: 16,
    color: "#000000",
    fontWeight: "500",
  },
  loginButton: {
    height: 57,
    backgroundColor: "rgba(49, 49, 49, 1)",
    borderRadius: 16,
    marginHorizontal: 20,
    marginTop: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  loginButtonText: {
    fontSize: 16,
    color: "#FFFFFF",
    fontWeight: "500",
  },
  customTabBar: {
    zIndex: 10,
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: 60,
    flexDirection: "row",
    backgroundColor: "#000000",
  },
  tabItem: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "center",
    paddingTop: 20,
  },
  tabText: {
    fontSize: 16,
    fontWeight: "500",
    color: "rgba(255, 255, 255, 0.6)",
  },
  tabTextActive: {
    color: "#FFFFFF",
  },
});
