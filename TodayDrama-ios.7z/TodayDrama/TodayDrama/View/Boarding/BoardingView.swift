//
//  BoardingView.swift
//  TodayDrama
//
//  Created by GH on 9/4/25.
//

import SwiftUI

struct BoardingView: View {
    @State private var register: Bool = false
    
    var body: some View {
        if register {
            RegisterView {
                withAnimation(.bouncy) {
                    register = false
                }
            }
        } else {
            LoginView {
                withAnimation(.bouncy) {
                    register = true
                }
            }
        }
    }
}

#Preview {
    BoardingView()
}
