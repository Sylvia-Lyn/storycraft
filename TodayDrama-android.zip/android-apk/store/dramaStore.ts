import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { DramaEntity, SegmentEntity } from '@/api/types';

// 剧集列表项
export interface DramaListItem extends DramaEntity {
  rootSegmentId?: number;
}

// 视频播放信息
export interface VideoPlayInfo {
  dramaId: number;
  segmentId: number;
  url: string;
  duration?: number;
}

// Drama State 类型
interface DramaState {
  // 状态
  dramaList: DramaListItem[];
  currentDrama: DramaListItem | null;
  currentSegment: SegmentEntity | null;
  currentVideoUrl: string | null;
  isLoading: boolean;
  lastFetchTime: number | null; // 用于缓存控制
  cacheExpiry: number; // 缓存过期时间（毫秒）

  // 方法
  setDramaList: (list: DramaListItem[]) => void;
  setCurrentDrama: (drama: DramaListItem | null) => void;
  setCurrentSegment: (segment: SegmentEntity | null) => void;
  setCurrentVideoUrl: (url: string | null) => void;
  setLoading: (loading: boolean) => void;
  clearCache: () => void;
  isCacheValid: () => boolean;
  updateLastFetchTime: () => void;
}

export const useDramaStore = create<DramaState>()(
  persist(
    (set, get) => ({
      // 初始状态
      dramaList: [],
      currentDrama: null,
      currentSegment: null,
      currentVideoUrl: null,
      isLoading: false,
      lastFetchTime: null,
      cacheExpiry: 5 * 60 * 1000, // 默认5分钟缓存

      // 设置剧集列表
      setDramaList: (list: DramaListItem[]) => {
        set({ dramaList: list });
      },

      // 设置当前剧集
      setCurrentDrama: (drama: DramaListItem | null) => {
        set({ currentDrama: drama });
      },

      // 设置当前片段
      setCurrentSegment: (segment: SegmentEntity | null) => {
        set({ currentSegment: segment });
      },

      // 设置当前视频URL
      setCurrentVideoUrl: (url: string | null) => {
        set({ currentVideoUrl: url });
      },

      // 设置加载状态
      setLoading: (loading: boolean) => {
        set({ isLoading: loading });
      },

      // 清除缓存
      clearCache: () => {
        set({
          dramaList: [],
          currentDrama: null,
          currentSegment: null,
          currentVideoUrl: null,
          lastFetchTime: null,
        });
      },

      // 检查缓存是否有效
      isCacheValid: () => {
        const state = get();
        if (!state.lastFetchTime || state.dramaList.length === 0) {
          return false;
        }
        const now = Date.now();
        return (now - state.lastFetchTime) < state.cacheExpiry;
      },

      // 更新最后获取时间
      updateLastFetchTime: () => {
        set({ lastFetchTime: Date.now() });
      },
    }),
    {
      name: 'drama-storage', // 存储的 key
      storage: createJSONStorage(() => AsyncStorage), // 使用 AsyncStorage
      // 只持久化部分数据
      partialize: (state) => ({
        dramaList: state.dramaList,
        currentDrama: state.currentDrama,
        currentSegment: state.currentSegment,
        currentVideoUrl: state.currentVideoUrl,
        lastFetchTime: state.lastFetchTime,
        cacheExpiry: state.cacheExpiry,
      }),
    }
  )
);
