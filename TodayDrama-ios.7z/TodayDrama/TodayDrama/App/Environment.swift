//
//  Environment.swift
//  TodayDrama
//
//  Created by GH on 9/3/25.
//

let baseURL = "http://18.183.126.169:8080/tiktok-drama/api/"

// TODO: - 待补全
let privacyPolicy: String = "https://example.com/user-agreement"

let userAgreement: String = "https://example.com/privacy-policy"

let regions: [String: String] = [
//    "United States": "+1",
    "China": "+86",
//    "United Kingdom": "+44",
//    "Japan": "+81",
//    "South Korea": "+82",
//    "Australia": "+61",
//    "Canada": "+1",
//    "India": "+91",
//    "Germany": "+49",
//    "France": "+33",
//    "Hong Kong": "+852",
//    "Taiwan": "+886",
//    "Singapore": "+65"
]
