// Service层使用示例

import { authService } from '@/services/authService';
import { dramaService } from '@/services/dramaService';
import { useAuthStore } from '@/store/authStore';

// ============ 认证相关示例 ============

// 示例 1: 登录
export async function loginExample() {
  try {
    await authService.login({
      mobile: '13800138000',
      password: 'password123',
    });

    // 登录成功后，authStore 中的状态已自动更新
    const user = useAuthStore.getState().user;
    console.log('登录成功:', user);

    // 跳转到主页
    // router.push('/(tabs)/dream');
  } catch (error) {
    console.error('登录失败:', error);
    // 显示错误提示
  }
}

// 示例 2: 注册
export async function registerExample() {
  try {
    await authService.register({
      mobile: '13800138000',
      password: 'password123',
      username: 'testuser',
      email: 'test@example.com',
      language: 'zh',
      gender: 1,
    });

    // 注册成功后自动登录
    // router.push('/(tabs)/dream');
  } catch (error) {
    console.error('注册失败:', error);
  }
}

// 示例 3: 更新用户信息
export async function updateProfileExample() {
  try {
    await authService.updateUserInfo({
      nickname: '新昵称',
      gender: 1,
      language: 'zh',
    });

    console.log('更新成功');
    // 用户信息已自动更新到 store
  } catch (error) {
    console.error('更新失败:', error);
  }
}

// 示例 4: 登出
export async function logoutExample() {
  try {
    await authService.logout();
    // router.push('/login');
  } catch (error) {
    console.error('登出失败:', error);
  }
}

// 示例 5: 获取支持的语言列表
export async function getLanguagesExample() {
  try {
    const languages = await authService.getSupportedLanguages();
    console.log('支持的语言:', languages);
    // [{ code: 'zh', name: '中文' }, { code: 'en', name: 'English' }]
  } catch (error) {
    console.error('获取语言列表失败:', error);
  }
}

// ============ 剧集相关示例 ============

// 示例 6: 获取剧集列表
export async function getDramaListExample() {
  try {
    const dramaPage = await dramaService.getDramaList({
      pageIndex: 1,
      pageSize: 10,
    });

    console.log('剧集列表:', dramaPage?.records);
    console.log('总数:', dramaPage?.total);
  } catch (error) {
    console.error('获取剧集列表失败:', error);
  }
}

// 示例 7: 获取剧集详情（包含根节点）
export async function getDramaDetailExample() {
  try {
    const drama = await dramaService.getDramaDetail(1);

    console.log('剧集信息:', drama?.title, drama?.description);
    console.log('根节点:', drama?.rootSegment);
  } catch (error) {
    console.error('获取剧集详情失败:', error);
  }
}

// 示例 8: 获取节点详情和分支选项
export async function getSegmentExample() {
  try {
    const segment = await dramaService.getSegmentDetail(1);

    console.log('节点信息:', segment?.title);
    console.log('视频URL:', segment?.url);
    console.log('分支选项:', segment?.branches);
  } catch (error) {
    console.error('获取节点失败:', error);
  }
}

// 示例 9: 提交播放进度
export async function submitProgressExample() {
  try {
    await dramaService.submitPlaybackProgress({
      dramaId: 1,
      segmentId: '123',
      chosenOptionId: '456',
      nextSegmentId: '789',
      playTime: 30,
      duration: 60,
      progressPercentage: 0.5,
    });

    console.log('进度提交成功');
  } catch (error) {
    console.error('提交进度失败:', error);
  }
}

// ============ 组合使用示例 ============

// 示例 10: 完整的剧集播放流程
export async function playDramaExample(dramaId: number) {
  try {
    // 1. 获取剧集详情
    const drama = await dramaService.getDramaDetail(dramaId);

    if (!drama?.rootSegment) {
      throw new Error('剧集没有根节点');
    }

    // 2. 获取根节点的详细信息（包含分支选项）
    const segment = await dramaService.getSegmentDetail(drama.rootSegment.id!);

    // 3. 播放视频
    console.log('播放视频:', segment?.url);

    // 4. 用户选择分支后，提交进度
    const selectedBranch = segment?.branches?.[0];
    if (selectedBranch) {
      await dramaService.submitPlaybackProgress({
        dramaId: drama.id,
        segmentId: String(segment?.id),
        chosenOptionId: String(selectedBranch.id),
        nextSegmentId: String(selectedBranch.nextSegmentId),
        playTime: 60,
        duration: 60,
        progressPercentage: 1,
      });

      // 5. 加载下一个节点
      if (selectedBranch.nextSegmentId) {
        const nextSegment = await dramaService.getSegmentDetail(
          selectedBranch.nextSegmentId
        );
        console.log('下一个节点:', nextSegment?.title);
      }
    }
  } catch (error) {
    console.error('播放剧集失败:', error);
  }
}
