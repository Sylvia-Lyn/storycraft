//
//  FeedCell.swift
//  TodayDrama
//
//  Created by GH on 9/8/25.
//

import AVKit
import Combine
import SwiftUI

struct FeedCellView: View {
    @Environment(DramaManager.self) var dramaManager
    let player: AVPlayer
    @Binding var showBranchTree: Bool
    
    var body: some View {
        ZStack {
            CustomVideoPlayer(player: player)
                .containerRelativeFrame([.horizontal, .vertical])
            
            VideoOverlayView(player: player, showBranchTree: $showBranchTree)
        }
        .contentShape(.rect)
        .onTapGesture {
            switch player.timeControlStatus {
            case .paused:
                player.play()
            case .playing:
                player.pause()
            default:
                break
            }
        }
        .onReceive(
            dramaManager.mainPlayerItem?.publisher(for: \.status)
                .eraseToAnyPublisher() ?? Empty<AVPlayerItem.Status, Never>().eraseToAnyPublisher()
        ) { (status: AVPlayerItem.Status) in
            if status == .readyToPlay && !dramaManager.currentSegment.branches.isEmpty {
                dramaManager.loadBranch()
            }
        }
    }
}

#Preview {
    @Previewable @State var showBranchTree = false
    let dreamFinalSegment1 = Segment(
        id: 1,
        title: "美梦成真",
        url: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        description: "沉浸在美好的梦境中",
        isEnd: true
    )
    
    let dreamFinalSegment2 = Segment(
        id: 2,
        title: "噩梦结局",
        url: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
        description: "回到残酷的现实世界",
        isEnd: true
    )
    
    let adventureSegment = Segment(
        id: 3,
        title: "冒险路线",
        url: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
        description: "踏上刺激的冒险之旅,寻找传说中的宝藏",
        isEnd: true
    )
    
    let dreamBranchSegment = Segment(
        id: 4,
        title: "梦境路线",
        url: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        description: "进入神秘的梦境世界,探索内心深处",
        branchTrigger: 20.0,
        defaultSegmentId: 1,
        branches: [dreamFinalSegment1, dreamFinalSegment2]
    )
    
    let rootSegment = Segment(
        id: 5,
        title: "奇幻冒险",
        url: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        branchTrigger: 0.0,
        defaultSegmentId: 4,
        branches: [dreamBranchSegment, adventureSegment]
    )
    
    let drama = Drama(
        id: 100,
        title: "大白兔的多重选择冒险",
        description: "一个充满选择的精彩故事,每个决定都会带来不同的结局",
        rootSegment: rootSegment
    )
    
    let manager = DramaManager(drama: drama)
    let player = AVPlayer()
    FeedCellView(player: player, showBranchTree: $showBranchTree)
        .environment(manager)
        .onAppear {
            manager.loadRoot()
            
            if let playerItem = manager.mainPlayerItem {
                player.replaceCurrentItem(with: playerItem)
                player.play()
            }
        }
        .ignoresSafeArea()
        .background(.black)
}
