//
//  Network.swift
//  TodayDrama
//
//  Created by GH on 9/3/25.
//

import Alamofire
import Foundation
import SwiftyJSON
import SwiftUI

enum Network {
#if DEBUG
    private static var token: String? = "ef7862fc-960c-46ac-9080-3896647b1c0b"
#else
    private static var token: String? = { Keychain.get("token") }()
#endif
    
    static func get(_ path: String, completion: @escaping (JSON) -> Void) {
        Task {
            let result = await requestInternal(.get, path: path, body: Optional<Data>.none, onFailure: nil)
            completion(result)
        }
    }
    
    static func get(_ path: String, completion: @escaping (JSON) -> Void, onFailure: @escaping () -> Void) {
        Task {
            let result = await requestInternal(.get, path: path, body: Optional<Data>.none, onFailure: onFailure)
            completion(result)
        }
    }
    
    static func get(_ path: String) {
        Task {
            _ = await requestInternal(.get, path: path, body: Optional<Data>.none, onFailure: nil)
        }
    }
    
    static func get<T: Encodable & Sendable>(_ path: String, parameters: T, completion: @escaping (JSON) -> Void) {
        Task {
            let result = await requestInternal(.get, path: path, body: parameters, onFailure: nil)
            completion(result)
        }
    }
    
    static func get<T: Encodable & Sendable>(_ path: String, parameters: T, completion: @escaping (JSON) -> Void, onFailure: @escaping () -> Void) {
        Task {
            let result = await requestInternal(.get, path: path, body: parameters, onFailure: onFailure)
            completion(result)
        }
    }
    
    static func get<T: Encodable & Sendable>(_ path: String, parameters: T) {
        Task {
            _ = await requestInternal(.get, path: path, body: parameters, onFailure: nil)
        }
    }
    
    static func post(_ path: String, completion: @escaping (JSON) -> Void) {
        Task {
            let result = await requestInternal(.post, path: path, body: Optional<Data>.none, onFailure: nil)
            completion(result)
        }
    }
    
    static func post(_ path: String, completion: @escaping (JSON) -> Void, onFailure: @escaping () -> Void) {
        Task {
            let result = await requestInternal(.post, path: path, body: Optional<Data>.none, onFailure: onFailure)
            completion(result)
        }
    }
    
    static func post(_ path: String) {
        Task {
            _ = await requestInternal(.post, path: path, body: Optional<Data>.none, onFailure: nil)
        }
    }
    
    static func post<T: Encodable & Sendable>(_ path: String, body: T, completion: @escaping (JSON) -> Void) {
        Task {
            let result = await requestInternal(.post, path: path, body: body, onFailure: nil)
            completion(result)
        }
    }
    
    static func post<T: Encodable & Sendable>(_ path: String, body: T, completion: @escaping (JSON) -> Void, onFailure: @escaping () -> Void) {
        Task {
            let result = await requestInternal(.post, path: path, body: body, onFailure: onFailure)
            completion(result)
        }
    }
    
    static func post<T: Encodable & Sendable>(_ path: String, body: T) {
        Task {
            _ = await requestInternal(.post, path: path, body: body, onFailure: nil)
        }
    }
    
    static func upload(_ path: String, multipartFormData: @escaping (MultipartFormData) -> Void, completion: @escaping (JSON) -> Void) {
        Task {
            let result = await uploadInternal(path: path, multipartFormData: multipartFormData, onFailure: nil)
            completion(result)
        }
    }
    
    static func upload(_ path: String, multipartFormData: @escaping (MultipartFormData) -> Void, completion: @escaping (JSON) -> Void, onFailure: @escaping () -> Void) {
        Task {
            let result = await uploadInternal(path: path, multipartFormData: multipartFormData, onFailure: onFailure)
            completion(result)
        }
    }
    
    static func download(_ url: String, to filename: String, in directory: Directory, progress: Binding<Double>? = nil) async -> URL? {
        let destinationURL = directory.baseURL.appendingPathComponent(filename)
        
        if FileManager.default.fileExists(atPath: destinationURL.path) {
            return destinationURL
        }
        
        let destination: DownloadRequest.Destination = { _, _ in
            return (destinationURL, [.createIntermediateDirectories])
        }
        
        do {
            return try await AF.download(url, to: destination)
                .downloadProgress { downloadProgress in
                    Task { @MainActor in
                        progress?.wrappedValue = downloadProgress.fractionCompleted
                    }
                }
                .serializingDownloadedFileURL()
                .value
        } catch {
            return nil
        }
    }
    
    private static func uploadInternal(path: String, multipartFormData: @escaping (MultipartFormData) -> Void, onFailure: (() -> Void)?) async -> JSON {
        let url = baseURL + path
        var headers: HTTPHeaders = [:]
        if let token = token {
            headers.add(name: "token", value: token)
        }
        
        let dataRequest = AF.upload(multipartFormData: multipartFormData, to: url, method: .post, headers: headers)
        
        let result = await dataRequest.serializingData().result
        
        switch result {
        case .success(let data):
            guard let json = try? JSON(data: data) else {
                onFailure?()
                return .null
            }
            guard let data = json["data"].exists() ? json["data"] : nil else {
                onFailure?()
                return .null
            }
            return data
            
        case .failure(let error):
            if let urlError = error.underlyingError as? URLError {
                switch urlError.code {
                case .notConnectedToInternet, .timedOut, .networkConnectionLost, .cannotFindHost, .cannotConnectToHost:
                    onFailure?()
                    return .null
                default:
                    break
                }
            }
            
            if error.responseCode == 401 {
                if let newToken = await refreshToken() {
                    token = newToken
                }
            } else if error.responseCode == 403 {
                AppState.shared.logout()
            }
            
            onFailure?()
            return .null
        }
    }
    
    private static func requestInternal<T: Encodable & Sendable>(_ method: HTTPMethod, path: String, body: T?, onFailure: (() -> Void)?) async -> JSON {
        let url = baseURL + path
        var headers: HTTPHeaders = [:]
        if let token = token {
            headers.add(name: "token", value: token)
        }
        
        let encoder: ParameterEncoder = (method == .get) ? URLEncodedFormParameterEncoder.default : JSONParameterEncoder.default
        
        let dataRequest: DataRequest
        
        if let body {
            dataRequest = AF.request(url, method: method, parameters: body, encoder: encoder, headers: headers)
        } else {
            dataRequest = AF.request(url, method: method, headers: headers)
        }
        
        print("[Network] \(url)")
        
        let result = await dataRequest.serializingData().result
        
        switch result {
        case .success(let data):
            guard let json = try? JSON(data: data) else {
                onFailure?()
                return .null
            }
            guard let data = json["data"].exists() ? json["data"] : nil else {
                onFailure?()
                return .null
            }
            return data
            
        case .failure(let error):
            if let urlError = error.underlyingError as? URLError {
                switch urlError.code {
                case .notConnectedToInternet, .timedOut, .networkConnectionLost, .cannotFindHost, .cannotConnectToHost:
                    onFailure?()
                    return .null
                default:
                    break
                }
            }
            
            if error.responseCode == 401 {
                if let newToken = await refreshToken() {
                    token = newToken
                }
            } else if error.responseCode == 403 {
                AppState.shared.logout()
            }
            
            onFailure?()
            return .null
        }
    }
    
    private static func refreshToken() async -> String? {
        guard let token = Keychain.get("token") else {
            return nil
        }
        
        let url = baseURL + "/user/refreshToken"
        let headers: HTTPHeaders = ["token": token]
        
        let result = await AF.request(url, method: .post, headers: headers).serializingData().result
        
        print("[Network] 正在刷新 Token")
        
        guard case let .success(data) = result else { return nil }
        guard let json = try? JSON(data: data) else { return nil }
        guard let newToken = json["data"]["token"].string else { return nil }
        
        Keychain.save("token", value: newToken)
        return newToken
    }
    
    static func setToken(_ token: String) {
        Keychain.save("token", value: token)
        self.token = token
    }
}
