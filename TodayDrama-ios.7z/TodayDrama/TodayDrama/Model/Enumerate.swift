//
//  Enumerate.swift
//  TodayDrama
//
//  Created by GH on 9/4/25.
//

import SwiftUI

// MARK: - 类型定义
enum IdentifierType: CaseIterable {
    case email
    case phone
    
    var placeholder: LocalizedStringKey {
        switch self {
        case .email:
            "邮箱地址"
        case .phone:
            "电话号码"
        }
    }
    
    /// 正则 pattern
    var regexPattern: String {
        switch self {
        case .email:
            // 禁用 '+' 别名（用户名中不允许出现 +）
            return #"^[A-Z0-9a-z._%]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"#
        case .phone:
            return #"^\d{10,15}$"#
        }
    }
    
    /// 错误提示
    var validationError: String {
        switch self {
        case .email:
            return "请输入有效的邮箱地址（不允许使用别名，如 +abc）"
        case .phone:
            return "请输入有效的手机号（10～15 位数字）"
        }
    }
    
    /// 键盘类型
    var keyboardType: UIKeyboardType {
        switch self {
        case .email:
            return .emailAddress
        case .phone:
            return .numberPad
        }
    }
    
    var switchButtonText: LocalizedStringKey {
        switch self {
        case .email:
            "使用手机号"
        case .phone:
            "使用邮箱"
        }
    }
}
