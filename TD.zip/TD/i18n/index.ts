import i18n from "i18next";
import { initReactI18next } from "react-i18next";


i18n
  .use(initReactI18next)
  .init({
    resources: {
      "zh": {
        translation: {
          common: {
            language: "语言",
            confirm: "确定",
            cancel: "取消",
            ok: "好的",
            prompt: "提示",
          },
          auth: {
            register: "注册",
            login: "登录",
            logout: "退出",
            username: "用户名",
            mobile: "手机号",
            dateOfBirth: "出生日期",
            password: "密码",
            confirmPassword: "确认密码",
            loginForFullExperience: "登录以获得完整体验",
            termsOfService: "用户协议",
            privacyPolicy: "隐私政策",
            agreeToTerms: "继续即代表你同意[用户协议]和[隐私政策]",
            enterMobile: "请输入手机号",
            enterValidMobile: "请输入有效的手机号",
            logoutConfirm: "确定要退出当前账号吗",
          },
          profile: {
            my: "我的",
            account: "账号",
            basicInfo: "基础信息",
            language: "语言",
            logOut: "退出账号",
          },
          tabs: {
            dream: "叙梦",
          },
        },
      },
      en: {
        translation: {
          common: {
            language: "Language",
            confirm: "Confirm",
            cancel: "Cancel",
            ok: "OK",
            prompt: "Prompt",
          },
          auth: {
            register: "Register",
            login: "Log In",
            logout: "Log Out",
            username: "Username",
            mobile: "Mobile Number",
            dateOfBirth: "Date of Birth",
            password: "Password",
            confirmPassword: "Confirm Password",
            loginForFullExperience: "Log in for the full experience",
            termsOfService: "Terms of Service",
            privacyPolicy: "Privacy Policy",
            agreeToTerms:
              "By continuing, you agree to our [Terms of Service] and [Privacy Policy].",
            enterMobile: "Please enter your mobile number",
            enterValidMobile: "Please enter a valid mobile number",
            logoutConfirm: "Are you sure you want to log out?",
          },
          profile: {
            my: "My",
            account: "Account",
            basicInfo: "Basic Information",
            language: "Language",
            logOut: "Log Out",
          },
          tabs: {
            dream: "Dream",
          },
        },
      },
      ja: {
        translation: {
          common: {
            language: "言語",
            confirm: "確認",
            cancel: "キャンセル",
            ok: "了解",
            prompt: "ヒント",
          },
          auth: {
            register: "登録",
            login: "ログイン",
            logout: "ログアウト",
            username: "ユーザー名",
            mobile: "携帯電話番号",
            dateOfBirth: "生年月日",
            password: "パスワード",
            confirmPassword: "パスワード確認",
            loginForFullExperience:
              "全ての機能を利用するには、ログインしてください",
            termsOfService: "利用規約",
            privacyPolicy: "プライバシーポリシー",
            agreeToTerms:
              "同意して続ける、[利用規約]と[プライバシーポリシー]に同意したものとみなされます",
            enterMobile: "携帯電話番号を入力してください",
            enterValidMobile: "有効な携帯電話番号を入力してください",
            logoutConfirm: "ログアウトしますか？",
          },
          profile: {
            my: "マイページ",
            account: "アカウント",
            basicInfo: "基本情報",
            language: "言語",
            logOut: "ログアウト",
          },
          tabs: {
            dream: "夢を語る",
          },
        },
      },
      ko: {
        translation: {
          common: {
            language: "언어",
            confirm: "확인",
            cancel: "취소",
            ok: "확인",
            prompt: "안내",
          },
          auth: {
            register: "회원가입",
            login: "로그인",
            logout: "로그아웃",
            username: "사용자 이름",
            mobile: "휴대폰 번호",
            dateOfBirth: "생년월일",
            password: "비밀번호",
            confirmPassword: "비밀번호 확인",
            loginForFullExperience: "전체 기능을 이용하려면 로그인하세요",
            termsOfService: "이용약관",
            privacyPolicy: "개인정보 처리방침",
            agreeToTerms:
              "계속하면 [이용약관] 및 [개인정보 처리방침]에 동의하는 것으로 간주됩니다.",
            enterMobile: "휴대폰 번호를 입력해 주세요",
            enterValidMobile: "유효한 휴대폰 번호를 입력해 주세요",
            logoutConfirm: "로그아웃 하시겠습니까？",
          },
          profile: {
            my: "마이",
            account: "계정",
            basicInfo: "기본 정보",
            language: "언어",
            logOut: "로그아웃",
          },
          tabs: {
            dream: "꿈 이야기",
          },
        },
      },
    },
    lng: "ja",
    fallbackLng: "ja",
    debug: __DEV__,
    interpolation: {
      escapeValue: false,
    },
    defaultNS: "translation",
    react: {
      useSuspense: false,
    },
  });

export default i18n;
