//
//  FileSystem.swift
//  TodayDrama
//
//  Created by GH on 9/3/25.
//

import Foundation

enum FileSystem {
    @discardableResult
    static func save<T: Encodable>(_ value: T, to filename: String, in directory: Directory) throws -> URL {
        let url = directory.baseURL.appendingPathComponent(filename)
        ensureDirectoryExists(for: url.deletingLastPathComponent())
        let data = try JSONEncoder().encode(value)
        try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        return url
    }
    
    static func load<T: Decodable>(_ type: T.Type, from filename: String, in directory: Directory) throws -> T {
        let url = directory.baseURL.appendingPathComponent(filename)
        let data = try Data(contentsOf: url)
        return try JSONDecoder().decode(T.self, from: data)
    }
    
    static func delete(_ filename: String, in directory: Directory) throws {
        let url = directory.baseURL.appendingPathComponent(filename)
        try FileManager.default.removeItem(at: url)
    }
    
    private static func ensureDirectoryExists(for directory: URL) {
        if !FileManager.default.fileExists(atPath: directory.path) {
            try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        }
    }
}

enum Directory {
    case applicationSupport
    case documents
    
    var baseURL: URL {
        switch self {
        case .applicationSupport:
            guard let url = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
                fatalError("无法找到 Application Support 目录")
            }
            return url
            
        case .documents:
            guard let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
                fatalError("无法找到 Documents 目录")
            }
            return documentsURL
        }
    }
}
