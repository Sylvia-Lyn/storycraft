import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { UserEntity } from '@/api/types';

// 使用 API 的 UserEntity 作为用户类型
export type User = UserEntity;

// 登录响应类型
export interface LoginResponse {
  user: User;
  token: string;
  refreshToken?: string;
  expiresIn?: number;
}

// Auth State 类型
interface AuthState {
  // 状态
  user: User | null;
  token: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;

  // 方法
  login: (response: LoginResponse) => void;
  logout: () => void;
  updateUser: (user: Partial<User>) => void;
  setToken: (token: string) => void;
  setRefreshToken: (refreshToken: string) => void;
  initAuth: () => Promise<void>;
  checkAuthStatus: () => boolean;
  clearAuth: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      // 初始状态
      user: null,
      token: null,
      refreshToken: null,
      isAuthenticated: false,
      isLoading: false,

      // 登录
      login: (response: LoginResponse) => {
        set({
          user: response.user,
          token: response.token,
          refreshToken: response.refreshToken || null,
          isAuthenticated: true,
        });
      },

      // 登出
      logout: () => {
        set({
          user: null,
          token: null,
          refreshToken: null,
          isAuthenticated: false,
        });
      },

      // 更新用户信息
      updateUser: (updatedUser: Partial<User>) => {
        const currentUser = get().user;
        if (currentUser) {
          set({
            user: {
              ...currentUser,
              ...updatedUser,
            },
          });
        } else {
          // 如果当前没有用户信息，直接设置
          set({
            user: updatedUser as User,
            isAuthenticated: true,
          });
        }
      },

      // 设置 Token
      setToken: (token: string) => {
        set({ token });
      },

      // 设置 Refresh Token
      setRefreshToken: (refreshToken: string) => {
        set({ refreshToken });
      },

      // 初始化认证状态（从存储中恢复）
      initAuth: async () => {
        set({ isLoading: true });
        try {
          const state = get();
          // 检查是否有有效的 token
          if (state.token && state.user) {
            set({ isAuthenticated: true });
          } else {
            set({ isAuthenticated: false });
          }
        } catch (error) {
          console.error('Failed to initialize auth:', error);
          set({ isAuthenticated: false });
        } finally {
          set({ isLoading: false });
        }
      },

      // 检查认证状态
      checkAuthStatus: () => {
        const state = get();
        return !!state.token && !!state.user;
      },

      // 清除所有认证数据
      clearAuth: () => {
        set({
          user: null,
          token: null,
          refreshToken: null,
          isAuthenticated: false,
        });
      },
    }),
    {
      name: 'auth-storage', // 存储的 key
      storage: createJSONStorage(() => AsyncStorage), // 使用 AsyncStorage
    }
  )
);
