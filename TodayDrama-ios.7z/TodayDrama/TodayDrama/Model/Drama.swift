//
//  Drama.swift
//  TodayDrama
//
//  Created by GH on 9/8/25.
//

import Foundation

struct Drama: Identifiable, Codable, Hashable {
    let id: Int
    var version: Int = 1
    let title: String
    var description: String?
    let rootSegment: Segment
    var cover: String?
}

struct Segment: Identifiable, Codable, Hashable {
    let id: Int
    let title: String
    let url: String
    var description: String?
    var isPaid: Int = 0
    var branchTrigger: TimeInterval = 0.0
    var defaultSegmentId: Int?
    var branches: [Segment] = []
    var isEnd: Bool = false
}
