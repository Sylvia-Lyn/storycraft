//
//  ProfileView.swift
//  TodayDrama
//
//  Created by GH on 9/4/25.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        VStack {
            HStack(spacing: 4) {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .frame(width: 64, height: 64)
                VStack(alignment: .leading) {
                    HStack {
                        Text("Username")
                            .font(.title3)
                            .fontWeight(.semibold)
                        
                        Text("VIP")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .padding(.horizontal, 4)
                            .foregroundStyle(.background)
                            .background(.foreground, in: .rect(cornerRadius: 4))
                    }
                    Spacer()
                    
                    Text("编号：123123123")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 8)
            }
            .frame(height: 64)
            
            Spacer()
        }
    }
}

#Preview {
    ProfileView()
}
