//
//  TreeView.swift
//  TodayDrama
//
//  Created by GH on 9/18/25.
//

import SwiftUI

struct TreeView: View {
    let viewModel: DramaFeedViewModel
    @Binding var showBranchTree: Bool
    @Environment(DramaManager.self) var manager
    
    private let nodeWidth: CGFloat = 72
    private let nodeHeight: CGFloat = 128
    private let horizontalSpacing: CGFloat = 100
    private let verticalSpacing: CGFloat = 160
    private let padding: CGFloat = 30
    
    @State private var childToParent: [Int: Int] = [:]
    
    private var pathToCurrent: Set<Int> {
        var path: Set<Int> = []
        var cur = manager.currentSegment.id
        path.insert(cur)
        while let p = childToParent[cur] {
            path.insert(p)
            cur = p
        }
        return path
    }
    
    var body: some View {
        ScrollView([.horizontal, .vertical]) {
            ZStack(alignment: .topLeading) {
                let nodePositions = calculateNodePositions()
                let contentSize = calculateContentSize(nodePositions)
                
                Canvas {
                    context,
                    size in
                    drawConnections(
                        context: context,
                        nodePositions: nodePositions,
                        pathToCurrent: pathToCurrent
                    )
                }
                .frame(width: contentSize.width, height: contentSize.height)
                
                ForEach(getAllSegments(), id: \.id) { segment in
                    if let position = nodePositions[segment.id] {
                        let isOnPath = pathToCurrent.contains(segment.id)
                        Rectangle()
                            .fill(isOnPath ? Color.blue.opacity(0.25) : Color.white.opacity(0.05))
                            .stroke(isOnPath ? Color.blue : Color.gray,
                                    lineWidth: isOnPath ? 2 : 1)
                            .frame(width: nodeWidth, height: nodeHeight)
                            .overlay(alignment: .bottom) {
                                Text(segment.title)
                                    .font(.caption2)
                                    .frame(width: nodeWidth)
                                    .lineLimit(1)
                                    .multilineTextAlignment(.center)
                                    .foregroundStyle(.white)
                            }
                            .position(x: position.x + nodeWidth / 2,
                                      y: position.y + nodeHeight / 2)
                            .onTapGesture {
                                viewModel.switchToSegment(segment, in: manager)
                                showBranchTree = false
                            }
                    }
                }
            }
        }
        .background(.black.opacity(0.75))
        .transition(.opacity)
        .onAppear {
            buildParentMap()
        }
    }
    
    private func buildParentMap() {
        childToParent.removeAll()
        func traverse(_ seg: Segment) {
            for child in seg.branches {
                childToParent[child.id] = seg.id
                traverse(child)
            }
        }
        traverse(manager.drama.rootSegment)
    }
    
    private func getAllSegments() -> [Segment] {
        func collect(_ seg: Segment) -> [Segment] {
            [seg] + seg.branches.flatMap(collect)
        }
        return collect(manager.drama.rootSegment)
    }
    
    private func calculateContentSize(_ positions: [Int: CGPoint]) -> CGSize {
        let maxX = positions.values.map(\.x).max() ?? 0
        let maxY = positions.values.map(\.y).max() ?? 0
        return CGSize(width: maxX + nodeWidth + padding,
                      height: maxY + nodeHeight + 30 + padding)
    }
    
    private func calculateSubtreeHeight(segment: Segment) -> CGFloat {
        segment.branches.isEmpty
        ? verticalSpacing
        : segment.branches.map(calculateSubtreeHeight).reduce(0, +)
    }
    
    private func calculateNodePositions() -> [Int: CGPoint] {
        var positions: [Int: CGPoint] = [:]
        
        @discardableResult
        func place(_ seg: Segment, x: CGFloat, y: CGFloat) -> CGFloat {
            positions[seg.id] = CGPoint(x: x, y: y)
            if seg.branches.isEmpty { return verticalSpacing }
            
            var currentY = y
            var total: CGFloat = 0
            for (idx, child) in seg.branches.enumerated() {
                if idx > 0 { currentY += total }
                let childH = place(child, x: x + horizontalSpacing, y: currentY)
                total += childH
            }
            return total
        }
        
        _ = place(manager.drama.rootSegment, x: padding, y: padding)
        return positions
    }
    
    private func drawConnections(
        context: GraphicsContext,
        nodePositions: [Int: CGPoint],
        pathToCurrent: Set<Int>
    ) {
        func draw(_ seg: Segment) {
            guard let parentPos = nodePositions[seg.id] else { return }
            let start = CGPoint(x: parentPos.x + nodeWidth,
                                y: parentPos.y + nodeHeight / 2)
            
            for child in seg.branches {
                guard let childPos = nodePositions[child.id] else { continue }
                let end = CGPoint(x: childPos.x,
                                  y: childPos.y + nodeHeight / 2)
                
                let midX = (start.x + end.x) / 2
                var p = Path()
                p.move(to: start)
                p.addLine(to: CGPoint(x: midX, y: start.y))
                p.addLine(to: CGPoint(x: midX, y: end.y))
                p.addLine(to: end)
                
                let onPath = pathToCurrent.contains(seg.id) && pathToCurrent.contains(child.id)
                context.stroke(
                    p,
                    with: .color(onPath ? .blue : .white),
                    lineWidth: onPath ? 2.5 : 1
                )
                
                draw(child)
            }
        }
        
        draw(manager.drama.rootSegment)
    }
}

#Preview {
    DramaFeedView()
}
