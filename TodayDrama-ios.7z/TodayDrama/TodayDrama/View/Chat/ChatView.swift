//
//  ChatView.swift
//  TodayDrama
//
//  Created by GH on 9/4/25.
//

import SwiftUI

struct ChatView: View {
    var body: some View {
        VStack {
            Text("聊天")
                .font(.largeTitle)
                .fontWeight(.bold)
        }
    }
}

#Preview {
    ChatView()
}
