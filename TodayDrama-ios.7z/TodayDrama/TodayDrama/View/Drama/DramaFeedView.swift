//
//  DramaFeedView.swift
//  TodayDrama
//
//  Created by GH on 9/4/25.
//

import AVKit
import SwiftUI

struct DramaFeedView: View {
    @State private var viewModel = DramaFeedViewModel()
    @State private var scrollPosition: Drama?
    @State private var hasInitialized = false
    @State private var showBranchTree = false
    
    var body: some View {
        ScrollView(showsIndicators: false) {
            LazyVStack(spacing: 0) {
                ForEach(Array(viewModel.managers.enumerated()), id: \.element.drama.id) { index, manager in
                    FeedCellView(player: viewModel.player, showBranchTree: $showBranchTree)
                        .environment(manager)
                        .id(manager.drama)
                }
            }
            .scrollTargetLayout()
        }
        .scrollPosition(id: $scrollPosition)
        .scrollTargetBehavior(.paging)
        .scrollDisabled(showBranchTree)
        .ignoresSafeArea()
        .background(.black)
        .onAppear {
            viewModel.loadInitDramas()
        }
        .onChange(of: viewModel.managers.count) { _, newCount in
            if !hasInitialized && newCount > 0 {
                hasInitialized = true
                scrollPosition = viewModel.managers.first?.drama
            }
        }
        .onChange(of: scrollPosition) { oldPosition, newPosition in
            guard let currentDrama = newPosition else { return }
            print("\(oldPosition?.title ?? "nil") -> \(currentDrama.title)")
            viewModel.activateDrama(currentDrama)
            
            // 检查是否滚动到最后一个 Drama
            if let lastDrama = viewModel.managers.last?.drama,
               currentDrama.id == lastDrama.id {
                print("[DramaFeedView] 滚动到最后一个 Drama，开始加载更多数据")
                viewModel.loadMoreDramas()
            }
        }
        .onDisappear {
            viewModel.cleanup()
        }
        .overlay {
            if showBranchTree {
                if let currentDrama = scrollPosition,
                   let manager = viewModel.managers.first(where: { $0.drama.id == currentDrama.id }) {
                    TreeView(viewModel: viewModel, showBranchTree: $showBranchTree)
                        .environment(manager)
                }
            }
        }
        .overlay(alignment: .topTrailing) {
            Circle()
                .fill(.black.opacity(0.3))
                .frame(height: 48)
                .overlay {
                    Image(systemName: showBranchTree ? "xmark" : "point.3.connected.trianglepath.dotted")
                        .font(.title2)
                        .foregroundStyle(.white)
                }
                .onTapGesture {
                    showBranchTree.toggle()
                }
                .padding(.trailing, 24)
        }
        .overlay(alignment: .bottom) {
            if viewModel.isLoading {
                HStack {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        .scaleEffect(0.8)
                    Text("加载更多...")
                        .font(.caption)
                        .foregroundStyle(.white)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(.black.opacity(0.6))
                .clipShape(.rect(cornerRadius: 20))
                .padding(.bottom, 80)
            }
        }
    }
}

#Preview {
    DramaFeedView()
}
