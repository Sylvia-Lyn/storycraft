import type { BranchOptionDTO, SegmentDTO } from '@/api/types';
import { dramaService } from '@/services/dramaService';
import { useAuthStore } from '@/store/authStore';
import type { DramaListItem } from '@/store/dramaStore';
import { Ionicons } from '@expo/vector-icons';
import { useIsFocused } from '@react-navigation/native';
import { usePathname, useRouter } from 'expo-router';
import { VideoView, useVideoPlayer } from 'expo-video';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Dimensions, FlatList, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const { height: SCREEN_HEIGHT } = Dimensions.get('window');

// 视频项数据结构
interface VideoItem {
  drama: DramaListItem;
  segment: SegmentDTO | null;
  videoUrl: string | null;
  posterUrl: string | null; // 封面图URL
  index: number;
  isInBranch?: boolean; // 是否在分支视频中
}

export default function DreamScreen() {
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [scrollEnabled, setScrollEnabled] = useState(true); // 控制滚动启用/禁用
  const [currentVideoInBranch, setCurrentVideoInBranch] = useState(false); // 当前视频是否在分支中

  const router = useRouter();
  const pathname = usePathname();
  const insets = useSafeAreaInsets();
  const isFocused = useIsFocused();
  const flatListRef = useRef<FlatList>(null);
  const isCorrectingScrollRef = useRef(false); // 防止递归纠正

  // 获取认证状态
  const { isAuthenticated } = useAuthStore();

  // 视频URL缓存
  const segmentCache = useRef<Map<number, { segment: SegmentDTO; url: string }>>(new Map());

  // 上次切换时间 - 用于节流控制
  const lastScrollTime = useRef<number>(0);
  const SCROLL_THROTTLE_MS = 1000; // 1秒内只能切换一次

  // 检查登录状态，未登录则跳转到profile页面
  useEffect(() => {
    if (!isAuthenticated && isFocused) {
      console.log('用户未登录，跳转到引导页面');
      // 使用 setTimeout 确保在下一个事件循环中执行导航
      const timer = setTimeout(() => {
        router.replace('/(tabs)/profile');
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [isAuthenticated, isFocused, router]);

  // 加载第一页视频
  useEffect(() => {
    if (isAuthenticated) {
      loadInitialVideos();
    }
  }, [isAuthenticated]);

  // 加载初始视频列表
  const loadInitialVideos = async () => {
    try {
      setIsLoading(true);
      setError(null);
      setScrollEnabled(false); // 初始加载时禁用滚动

      const result = await dramaService.fetchDramaListByPage(1, 10);
      console.log(result)
      if (!result.records || result.records.length === 0) {
        throw new Error('暂无可播放的剧集');
      }

      // 转换为VideoItem格式
      const videoItems: VideoItem[] = result.records.map((drama, index) => ({
        drama,
        segment: null,
        videoUrl: null,
        posterUrl: null,
        index,
        isInBranch: false, // 初始视频不在分支中
      }));
      console.log('videoItems:',videoItems)
      setVideos(videoItems);
      setHasMore(result.hasMore);
      setCurrentPage(1);

      // 预加载前3个视频的URL和缓存
      await loadVideoUrls(videoItems.slice(0, 3));

      console.log('初始视频列表加载完成:', videoItems.length);
    } catch (err) {
      console.error('加载视频失败:', err);
      setError(err instanceof Error ? err.message : '加载失败');
    } finally {
      setIsLoading(false);
    }
  };

  // 加载更多视频
  const loadMoreVideos = useCallback(async () => {
    if (!hasMore || isLoadingMore) return;

    try {
      setIsLoadingMore(true);

      const nextPage = currentPage + 1;
      const result = await dramaService.fetchDramaListByPage(nextPage, 10);

      if (result.records && result.records.length > 0) {
        setVideos((prev) => {
          const newVideoItems: VideoItem[] = result.records.map((drama, index) => ({
            drama,
            segment: null,
            videoUrl: null,
            posterUrl: null,
            index: prev.length + index,
            isInBranch: false, // 初始视频不在分支中
          }));
          return [...prev, ...newVideoItems];
        });
        setHasMore(result.hasMore);
        setCurrentPage(nextPage);

        console.log('加载更多视频:', result.records.length);
      }
    } catch (err) {
      console.error('加载更多视频失败:', err);
    } finally {
      setIsLoadingMore(false);
    }
  }, [hasMore, isLoadingMore, currentPage]);

  // 加载视频URL（批量）
  const loadVideoUrls = useCallback(async (items: VideoItem[]) => {
    const promises = items.map(async (item) => {
      try {
        const drama = item.drama;
        let rootSegmentId: number | undefined;

        if ('rootSegment' in drama && drama.rootSegment && typeof drama.rootSegment === 'object' && 'id' in drama.rootSegment) {
          rootSegmentId = drama.rootSegment.id as number;
        } else if ('rootSegmentId' in drama) {
          rootSegmentId = drama.rootSegmentId as number;
        }

        if (!rootSegmentId) return;

        // 检查缓存
        if (segmentCache.current.has(rootSegmentId)) {
          const cached = segmentCache.current.get(rootSegmentId)!;
          item.segment = cached.segment;
          item.videoUrl = cached.url;
          return;
        }

        // 获取带缓存的片段信息
        const segment = await dramaService.getSegmentDetailWithCache(rootSegmentId);

        if (segment) {
          console.log(`✓ 加载segment ID=${rootSegmentId}:`, {
            hasUrl: !!segment.url,
            hasBranches: !!segment.branches,
            branchesCount: segment.branches?.length || 0,
            title: segment.title,
          });

          const url = segment.url || null;
          item.segment = segment;
          item.videoUrl = url;

          // 保存到缓存
          if (url) {
            segmentCache.current.set(rootSegmentId, { segment, url });
          }

          // 暂时禁用视频文件预加载
          // if (segment.url && !segment.cachedUrl) {
          //   dramaService.preloadSegmentVideo(rootSegmentId).catch((err) =>
          //     console.error('预加载失败:', err)
          //   );
          // }
        }
      } catch (err) {
        console.error('加载视频URL失败:', err);
      }
    });

    await Promise.all(promises);

    // 更新状态
    setVideos((prev) => [...prev]);
  }, []);

  // 监听当前视频的加载状态，加载完成后启用滚动
  useEffect(() => {
    const currentVideo = videos[currentIndex];
    if (currentVideo && currentVideo.videoUrl && !scrollEnabled) {
      // 当前视频已加载完成，启用滚动（带1秒延迟）
      const timer = setTimeout(() => {
        setScrollEnabled(true);
      }, SCROLL_THROTTLE_MS);

      return () => clearTimeout(timer);
    }
  }, [videos, currentIndex, scrollEnabled, SCROLL_THROTTLE_MS]);

  // 实时监控滚动位置，防止滑动超出相邻视频
  const onScroll = useCallback((event: any) => {
    // 如果正在纠正滚动，忽略此次事件
    if (isCorrectingScrollRef.current) {
      return;
    }

    const offsetY = event.nativeEvent.contentOffset.y;
    const currentScrollIndex = offsetY / SCREEN_HEIGHT;

    // 计算允许的最小和最大滚动位置
    const minAllowedIndex = Math.max(0, currentIndex - 1);
    const maxAllowedIndex = Math.min(videos.length - 1, currentIndex + 1);

    // 如果滚动超出允许范围，立即限制
    if (currentScrollIndex < minAllowedIndex - 0.15) {
      // 向上滑动超出范围，停在最小位置
      console.log(`⛔ 向上滑动超限，限制在位置 ${minAllowedIndex}`);
      isCorrectingScrollRef.current = true;

      flatListRef.current?.scrollToOffset({
        offset: minAllowedIndex * SCREEN_HEIGHT,
        animated: false,
      });

      setTimeout(() => {
        isCorrectingScrollRef.current = false;
      }, 100);
    } else if (currentScrollIndex > maxAllowedIndex + 0.15) {
      // 向下滑动超出范围，停在最大位置
      console.log(`⛔ 向下滑动超限，限制在位置 ${maxAllowedIndex}`);
      isCorrectingScrollRef.current = true;

      flatListRef.current?.scrollToOffset({
        offset: maxAllowedIndex * SCREEN_HEIGHT,
        animated: false,
      });

      setTimeout(() => {
        isCorrectingScrollRef.current = false;
      }, 100);
    }
  }, [currentIndex, videos.length]);

  // 当视频可见时触发
  const onViewableItemsChanged = useCallback(({ viewableItems }: any) => {
    if (viewableItems.length > 0) {
      const visibleItem = viewableItems[0];
      const index = visibleItem.index;

      // 如果索引没有变化，不处理
      if (index === currentIndex) {
        return;
      }

      // 严格控制：只允许切换到相邻的视频（上一个或下一个）
      const indexDiff = Math.abs(index - currentIndex);
      if (indexDiff > 1) {
        // 试图跳过多个视频，立即禁用滚动并强制滚回当前视频
        console.log(`❌ 禁止跳过视频：从 ${currentIndex} 到 ${index}`);
        setScrollEnabled(false);

        // 强制滚回当前视频
        setTimeout(() => {
          flatListRef.current?.scrollToIndex({
            index: currentIndex,
            animated: false,
          });
          // 延迟重新启用滚动
          setTimeout(() => {
            setScrollEnabled(true);
          }, 300);
        }, 0);
        return;
      }

      // 节流控制：检查距离上次切换是否超过1秒
      const now = Date.now();
      if (now - lastScrollTime.current < SCROLL_THROTTLE_MS) {
        // 距离上次切换不足1秒，禁止切换
        console.log(`⏱️ 切换过快，禁止从 ${currentIndex} 到 ${index}`);
        setScrollEnabled(false);

        // 强制滚回当前视频
        setTimeout(() => {
          flatListRef.current?.scrollToIndex({
            index: currentIndex,
            animated: false,
          });
          // 延迟重新启用滚动
          setTimeout(() => {
            setScrollEnabled(true);
          }, 300);
        }, 0);
        return;
      }

      // 允许切换：更新切换时间和索引
      console.log(`✅ 允许切换：从 ${currentIndex} 到 ${index}`);
      lastScrollTime.current = now;
      setCurrentIndex(index);

      // 暂时禁用滚动，防止连续滑动
      setScrollEnabled(false);

      // 检查当前视频是否已加载URL
      setVideos((currentVideos) => {
        const currentVideo = currentVideos[index];
        if (!currentVideo?.videoUrl) {
          // 当前视频未加载，保持禁用滚动直到加载完成
          console.log(`⏳ 视频 ${index} 未加载，等待加载完成`);
        } else {
          // 视频已加载，1秒后重新启用滚动
          setTimeout(() => {
            setScrollEnabled(true);
          }, SCROLL_THROTTLE_MS);
        }
        return currentVideos;
      });

      // 预加载前后视频
      setVideos((currentVideos) => {
        const toPreload: VideoItem[] = [];

        // 前一个
        if (index > 0 && currentVideos[index - 1] && !currentVideos[index - 1].videoUrl) {
          toPreload.push(currentVideos[index - 1]);
        }

        // 后一个
        if (index + 1 < currentVideos.length && currentVideos[index + 1] && !currentVideos[index + 1].videoUrl) {
          toPreload.push(currentVideos[index + 1]);
        }

        // 后两个
        if (index + 2 < currentVideos.length && currentVideos[index + 2] && !currentVideos[index + 2].videoUrl) {
          toPreload.push(currentVideos[index + 2]);
        }

        if (toPreload.length > 0) {
          loadVideoUrls(toPreload);
        }

        // 接近末尾时加载更多
        if (index >= currentVideos.length - 5) {
          loadMoreVideos();
        }

        return currentVideos;
      });
    }
  }, [loadVideoUrls, loadMoreVideos, SCROLL_THROTTLE_MS, currentIndex]);

  // 滑动结束后确保对齐到完整视频
  const onMomentumScrollEnd = useCallback((event: any) => {
    const offsetY = event.nativeEvent.contentOffset.y;
    const targetIndex = Math.round(offsetY / SCREEN_HEIGHT);

    // 严格限制：只能在当前视频或相邻视频上
    const validIndices = [currentIndex - 1, currentIndex, currentIndex + 1];

    if (!validIndices.includes(targetIndex)) {
      // 不是有效的位置，强制滚回当前视频
      console.log(`❌ 滑动结束位置无效：${targetIndex}，强制滚回 ${currentIndex}`);
      flatListRef.current?.scrollToIndex({
        index: currentIndex,
        animated: false,
      });
      return;
    }

    // 如果没有完全对齐，强制对齐到目标位置
    if (Math.abs(offsetY - targetIndex * SCREEN_HEIGHT) > 1) {
      console.log(`对齐视频位置：${targetIndex}`);
      flatListRef.current?.scrollToIndex({
        index: targetIndex,
        animated: true,
      });
    }
  }, [currentIndex]);

  const viewabilityConfig = useRef({
    viewAreaCoveragePercentThreshold: 50, // 降低到50%，当视频超过一半可见时才算可见
    minimumViewTime: 300, // 至少可见300ms才触发
    waitForInteraction: false,
  }).current;

  // 渲染每个视频项
  const renderItem = ({ item }: { item: VideoItem }) => {
    return (
      <VideoItemComponent
        item={item}
        isActive={currentIndex === item.index}
        isFocused={isFocused}
        insets={insets}
        onBranchStatusChange={setCurrentVideoInBranch}
      />
    );
  };

  // 未登录状态 - 显示空白页面，等待跳转
  if (!isAuthenticated) {
    return (
      <View style={[styles.container, styles.centerContent]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FFFFFF" />
        </View>
      </View>
    );
  }

  // 加载状态
  if (isLoading && videos.length === 0) {
    return (
      <View style={[styles.container, styles.centerContent]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FFFFFF" />
        </View>
      </View>
    );
  }

  // 错误状态
  if (error && videos.length === 0) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity style={styles.retryButton} onPress={loadInitialVideos}>
          <Text style={styles.retryButtonText}>点击重试</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        ref={flatListRef}
        data={videos}
        renderItem={renderItem}
        keyExtractor={(item) => `video-${item.index}`}
        pagingEnabled
        showsVerticalScrollIndicator={false}
        decelerationRate="fast"
        snapToInterval={SCREEN_HEIGHT}
        snapToAlignment="start"
        disableIntervalMomentum={true}
        windowSize={3}
        maxToRenderPerBatch={2}
        initialNumToRender={1}
        removeClippedSubviews
        scrollEnabled={scrollEnabled && !currentVideoInBranch}
        onScroll={onScroll}
        scrollEventThrottle={16}
        onViewableItemsChanged={onViewableItemsChanged}
        onMomentumScrollEnd={onMomentumScrollEnd}
        viewabilityConfig={viewabilityConfig}
        ListFooterComponent={
          isLoadingMore ? (
            <View style={styles.footerLoader}>
              <ActivityIndicator size="small" color="#FFFFFF" />
            </View>
          ) : null
        }
      />

      {/* 自定义 Tab Bar */}
      <View style={[styles.customTabBar, { height: 40 + insets.bottom, paddingBottom: insets.bottom }]}>
        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => router.push('/(tabs)/dream')}
        >
          <Text style={[styles.tabText, pathname === '/dream' && styles.tabTextActive]}>
            叙梦
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => router.push('/(tabs)/profile')}
        >
          <Text style={[styles.tabText, pathname === '/profile' && styles.tabTextActive]}>
            我的
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// 单个视频组件
function VideoItemComponent({
  item,
  isActive,
  isFocused,
  insets,
  onBranchStatusChange,
}: {
  item: VideoItem;
  isActive: boolean;
  isFocused: boolean;
  insets: any;
  onBranchStatusChange: (isInBranch: boolean) => void;
}) {
  // 如果是激活状态，初始就设置为播放中
  const [isPlaying, setIsPlaying] = useState(isActive && isFocused);
  const [progress, setProgress] = useState(0);
  const [userPaused, setUserPaused] = useState(false); // 跟踪是否用户手动暂停
  const [showPoster, setShowPoster] = useState(true); // 显示封面
  const [showOptions, setShowOptions] = useState(false); // 显示选项蒙层
  const [countdown, setCountdown] = useState(10); // 倒计时
  const [isVideoEnded, setIsVideoEnded] = useState(false); // 视频是否播放结束
  const [isInBranch, setIsInBranch] = useState(false); // 是否在分支视频中
  const playerRef = useRef<any>(null);
  const countdownTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const isReplacingVideoRef = useRef(false); // 标记是否正在切换视频

  // 保存初始视频信息
  const initialSegmentRef = useRef<SegmentDTO | null>(null);
  const initialVideoUrlRef = useRef<string | null>(null);
  const initialTitleRef = useRef<string | null>(null);

  // 手势防抖：记录上次触发时间
  const lastGestureTimeRef = useRef<number>(0);
  const lastTapTimeRef = useRef<number>(0);
  const isProcessingGestureRef = useRef<boolean>(false); // 防止重复处理
  const GESTURE_DEBOUNCE_MS = 1000; // 500毫秒防抖
  const TAP_DEBOUNCE_MS = 300; // 点击防抖300毫秒

  console.log(item.videoUrl)

  // 保存初始视频信息（仅在第一次加载时）
  useEffect(() => {
    if (item.segment && item.videoUrl && !initialSegmentRef.current) {
      initialSegmentRef.current = item.segment;
      initialVideoUrlRef.current = item.videoUrl;
      initialTitleRef.current = item.drama?.title || null;
      console.log('保存初始视频信息:', {
        title: initialTitleRef.current,
        hasSegment: !!initialSegmentRef.current,
        hasUrl: !!initialVideoUrlRef.current,
      });
    }
  }, [item.segment, item.videoUrl, item.drama?.title]);

  // 监听 isInBranch 状态变化，通知父组件
  useEffect(() => {
    onBranchStatusChange(isInBranch);
  }, [isInBranch, onBranchStatusChange]);

  // 选择选项
  const handleSelectOption = useCallback(async (option: BranchOptionDTO) => {
    console.log('选择了选项:', option);

    // 设置正在切换视频的标志
    isReplacingVideoRef.current = true;

    // 清除倒计时
    if (countdownTimerRef.current) {
      clearInterval(countdownTimerRef.current);
    }
    setShowOptions(false);

    // 标记进入分支视频
    setIsInBranch(true);
    item.isInBranch = true; // 更新VideoItem的isInBranch标志

    // 加载下一个片段的视频
    if (option.nextSegmentId) {
      try {
        // 1. 先用选项里segment对象的url立即播放下一个视频
        if (option.segment?.url) {
          console.log('使用选项segment的URL播放:', option.segment.url);
          item.videoUrl = option.segment.url;

          // 更新标题
          if (option.segment.title) {
            item.drama.title = option.segment.title;
          }

          // 立即播放新视频（只有当前视频才播放）
          if (playerRef.current && isActive && isFocused) {
            playerRef.current.replace(option.segment.url);
            playerRef.current.currentTime = 0;
            playerRef.current.play();
            setIsPlaying(true);
            setUserPaused(false);
            setShowPoster(false);
            setIsVideoEnded(false);

            // 延迟重置标志，确保视频切换完成
            setTimeout(() => {
              isReplacingVideoRef.current = false;
            }, 500);
          } else if (playerRef.current) {
            // 如果不是当前视频，只替换源，不播放
            playerRef.current.replace(option.segment.url);
            setTimeout(() => {
              isReplacingVideoRef.current = false;
            }, 500);
          }
        }

        // 2. 用nextSegmentId请求完整的segment信息（包含选择题branches）
        console.log('请求完整的segment信息:', option.nextSegmentId);
        const nextSegmentDetail = await dramaService.getSegmentDetailWithCache(option.nextSegmentId);

        if (nextSegmentDetail) {
          console.log('✓ 获取到完整的segment信息:', {
            segmentId: option.nextSegmentId,
            hasUrl: !!nextSegmentDetail.url,
            hasBranches: !!nextSegmentDetail.branches,
            branchesCount: nextSegmentDetail.branches?.length || 0,
            title: nextSegmentDetail.title,
            branches: nextSegmentDetail.branches,
          });

          // 更新item的segment（包含branches信息）
          item.segment = nextSegmentDetail;

          // 更新标题（使用完整segment的title）
          if (nextSegmentDetail.title) {
            item.drama.title = nextSegmentDetail.title;
          }

          // 如果之前没有URL，现在更新
          if (!option.segment?.url && nextSegmentDetail.url) {
            item.videoUrl = nextSegmentDetail.url;
            if (playerRef.current && isActive && isFocused) {
              playerRef.current.replace(nextSegmentDetail.url);
              playerRef.current.currentTime = 0;
              playerRef.current.play();
              setIsPlaying(true);
              setUserPaused(false);
              setShowPoster(false);
              setIsVideoEnded(false);

              // 延迟重置标志，确保视频切换完成
              setTimeout(() => {
                isReplacingVideoRef.current = false;
              }, 500);
            } else if (playerRef.current) {
              // 如果不是当前视频，只替换源，不播放
              playerRef.current.replace(nextSegmentDetail.url);
              setTimeout(() => {
                isReplacingVideoRef.current = false;
              }, 500);
            }
          } else if (!option.segment?.url && !nextSegmentDetail.url) {
            // 如果两者都没有URL，立即重置标志
            isReplacingVideoRef.current = false;
          }
        }
      } catch (error) {
        console.error('加载下一个片段失败:', error);
        // 出错时也要重置标志
        isReplacingVideoRef.current = false;
      }
    } else {
      // 如果没有nextSegmentId，重置标志
      isReplacingVideoRef.current = false;
    }
  }, [item, isActive, isFocused]);

  // 自动选择
  const handleAutoSelect = useCallback(() => {
    if (!item.segment) return;

    // 优先选择默认选项，否则选第一个
    const defaultOption = item.segment.branches?.find(
      (b) => b.nextSegmentId === item.segment?.defaultSegmentId
    );
    const selectedOption = defaultOption || item.segment.branches?.[0];

    if (selectedOption) {
      handleSelectOption(selectedOption);
    }
  }, [item.segment, handleSelectOption]);

  // 返回到初始视频
  const handleBackToInitial = useCallback(() => {
    if (!initialSegmentRef.current || !initialVideoUrlRef.current) {
      console.log('没有初始视频信息，无法返回');
      return;
    }

    console.log('返回到初始视频');

    // 设置正在切换视频的标志
    isReplacingVideoRef.current = true;

    // 清除倒计时
    if (countdownTimerRef.current) {
      clearInterval(countdownTimerRef.current);
    }

    // 重置所有状态
    setShowOptions(false);
    setIsVideoEnded(false);
    setUserPaused(false);
    setShowPoster(false);
    setIsInBranch(false);
    setCountdown(10);
    item.isInBranch = false; // 重置VideoItem的isInBranch标志

    // 恢复初始视频信息
    item.segment = initialSegmentRef.current;
    item.videoUrl = initialVideoUrlRef.current;
    if (initialTitleRef.current) {
      item.drama.title = initialTitleRef.current;
    }

    // 播放初始视频（只有当前视频才播放）
    if (playerRef.current && isActive && isFocused) {
      playerRef.current.replace(initialVideoUrlRef.current);
      playerRef.current.currentTime = 0;
      playerRef.current.play();
      setIsPlaying(true);

      // 延迟重置标志，确保视频切换完成
      setTimeout(() => {
        isReplacingVideoRef.current = false;
      }, 500);
    } else if (playerRef.current) {
      // 如果不是当前视频，只替换源，不播放
      playerRef.current.replace(initialVideoUrlRef.current);
      setTimeout(() => {
        isReplacingVideoRef.current = false;
      }, 500);
    }
  }, [item, isActive, isFocused]);

  // 开始倒计时
  const startCountdown = useCallback(() => {
    // 清除之前的定时器
    if (countdownTimerRef.current) {
      clearInterval(countdownTimerRef.current);
    }

    countdownTimerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          // 倒计时结束，自动选择第一个选项或默认选项
          if (countdownTimerRef.current) {
            clearInterval(countdownTimerRef.current);
          }
          handleAutoSelect();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }, [handleAutoSelect]);

  // 创建视频播放器 - 监听 videoUrl 变化
  const player = useVideoPlayer(item.videoUrl || '', (player) => {
    playerRef.current = player;
    if (item.videoUrl) {
      try {
        player.loop = false; // 不循环播放
        player.muted = false; // 确保不静音
        player.volume = 1.0; // 设置音量为最大

        // 监听播放状态变化，视频开始播放时隐藏封面
        player.addListener('playingChange', (event: { isPlaying: boolean; oldIsPlaying: boolean }) => {
          if (event.isPlaying) {
            setShowPoster(false);
            setIsVideoEnded(false); // 开始播放时重置结束标志
          } else {
            // 如果正在切换视频，忽略此事件
            if (isReplacingVideoRef.current) {
              console.log('正在切换视频，忽略播放状态变化');
              return;
            }

            // 视频暂停或结束时，检查是否播放完成
            if (player.currentTime >= player.duration - 0.1) {
              // 视频播放结束
              console.log('视频播放结束，branches数量:', item.segment?.branches?.length || 0);

              setIsPlaying(false);
              setShowPoster(true);
              setIsVideoEnded(true); // 标记视频已结束

              // 如果有分支选项，显示选项蒙层并开始倒计时
              if (item.segment?.branches && item.segment.branches.length > 0) {
                setShowOptions(true);
                setCountdown(10);
                startCountdown();
              }
            }
          }
        });

        if (isActive && isFocused) {
          player.currentTime = 0;
          player.play();
          setIsPlaying(true);
        } else {
          // 非激活状态下，暂停在第一帧作为封面
          player.currentTime = 0;
        }
      } catch (err) {
        console.error('播放器初始化失败:', err);
      }
    }
  });

  // 当videoUrl更新时，替换播放源（但不自动播放）
  useEffect(() => {
    if (!player || !item.videoUrl) return;

    try {
      player.replace(item.videoUrl);
      // 不自动播放，等待 isActive 和 isFocused 的 effect 来控制播放
    } catch (error) {
      console.error('更新视频源失败:', error);
    }
  }, [item.videoUrl, player]);

  // 监听播放状态 - 这是唯一控制播放/暂停的地方
  useEffect(() => {
    if (!player || !item.videoUrl) return;

    try {
      if (isActive && isFocused) {
        // 只有当前视频且页面获得焦点时才播放
        console.log(`视频 ${item.index} 开始播放`);
        player.currentTime = 0;
        player.play();
        setIsPlaying(true);
        setProgress(0);
        setUserPaused(false); // 重置用户暂停标志
        setIsVideoEnded(false); // 重置视频结束标志
        // 播放时不显示封面
        setShowPoster(false);
      } else {
        // 不是当前视频或页面失去焦点时暂停
        console.log(`视频 ${item.index} 暂停播放`);
        player.pause();
        setIsPlaying(false);
        // 暂停时显示封面（第一帧）
        setShowPoster(true);
      }
    } catch (error) {
      console.error('切换播放状态失败:', error);
    }
  }, [isActive, isFocused, player, item.videoUrl, item.index]);

  // 监听播放进度
  useEffect(() => {
    if (!player || !isActive) return;

    const interval = setInterval(() => {
      try {
        if (player.duration > 0) {
          setProgress((player.currentTime / player.duration) * 100);
        }
      } catch (error) {
        // 忽略进度更新错误
      }
    }, 100);

    return () => clearInterval(interval);
  }, [player, isActive]);

  // 切换播放/暂停
  const togglePlayPause = useCallback(() => {
    if (!playerRef.current) return;

    try {
      if (isPlaying) {
        playerRef.current.pause();
        setIsPlaying(false);
        setUserPaused(true); // 标记为用户手动暂停

        // 暂停时如果有分支选项，显示选项蒙层并开始倒计时
        // if (item.segment?.branches && item.segment.branches.length > 0) {
        //   console.log('显示选项蒙层，branches数量:', item.segment.branches.length);
        //   setShowOptions(true);
        //   setCountdown(10);
        //   startCountdown();
        // }
      } else {
        playerRef.current.play();
        setIsPlaying(true);
        setUserPaused(false); // 取消暂停标志

        // 继续播放时隐藏选项蒙层（如果是用户主动播放）
        // if (showOptions) {
        //   setShowOptions(false);
        //   // 清除倒计时
        //   if (countdownTimerRef.current) {
        //     clearInterval(countdownTimerRef.current);
        //   }
        // }
      }
    } catch (error) {
      console.error('切换播放状态失败:', error);
    }
  }, [isPlaying, item.segment, showOptions, startCountdown]);

  // 清理倒计时
  useEffect(() => {
    return () => {
      if (countdownTimerRef.current) {
        clearInterval(countdownTimerRef.current);
      }
    };
  }, []);

  // 手势识别：使用 Pan 手势检测滑动方向
  const panGesture = Gesture.Pan()
    .onEnd((event) => {
      // 防止重复处理
      if (isProcessingGestureRef.current) {
        return;
      }

      const { translationX, translationY } = event;
      const now = Date.now();

      // 统一的防抖检查 - 在开始就检查
      if (now - lastGestureTimeRef.current < GESTURE_DEBOUNCE_MS) {
        console.log('手势触发过快，已忽略');
        return;
      }

      // 标记正在处理
      isProcessingGestureRef.current = true;
      // 立即更新时间戳
      lastGestureTimeRef.current = now;

      // 判断是水平还是垂直滑动（取绝对值较大的方向）
      if (Math.abs(translationX) > Math.abs(translationY)) {
        // 水平滑动
        if (translationX > 50) {
          console.log('右滑');
        } else if (translationX < -50) {
          console.log('左滑');
        }
      } else {
        // 垂直滑动
        if (translationY > 50) {
          console.log('下滑');
        } else if (translationY < -50) {
          console.log('上滑');
        }
      }

      // 延迟重置处理标志，避免同一次手势被多次处理
      setTimeout(() => {
        isProcessingGestureRef.current = false;
      }, 100);
    });

  // 点击手势（替代 TouchableOpacity 的 onPress）
  const tapGesture = Gesture.Tap()
    .onEnd(() => {
      // 点击防抖检查
      const now = Date.now();
      if (now - lastTapTimeRef.current < TAP_DEBOUNCE_MS) {
        console.log('点击过快，已忽略');
        return;
      }
      lastTapTimeRef.current = now;
      togglePlayPause();
    });

  // 组合手势
  const composedGestures = Gesture.Race(panGesture, tapGesture);

  return (
    <View style={styles.videoContainer}>
      <GestureDetector gesture={composedGestures}>
        <View
          style={styles.videoTouchArea}
        >
        {item.videoUrl ? (
          <VideoView
            player={player}
            style={styles.video}
            contentFit="cover"
            allowsFullscreen={false}
            allowsPictureInPicture={false}
            nativeControls={false}
          />
        ) : (
          <View style={styles.loadingOverlay}>
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#ffffff" />
            </View>
          </View>
        )}

        {/* 顶部标题栏 */}
        <View style={[styles.topBar, { height: 80 + insets.top, paddingTop: insets.top }]}>
          {/* 返回箭头 - 仅在分支视频中显示 */}
          {isInBranch && (
            <TouchableOpacity
              style={styles.backButton}
              onPress={handleBackToInitial}
              activeOpacity={0.7}
            >
              <Ionicons name="chevron-back" size={18} color="#FFFFFF" />
            </TouchableOpacity>
          )}
          {/* 占位符 - 保持标题居中 */}
          {!isInBranch && <View style={styles.backButton} />}

          <Text style={styles.topBarTitle} numberOfLines={1}>
            {item.drama?.title || ''}
          </Text>

          {/* 右侧占位符 - 保持标题居中 */}
          <View style={styles.backButton} />
        </View>

        {/* 播放/暂停指示器 - 只有用户手动暂停时才显示 */}
        {userPaused && item.videoUrl && isActive && (
          <View style={styles.touchArea}>
            <Image
              source={require('@/assets/drama/play.png')}
              style={styles.playIcon}
            />
          </View>
        )}

        {/* 进度条 */}
        {item.videoUrl && (
          <View style={[styles.progressBarContainer, { bottom: 40 + insets.bottom }]}>
            <View style={[styles.progressBar, { width: `${progress}%` }]}>
              <View style={styles.progressThumb} />
            </View>
          </View>
        )}

        {/* 选项蒙层 */}
        {showOptions && item.segment && (
          <View style={[styles.optionsOverlay, { bottom: 40 + insets.bottom }]}>
            <View style={styles.optionsContainer}>
              {/* 标题和倒计时分两行 */}
              {/* 问题标题 - 左对齐 */}
              <Text style={styles.questionTitle}>{item.segment.title}</Text>
              {/* 倒计时 - 右对齐 */}
              <Text style={styles.countdownText}>{countdown}秒后自动选择</Text>

              {/* 选项列表 */}
              <View style={styles.optionsList}>
                {item.segment.branches?.map((option, index) => (
                  <TouchableOpacity
                    key={option.id}
                    style={styles.optionButton}
                    onPress={() => handleSelectOption(option)}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.optionLabel}>
                      {String.fromCharCode(65 + index)}：{option.title}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* 底部按钮 */}
              <View style={styles.optionsButtons}>
                <TouchableOpacity
                  style={styles.replayButton}
                  onPress={() => {
                    // 再看一遍 - 从头播放
                    if (playerRef.current) {
                      playerRef.current.currentTime = 0;
                      playerRef.current.play();
                      setShowOptions(false);
                      setIsVideoEnded(false);
                      setIsPlaying(true);
                      setUserPaused(false); // 重置用户暂停标志
                      setShowPoster(false); // 隐藏封面
                      if (countdownTimerRef.current) {
                        clearInterval(countdownTimerRef.current);
                      }
                    }
                  }}
                >
                  <Text style={styles.replayButtonText}>再看一遍</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}


      </View>
      </GestureDetector>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000',
  },
  centerContent: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingContainer: {
    width: 100,
    height: 100,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backdropFilter: 'blur(10px)',
  },
  errorText: {
    fontSize: 16,
    color: '#FF4444',
    textAlign: 'center',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  retryButtonText: {
    color: '#000000',
    fontSize: 16,
    fontWeight: '600',
  },
  videoContainer: {
    height: SCREEN_HEIGHT,
    width: '100%',
    backgroundColor: '#000000', // 黑色背景避免闪烁
  },
  videoTouchArea: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  video: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    width: '100%',
    height: '100%',
  },
  loadingOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  touchArea: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    pointerEvents: 'none',
  },
  playIcon: {
    width: 220,
    height: 220,
  },
  progressBarContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    pointerEvents: 'none',
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#FFFFFF',
    position: 'relative',
    justifyContent: 'center',
  },
  progressThumb: {
    position: 'absolute',
    right: -3,
    top: -3,
    width: 9,
    height: 9,
    borderRadius: 4.5,
    backgroundColor: '#FFFFFF',
  },
  infoContainer: {
    position: 'absolute',
    left: 20,
    right: 20,
    pointerEvents: 'none',
  },
  infoText: {
    color: '#FFFFFF',
    fontSize: 14,
    marginBottom: 8,
  },
  titleText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  topBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 80,
    backgroundColor: 'rgba(0, 0, 0, 0.2)', // 半透明黑色背景
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    pointerEvents: 'box-none', // 允许子元素响应点击
  },
  backButton: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
    marginLeft: -8,
    pointerEvents: 'auto', // 确保按钮可点击
  },
  topBarTitle: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '600',
    textAlign: 'center',
    paddingHorizontal: 20,
  },
  customTabBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 40,
    flexDirection: 'row',
    backgroundColor: 'rgba(0, 0, 0, 0.5)', // 半透明黑色背景
    backdropFilter: 'blur(10px)', // 模糊效果（iOS支持）
  },
  tabItem: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    height: 40,
  },
  tabText: {
    fontSize: 16,
    fontWeight: '500',
    color: 'rgba(255, 255, 255, 0.6)', // 调整未激活颜色，更柔和
  },
  tabTextActive: {
    color: '#FFFFFF',
  },
  footerLoader: {
    height: SCREEN_HEIGHT,
    justifyContent: 'center',
    alignItems: 'center',
  },
  optionsOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'flex-end',
    paddingTop: 40,
    paddingBottom: 40,
    paddingLeft: 50,
    paddingRight: 20,
  },
  optionsContainer: {
    width: '100%',
  },
  questionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'left',
    marginBottom: 10,
  },
  countdownText: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.7)',
    textAlign: 'right',
    marginBottom: 20,
  },
  optionsList: {
    gap: 15,
    marginBottom: 20,
  },
  optionButton: {
    backgroundColor: 'rgba(30, 30, 30, 1)',
    borderRadius: 16,
    height: 53,
    justifyContent: 'center',
    paddingHorizontal: 15,
  },
  optionLabel: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'left',
  },
  optionsButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 15,
  },
  replayButton: {
    width: 145,
    height: 53,
    backgroundColor: 'transparent',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  replayButtonText: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '400',
  },
});
