
import { useAuthStore } from '@/store/authStore';

export function LoginExample() {
  const login = useAuthStore((state) => state.login);

  const handleLogin = async (phone: string, password: string) => {
    try {
      const response = await fetch('YOUR_API_URL/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, password }),
      });

      const data = await response.json();

      login({
        user: data.user,
        token: data.token,
        refreshToken: data.refreshToken,
      });

    } catch (error) {
      console.error('Login failed:', error);
    }
  };
}

export function RegisterExample() {
  const login = useAuthStore((state) => state.login);

  const handleRegister = async (userData: any) => {
    try {
      const response = await fetch('YOUR_API_URL/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
      });

      const data = await response.json();

      login({
        user: data.user,
        token: data.token,
      });

    } catch (error) {
      console.error('Register failed:', error);
    }
  };
}

export function UserProfileExample() {
  const user = useAuthStore((state) => state.user);
  const updateUser = useAuthStore((state) => state.updateUser);

  const handleUpdateProfile = (newData: any) => {
    updateUser(newData);

  };
}

export function LogoutExample() {
  const logout = useAuthStore((state) => state.logout);

  const handleLogout = () => {
    logout();
  };
}

export function AuthCheckExample() {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const checkAuthStatus = useAuthStore((state) => state.checkAuthStatus);

  useEffect(() => {
    if (!checkAuthStatus()) {
    }
  }, []);
}

export function ApiRequestExample() {
  const token = useAuthStore((state) => state.token);

  const fetchUserData = async () => {
    const response = await fetch('YOUR_API_URL/user', {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    });

    return response.json();
  };
}

export function AppInitExample() {
  const initAuth = useAuthStore((state) => state.initAuth);
  const isLoading = useAuthStore((state) => state.isLoading);

  useEffect(() => {
    initAuth();
  }, []);

  if (isLoading) {
    return <LoadingScreen />;
  }
}
