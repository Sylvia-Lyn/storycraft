//
//  Keychain.swift
//  TodayDrama
//
//  Created by GH on 9/3/25.
//

import Foundation
import KeychainSwift

enum Keychain {
    static func save(_ key: String, value: String) {
        KeychainSwift().set(value, forKey: key, withAccess: .accessibleAfterFirstUnlock)
    }
    
    static func get(_ key: String) -> String? { KeychainSwift().get(key) }
    
    static func delete(_ key: String) { KeychainSwift().delete(key) }
}
