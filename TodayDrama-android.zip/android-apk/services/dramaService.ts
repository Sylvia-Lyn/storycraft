// 剧集服务 - 处理所有与剧集相关的业务逻辑
import { BranchOptionApi, DramaApi, SegmentApi } from '@/api';
import type { DramaEntity, PageQueryRequest, PlaybackProgressForm, SegmentDTO } from '@/api/types';
import { useDramaStore } from '@/store/dramaStore';
import * as FileSystem from 'expo-file-system/legacy';
import AsyncStorage from '@react-native-async-storage/async-storage';

// 视频缓存管理
class VideoCache {
  private static CACHE_DIR = `${FileSystem.cacheDirectory}videos/`;
  private static CACHE_INDEX_KEY = 'video_cache_index';
  private static MAX_CACHE_SIZE = 500 * 1024 * 1024; // 500MB

  // 初始化缓存目录
  static async init() {
    try {
      const dirInfo = await FileSystem.getInfoAsync(this.CACHE_DIR);
      if (!dirInfo.exists) {
        await FileSystem.makeDirectoryAsync(this.CACHE_DIR, { intermediates: true });
      }
    } catch (error) {
      console.error('初始化缓存目录失败:', error);
    }
  }

  // 获取缓存的视频路径
  static async getCachedVideoPath(url: string, segmentId: number): Promise<string> {
    // 暂时禁用本地缓存，直接返回远程URL
    console.log(`使用远程URL播放视频: ${segmentId}`);

    // 异步预加载到缓存（不阻塞，静默失败）
    this.preloadVideoSilently(url, segmentId);

    return url;
  }

  // 静默预加载（不抛出错误）
  private static async preloadVideoSilently(url: string, segmentId: number): Promise<void> {
    try {
      await this.preloadVideo(url, segmentId);
    } catch (error) {
      // 静默失败，不影响主流程
      // console.error('后台缓存失败:', error);
    }
  }

  // 预下载视频（不阻塞）
  static async preloadVideo(url: string, segmentId: number): Promise<void> {
    try {
      await this.init();

      const fileName = `video_${segmentId}.mp4`;
      const filePath = `${this.CACHE_DIR}${fileName}`;
      const fileInfo = await FileSystem.getInfoAsync(filePath);

      if (fileInfo.exists) {
        console.log(`视频已缓存: ${fileName}`);
        return;
      }

      console.log(`开始预加载视频: ${fileName}`);
      const downloadResult = await FileSystem.downloadAsync(url, filePath);

      if (downloadResult.status === 200) {
        await this.updateCacheIndex(segmentId, filePath, url);
        await this.cleanupIfNeeded();
        console.log(`视频预加载成功: ${fileName}`);
      }
    } catch (error) {
      console.error('预加载视频失败:', error);
    }
  }

  // 更新缓存索引
  private static async updateCacheIndex(
    segmentId: number,
    filePath: string,
    url: string
  ): Promise<void> {
    try {
      const indexStr = await AsyncStorage.getItem(this.CACHE_INDEX_KEY);
      const index = indexStr ? JSON.parse(indexStr) : {};

      index[segmentId] = {
        filePath,
        url,
        timestamp: Date.now(),
      };

      await AsyncStorage.setItem(this.CACHE_INDEX_KEY, JSON.stringify(index));
    } catch (error) {
      console.error('更新缓存索引失败:', error);
    }
  }

  // 清理缓存（如果超过限制）
  private static async cleanupIfNeeded(): Promise<void> {
    try {
      const dirInfo = await FileSystem.getInfoAsync(this.CACHE_DIR);
      if (!dirInfo.exists) return;

      // 获取所有缓存文件
      const files = await FileSystem.readDirectoryAsync(this.CACHE_DIR);
      let totalSize = 0;

      const fileInfos = await Promise.all(
        files.map(async (file) => {
          const filePath = `${this.CACHE_DIR}${file}`;
          const info = await FileSystem.getInfoAsync(filePath);
          if (info.exists && 'size' in info) {
            totalSize += info.size;
            return {
              path: filePath,
              size: info.size,
              modificationTime: info.modificationTime || 0,
            };
          }
          return null;
        })
      );

      // 如果超过限制，删除最旧的文件
      if (totalSize > this.MAX_CACHE_SIZE) {
        const validFiles = fileInfos.filter((f) => f !== null).sort((a, b) => a!.modificationTime - b!.modificationTime);

        let removedSize = 0;
        for (const file of validFiles) {
          if (totalSize - removedSize <= this.MAX_CACHE_SIZE * 0.8) break;

          await FileSystem.deleteAsync(file!.path);
          removedSize += file!.size;
          console.log(`删除旧缓存: ${file!.path}`);
        }
      }
    } catch (error) {
      console.error('清理缓存失败:', error);
    }
  }

  // 清除所有缓存
  static async clearAll(): Promise<void> {
    try {
      await FileSystem.deleteAsync(this.CACHE_DIR, { idempotent: true });
      await AsyncStorage.removeItem(this.CACHE_INDEX_KEY);
      console.log('所有视频缓存已清除');
    } catch (error) {
      console.error('清除缓存失败:', error);
    }
  }
}

export const dramaService = {
  // 暴露视频缓存管理
  videoCache: VideoCache,

  /**
   * 获取剧集列表
   */
  async getDramaList(pageRequest: PageQueryRequest<DramaEntity>) {
    const response = await DramaApi.listUsingPOST(pageRequest);
    return response.data;
  },

  /**
   * 获取剧集列表（包含节点信息）
   */
  async getDramaListWithSegments(pageRequest: PageQueryRequest<DramaEntity>) {
    const response = await DramaApi.listDramaSegmentsUsingPOST(pageRequest);
    return response.data;
  },

  /**
   * 根据剧集ID获取根节点
   */
  async getRootSegment(dramaId: number) {
    const response = await DramaApi.getRootSegmentByDramaIdUsingGET(dramaId);
    return response.data;
  },

  /**
   * 获取指定剧集的完整信息
   */
  async getDramaDetail(dramaId: number) {
    const response = await SegmentApi.getDramaDetailUsingGET(dramaId);
    return response.data;
  },

  /**
   * 获取指定节点的信息
   */
  async getSegment(segmentId: number) {
    const response = await SegmentApi.getSegmentUsingGET(segmentId);
    return response.data;
  },

  /**
   * 获取指定节点的详细信息（包含分支）
   */
  async getSegmentDetail(segmentId: number) {
    const response = await SegmentApi.getSegmentDetailUsingGET(segmentId);
    return response.data;
  },

  /**
   * 获取指定节点的详细信息并返回缓存的视频路径
   */
  async getSegmentDetailWithCache(segmentId: number): Promise<(SegmentDTO & { cachedUrl?: string }) | undefined> {
    const segment = await this.getSegmentDetail(segmentId);

    if (segment?.url) {
      // 获取缓存的视频路径（如果存在）
      const cachedUrl = await VideoCache.getCachedVideoPath(segment.url, segmentId);
      return { ...segment, cachedUrl };
    }

    return segment;
  },

  /**
   * 预加载视频到缓存
   */
  async preloadSegmentVideo(segmentId: number): Promise<void> {
    try {
      const segment = await this.getSegmentDetail(segmentId);
      if (segment?.url) {
        await VideoCache.preloadVideo(segment.url, segmentId);
      }
    } catch (error) {
      console.error('预加载视频失败:', error);
    }
  },

  /**
   * 根据节点ID获取分支选项
   */
  async getBranchOptions(segmentId: number) {
    const response = await BranchOptionApi.listBySegmentIdUsingGET(segmentId);
    return response.data || [];
  },

  /**
   * 获取分支选项详情
   */
  async getBranchOptionDetail(optionId: number) {
    const response = await BranchOptionApi.infoUsingGET(optionId);
    return response.data;
  },

  /**
   * 提交用户在某个节点的选择（播放进度）
   */
  async submitPlaybackProgress(progressData: PlaybackProgressForm) {
    const response = await SegmentApi.submitPlaybackProgressUsingPOST(progressData);
    return response;
  },

  /**
   * 获取剧集列表并保存到 store（带缓存）
   */
  async fetchAndCacheDramaList(forceRefresh: boolean = false) {
    const store = useDramaStore.getState();

    // 检查缓存是否有效
    if (!forceRefresh && store.isCacheValid()) {
      console.log('使用缓存的剧集列表');
      return store.dramaList;
    }

    try {
      store.setLoading(true);

      // 获取剧集列表
      const pageRequest: PageQueryRequest<DramaEntity> = {
        pageIndex: 1,
        pageSize: 10,
      };

      const response = await DramaApi.listDramaSegmentsUsingPOST(pageRequest);

      if (response.data?.records) {
        // 保存到 store
        store.setDramaList(response.data.records);
        store.updateLastFetchTime();
        console.log('剧集列表已更新到 store');
        return response.data.records;
      }

      return [];
    } catch (error) {
      console.error('获取剧集列表失败:', error);
      throw error;
    } finally {
      store.setLoading(false);
    }
  },

  /**
   * 分页获取剧集列表（支持无限滚动）
   */
  async fetchDramaListByPage(pageIndex: number, pageSize: number = 10) {
    try {
      const pageRequest: PageQueryRequest<DramaEntity> = {
        pageIndex,
        pageSize,
      };

      const response = await DramaApi.listDramaSegmentsUsingPOST(pageRequest);

      return {
        records: response.data?.records || [],
        total: response.data?.total || 0,
        hasMore: (response.data?.records?.length || 0) === pageSize,
      };
    } catch (error) {
      console.error('分页获取剧集列表失败:', error);
      throw error;
    }
  },

  /**
   * 获取第一个剧集的视频URL
   */
  async getFirstDramaVideo() {
    const store = useDramaStore.getState();

    try {
      // 先获取剧集列表
      const dramaList = await this.fetchAndCacheDramaList();

      if (!dramaList || dramaList.length === 0) {
        throw new Error('剧集列表为空');
      }

      // 获取第一个剧集
      const firstDrama = dramaList[0];
      store.setCurrentDrama(firstDrama);

      // 获取根片段ID - 处理不同的数据结构
      let rootSegmentId: number | undefined;
      if ('rootSegment' in firstDrama && firstDrama.rootSegment?.id) {
        // DramaSegmentDTO 类型
        rootSegmentId = firstDrama.rootSegment.id;
      } else if ('rootSegmentId' in firstDrama) {
        // DramaListItem 类型
        rootSegmentId = firstDrama.rootSegmentId;
      }

      if (!rootSegmentId) {
        throw new Error('剧集没有根片段ID');
      }

      // 获取片段详情
      const segmentDetail = await this.getSegmentDetail(rootSegmentId);

      if (!segmentDetail || !segmentDetail.url) {
        throw new Error('片段没有视频URL');
      }

      // 保存到 store
      store.setCurrentSegment(segmentDetail);
      store.setCurrentVideoUrl(segmentDetail.url);

      return {
        drama: firstDrama,
        segment: segmentDetail,
        url: segmentDetail.url,
      };
    } catch (error) {
      console.error('获取第一个剧集视频失败:', error);
      throw error;
    }
  },

  /**
   * 根据剧集ID获取视频URL
   */
  async getDramaVideoById(dramaId: number) {
    const store = useDramaStore.getState();

    try {
      // 获取根节点
      const rootSegment = await this.getRootSegment(dramaId);

      if (!rootSegment || !rootSegment.id) {
        throw new Error('无法获取根片段');
      }

      // 获取片段详情
      const segmentDetail = await this.getSegmentDetail(rootSegment.id);

      if (!segmentDetail || !segmentDetail.url) {
        throw new Error('片段没有视频URL');
      }

      // 保存到 store
      store.setCurrentSegment(segmentDetail);
      store.setCurrentVideoUrl(segmentDetail.url);

      return {
        segment: segmentDetail,
        url: segmentDetail.url,
      };
    } catch (error) {
      console.error('获取剧集视频失败:', error);
      throw error;
    }
  },
};
