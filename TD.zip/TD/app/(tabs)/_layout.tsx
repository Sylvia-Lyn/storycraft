import { Tabs } from "expo-router";
import { View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  return (
    <View style={{ flex: 1, backgroundColor: "#1c1c1c" }}>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarStyle: {
            display: 'none',
          },
        }}
      >
        <Tabs.Screen
          name="dream"
          options={{
            title: "叙梦",
          }}
        />
        <Tabs.Screen
          name="profile"
          options={{
            title: "我的",
          }}
        />
      </Tabs>
    </View>
  );
}
