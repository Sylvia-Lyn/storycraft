//
//  VideoOverlayView.swift
//  TodayDrama
//
//  Created by GH on 9/15/25.
//

import Combine
import SwiftUI
import AVFoundation

struct VideoOverlayView: View {
    @Environment(DramaManager.self) var manager
    let player: AVPlayer
    @Binding var showBranchTree: Bool
    
    @State private var currentTime: TimeInterval = 0
    @State private var hasAutoSwitched = false
    
    private var showBranchOptions: Bool {
        currentTime > 0 &&
        currentTime >= manager.currentSegment.branchTrigger &&
        !manager.currentSegment.branches.isEmpty &&
        !hasAutoSwitched
    }
    
    private var shouldAutoSwitch: Bool {
        guard manager.currentSegment.defaultSegmentId != nil,
              showBranchOptions else { return false }
        
        let timeElapsed = currentTime - manager.currentSegment.branchTrigger
        return timeElapsed >= 10.0 && !hasAutoSwitched
    }
    
    var body: some View {
        ZStack {
            if !showBranchTree {
                overlayView
            }
        }
        .onReceive(Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()) { _ in
            guard let currentItem = player.currentItem else { return }
            let time = currentItem.currentTime().seconds
            guard !time.isNaN && !time.isInfinite else { return }
            
            currentTime = time
            
            if shouldAutoSwitch {
                autoSwitchToDefault()
            }
        }
        .onChange(of: manager.currentSegment.id) { _, _ in
            hasAutoSwitched = false
            currentTime = 0
        }
    }
    
    private var overlayView: some View {
        VStack(spacing: 8) {
            Spacer()
            
            VStack(alignment: .leading, spacing: 4) {
                Text(manager.drama.title)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                
                Text(manager.currentSegment.title)
                    .font(.title2)
                    .fontWeight(.bold)
                
                if let description = manager.drama.description {
                    Text(description)
                        .font(.caption)
                        .lineLimit(2)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .overlay(alignment: .trailing) {
                let remaining = Int(ceil(manager.currentSegment.branchTrigger - currentTime))
                if remaining > 0 && !manager.currentSegment.branches.isEmpty && currentTime > 0 {
                    Text("\(remaining)")
                        .fontWeight(.bold)
                }
            }
            
            if showBranchOptions {
                ForEach(manager.currentSegment.branches) { branch in
                    Button {
                        selectBranch(branch)
                    } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text(branch.title)
                                    .font(.headline)
                                    .fontWeight(.semibold)
                            }
                            
                            if let description = branch.description {
                                Text(description)
                                    .font(.caption)
                                    .lineLimit(2)
                            }
                            
                            if manager.currentSegment.defaultSegmentId == branch.id {
                                let progress = (currentTime - manager.currentSegment.branchTrigger) / 10.0
                                
                                ProgressView(value: min(1.0, max(0.0, progress)))
                                    .progressViewStyle(LinearProgressViewStyle(tint: .white))
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(12)
                        .background(Color.white.opacity(0.2))
                        .clipShape(.rect(cornerRadius: 12, style: .continuous))
                    }
                }
            }
        }
        .padding()
        .background(
            LinearGradient(
                colors: [.clear, .black.opacity(0.6)],
                startPoint: .top,
                endPoint: .bottom
            )
        )
        .foregroundStyle(.white)
//        .padding(.bottom, 64)
    }
    
    func jumpToSegment(_ segment: Segment) {
        if segment.id == manager.drama.rootSegment.id {
            manager.currentSegment = manager.drama.rootSegment
            if let rootPlayerItem = manager.mainPlayerItem {
                player.replaceCurrentItem(with: rootPlayerItem)
                rootPlayerItem.seek(to: .zero, completionHandler: nil)
                player.play()
            }
            showBranchTree = false
            return
        }
        
        findBranch(for: segment, in: manager.drama.rootSegment) { branch in
            selectBranch(branch)
        }
        showBranchTree = false
    }
    
    private func selectBranch(_ branch: Segment) {
        guard let newPlayerItem = manager.switchToBranch(branch) else { return }
        
        player.replaceCurrentItem(with: newPlayerItem)
        newPlayerItem.seek(to: .zero, completionHandler: nil)
        player.play()
        
        hasAutoSwitched = true
        currentTime = 0
    }
    
    private func autoSwitchToDefault() {
        guard let defaultSegmentId = manager.currentSegment.defaultSegmentId,
              let defaultBranch = manager.currentSegment.branches.first(where: { $0.id == defaultSegmentId }) else {
            return
        }
        
        selectBranch(defaultBranch)
    }
    
    private func findBranch(for targetSegment: Segment, in currentSegment: Segment, completion: @escaping (Segment) -> Void) {
        for branch in currentSegment.branches {
            if branch.id == targetSegment.id {
                completion(branch)
                return
            }
            findBranch(for: targetSegment, in: branch, completion: completion)
        }
    }
}
