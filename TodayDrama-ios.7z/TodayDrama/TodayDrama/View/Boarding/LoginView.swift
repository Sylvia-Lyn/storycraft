//
//  LoginView.swift
//  TodayDrama
//
//  Created by GH on 9/4/25.
//

import SwiftUI
import SwiftyJSON
import AuthenticationServices

struct LoginView: View {
    @State private var identifier: String = ""
    @State private var password: String = ""
    @State private var prefixCode: String = "+86"
    @State private var type: IdentifierType = .phone
    @State private var canLogin: Bool = false
    @Bindable private var app = AppState.shared
    @FocusState private var focusedField: Field?
    let toRegister: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            TitleView()
            
            // TODO: - 待添加前缀功能
//            IdentifierInputView(identifier: $identifier, prefixCode: $prefixCode, type: type)
            IdentifierInputView(identifier: $identifier, type: type)
            
            PasswordInputView(password: $password)
            
            InputTypeSelectionView(type: $type, identifier: $identifier, toRegister: toRegister)
            
            LoginButtonView(
                canLogin: canLogin,
                type: type,
                identifier: identifier,
                password: password
            )
            
//            LoginButtonView(
//                canLogin: canLogin,
//                type: type,
//                identifier: identifier,
//                password: password,
//                prefixCode: prefixCode
//            )
            
            Spacer()
            
            TermsView()
            
            OrDividerView()
            
            ThirdPartyLoginView()
        }
        .onChange(of: identifier) { validateInputs() }
        .onChange(of: password) { validateInputs() }
        .onChange(of: type) { validateInputs() }
        .onAppear { validateInputs() }
        .padding(.horizontal, 24)
    }
    
    private enum Field: Hashable {
        case identifier
        case password
    }
    
    private func validateInputs() {
        let isPasswordValid = password.count >= 8
        
        var isIdentifierValid = false
        switch type {
        case .email:
            let emailRegex = try? NSRegularExpression(pattern: type.regexPattern)
            let range = NSRange(identifier.startIndex..<identifier.endIndex, in: identifier)
            isIdentifierValid = emailRegex?.firstMatch(in: identifier, range: range) != nil
            
        case .phone:
            let phoneRegex = try? NSRegularExpression(pattern: type.regexPattern)
            let range = NSRange(identifier.startIndex..<identifier.endIndex, in: identifier)
            isIdentifierValid = phoneRegex?.firstMatch(in: identifier, range: range) != nil
        }
        
        withAnimation(.spring(duration: 0.25)) {
            canLogin = isPasswordValid && isIdentifierValid
        }
    }
}

// MARK: - 标题
private struct TitleView: View {
    @Bindable private var app = AppState.shared
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("登录")
                .font(.largeTitle)
                .bold()
            
            Text("登录以获得完整体验")
                .font(.headline)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .frame(maxHeight: 128)
    }
}

// MARK: - 邮箱/手机号输入
struct IdentifierInputView: View {
    @Binding var identifier: String
//    @Binding var prefixCode: String
    var type: IdentifierType
    
    var body: some View {
        HStack(spacing: 8) {
//            if type == .phone {
//                Menu {
//                    ForEach(Array(regions.keys).sorted(), id: \.self) { region in
//                        Button("\(region) (\(regions[region]!))") {
//                            prefixCode = regions[region]!
//                        }
//                    }
//                } label: {
//                    Text(prefixCode)
//                }
//            }
            
            TextField(type.placeholder, text: $identifier)
                .keyboardType(type.keyboardType)
                .textContentType(.oneTimeCode)
                .textFieldStyle(.roundedBorder)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
        }
    }
}

// MARK: - 密码输入
private struct PasswordInputView: View {
    @Binding var password: String
    
    var body: some View {
        SecureField("密码", text: $password)
            .textFieldStyle(.roundedBorder)
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()
    }
}

// MARK: - 登录类型选择
private struct InputTypeSelectionView: View {
    @Binding var type: IdentifierType
    @Binding var identifier: String
    let toRegister: () -> Void
    
    var body: some View {
        HStack {
            Button(type.switchButtonText) {
                UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                
                withAnimation(.spring) {
                    type = (type == .email) ? .phone : .email
                }
                
                identifier.removeAll()
            }
            
            Spacer()
            
            Button {
                toRegister()
            } label: {
                Text("注册")
                
                Image(systemName: "arrow.right")
            }
        }
        .font(.headline)
        .buttonStyle(.plain)
    }
}

// MARK: - 登录按钮
private struct LoginButtonView: View {
    var canLogin: Bool
    var type: IdentifierType
    var identifier: String
    var password: String
//    var prefixCode: String
    
    var body: some View {
        Button {
            guard canLogin else { return }
            
            var body = ["password": password]
            if type == .phone {
                body["mobile"] = identifier
//                body["mobile"] = prefixCode + identifier
            } else {
                body["email"] = identifier
            }
            
            Network.post("user/login", body: body) { data in
                guard let token = data["token"].string else { return }
                Network.setToken(token)
                
                AppState.shared.user.auth()
            }
        } label: {
            Text("登录")
                .font(.headline)
                .kerning(canLogin ? 3 : 1)
                .fontWeight(canLogin ? .semibold : .medium)
                .foregroundStyle(.background)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(.foreground, in: .rect(cornerRadius: 8))
        }
        .buttonBorderShape(.roundedRectangle(radius: 8))
        .buttonStyle(.plain)
        .disabled(!canLogin)
    }
}

// MARK: - 条款
struct TermsView: View {
    @State private var showUserAgreement = false
    @State private var showPrivacyPolicy = false
    @Environment(\.dismiss) private var dismiss
    @State private var register: Bool = true
    
    var body: some View {
        VStack {
            Text("继续即代表你同意 [用户协议](useragreement) 和 [隐私政策](privacypolicy)")
                .font(.caption)
                .foregroundStyle(.secondary)
//                .tint(.accent)
                .frame(maxWidth: .infinity, alignment: .center)
                .environment(\.openURL, OpenURLAction { url in
                    if url.absoluteString == "useragreement" {
                        showUserAgreement = true
                        return .handled
                    } else if url.absoluteString == "privacypolicy" {
                        showPrivacyPolicy = true
                        return .handled
                    }
                    return .discarded
                })
        }
        .sheet(isPresented: $showUserAgreement) {
            // TODO: - 用户协议
//            WebView(url: URL(string: userAgreement)!, title: "用户协议")
        }
        .sheet(isPresented: $showPrivacyPolicy) {
//            WebView(url: URL(string: privacyPolicy)!, title: "隐私条款")
        }
    }
}

// MARK: - 分隔线
private struct OrDividerView: View {
    var body: some View {
        HStack {
            Rectangle()
                .frame(height: 2)
                .foregroundStyle(.tertiary)
            
            Text("or Sign in with")
                .layoutPriority(1)
                .font(.footnote)
            
            Rectangle()
                .frame(height: 2)
                .foregroundStyle(.tertiary)
        }
    }
}

private struct ThirdPartyLoginView: View {
    var body: some View {
        HStack(spacing: 16) {
            // MARK: - Sign in with Apple Button
            SignInWithAppleButton(.signIn) { request in
                request.requestedScopes = [.email]
            } onCompletion: { result in
                switch result {
                case .success(let authorization):
                    print(authorization)
                case .failure(let error):
                    print("Authentication error: \(error.localizedDescription)")
                }
            }
            .signInWithAppleButtonStyle(.whiteOutline)
//            .fixedSize()
            
            // MARK: - Google Sign in Button
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .fill(.white)
                .strokeBorder(Color.black, lineWidth: 0.6)
                .overlay {
                    HStack(spacing: 12) {
//                        Image(.googleLogo)
                        
                        Text("Sign in with Google")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.black)
                    }
                }
                .hoverEffect()
        }
        .frame(height: 44)
    }
}

#Preview {
    LoginView {}
}
