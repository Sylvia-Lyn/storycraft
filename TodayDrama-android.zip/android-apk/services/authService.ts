// 认证服务 - 处理所有与认证相关的业务逻辑
import { AuthApi } from "@/api";
import type { LoginForm, RegisterForm, UserUpdateForm } from "@/api/types";
import { useAuthStore } from "@/store/authStore";

export const authService = {
  /**
   * 用户登录
   */
  async login(loginData: LoginForm) {
    const response = await AuthApi.loginUsingPOST(loginData);

    if (response.data) {
      // 从响应数据中提取 token 和用户信息
      const { token, refreshToken, ...userData } = response.data;

      console.log("登录响应数据:", { token, refreshToken, userData });

      // 保存登录信息到 store
      useAuthStore.getState().login({
        user: userData as any, // 临时用户数据
        token: token as string,
        refreshToken: refreshToken as string,
      });

      console.log("Token 已保存到 store:", useAuthStore.getState().token);

      // 登录成功后立即获取完整的用户信息
      try {
        await this.getUserInfo();
      } catch (error) {
        console.error("获取用户信息失败:", error);
        // 即使获取用户信息失败，登录也算成功
      }
    }

    return response;
  },

  /**
   * 用户注册
   */
  async register(registerData: RegisterForm) {
    const response = await AuthApi.registerUsingPOST(registerData);

    if (response.data) {
      // 从响应数据中提取 token 和用户信息
      const { token, refreshToken, ...userData } = response.data;

      // 保存登录信息到 store
      useAuthStore.getState().login({
        user: userData as any, // 临时用户数据
        token: token as string,
        refreshToken: refreshToken as string,
      });

      // 注册成功后立即获取完整的用户信息
      try {
        await this.getUserInfo();
      } catch (error) {
        console.error("获取用户信息失败:", error);
        // 即使获取用户信息失败，注册也算成功
      }
    }

    return response;
  },

  /**
   * 用户登出
   */
  async logout() {
    const userId = useAuthStore.getState().user?.userId;

    try {
      // 调用服务器登出接口
      if (userId) {
        await AuthApi.logoutUsingPOST(userId);
      }
    } catch (error) {
      console.error("调用登出API失败:", error);
      // 即使API调用失败，也要清除本地数据
    } finally {
      // 清除本地所有认证数据（包括 AsyncStorage）
      useAuthStore.getState().logout();
    }
  },

  /**
   * 刷新token
   */
  async refreshToken() {
    const response = await AuthApi.refreshTokenUsingPOST();

    if (response.data) {
      const { token, refreshToken } = response.data;
      const currentUser = useAuthStore.getState().user;

      if (currentUser) {
        useAuthStore.getState().login({
          user: currentUser,
          token: token as string,
          refreshToken: refreshToken as string,
        });
      }
    }

    return response;
  },

  /**
   * 获取用户信息
   */
  async getUserInfo() {
    console.log("开始获取用户信息...");
    const { data } = await AuthApi.userInfoUsingPOST_1();
    console.log("获取到的用户信息:", data);
    useAuthStore.getState().updateUser(data);
    console.log("用户信息已更新到 store:", useAuthStore.getState().user);
    return data;
  },

  /**
   * 更新用户信息
   */
  async updateUserInfo(updateData: UserUpdateForm) {
    const response = await AuthApi.updateUserInfoUsingPOST(updateData);

    // 更新成功后重新获取用户信息
    if (response.code === "0") {
      await this.getUserInfo();
    }

    return response;
  },

  /**
   * 更新语言偏好
   */
  async updateLanguage(language: string) {
    const response = await AuthApi.updateLanguageUsingPOST({ language });

    // 更新成功后重新获取用户信息
    if (response.code === "0") {
      await this.getUserInfo();
    }

    return response;
  },

  /**
   * 获取支持的语言列表
   */
  async getSupportedLanguages() {
    const response = await AuthApi.getSupportedLanguagesUsingGET();
    return response.data || [];
  },

  /**
   * 获取用户ID
   */
  async getUserId() {
    const response = await AuthApi.userInfoUsingPOST();
    return response.data;
  },
};
