//
//  DiscoverView.swift
//  TodayDrama
//
//  Created by GH on 9/4/25.
//

import SwiftUI

struct DiscoverView: View {
    var body: some View {
        VStack {
            Text("发现")
                .font(.largeTitle)
                .fontWeight(.bold)
        }
    }
}

#Preview {
    DiscoverView()
}
